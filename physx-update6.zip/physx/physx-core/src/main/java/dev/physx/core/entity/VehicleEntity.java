package dev.physx.core.entity;

import dev.physx.core.ModRegistry;
import dev.physx.core.network.InputPayload;
import dev.physx.core.vehicle.*;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.neoforge.entity.PartEntity;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

public class VehicleEntity extends Entity {
    /** Высота центра масс над низом хитбокса (низ хитбокса 0.40 м над землёй). */
    public static final double COM_Y = 0.445;
    /** Высота центра масс над землёй в покое (из теста подвески Blazer: 0.846 м). */
    public static final double COM_H = 0.845;
    /** Высота точки посадки водителя относительно центра масс. */
    public static final double SEAT_Y = -0.225;

    private static final EntityDataAccessor<Float> QX = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> QY = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> QZ = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> QW = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> STEER = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> SPIN = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);

    // данные для приборной панели (HUD)
    private static final EntityDataAccessor<Float> HUD_SPEED = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> HUD_RPM = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> HUD_RPM_MAX = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> HUD_GEAR = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> HUD_PEDALS = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.INT);

    /** Части хитбокса: смещение вдоль машины, ширина, низ относительно хитбокса, высота. */
    private static final double[][] PART_DEF = {
            {1.44, 1.9, -0.05, 0.82},   // капот (верх ~1.17 м над землёй)
            {-0.30, 1.9, -0.05, 1.65},  // кабина (крыша ~2.0 м)
            {-1.20, 1.9, -0.05, 1.65},
            {-2.00, 1.9, -0.05, 1.65}
    };
    private final VehiclePart[] parts = new VehiclePart[PART_DEF.length];
    private double heading;

    // сервер
    private VehicleSim sim;
    private final VehicleInput input = new VehicleInput();
    private final LevelProbe probe = new LevelProbe();
    private boolean asleep, handbrakeHeld;
    private int restTicks;
    public double lastImpactSpeed;

    // клиент
    private final Quaternionf prevQ = new Quaternionf(), curQ = new Quaternionf();
    private float prevSteer, steer, prevSpin, spin, lastRawSpin;
    private double lerpX, lerpY, lerpZ;
    private int lerpSteps;

    public VehicleEntity(EntityType<? extends VehicleEntity> type, Level level) {
        super(type, level);
        for (int i = 0; i < parts.length; i++) parts[i] = new VehiclePart(this, (float) PART_DEF[i][1], (float) PART_DEF[i][3]);
    }

    @Override public boolean isMultipartEntity() { return true; }
    @Override public PartEntity<?>[] getParts() { return parts; }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder b) {
        b.define(QX, 0f); b.define(QY, 0f); b.define(QZ, 0f); b.define(QW, 0f);
        b.define(STEER, 0f); b.define(SPIN, 0f);
        b.define(HUD_SPEED, 0f); b.define(HUD_RPM, 0f); b.define(HUD_RPM_MAX, 6000f);
        b.define(HUD_GEAR, 3); b.define(HUD_PEDALS, 0);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag t) {
        if (t.contains("qw")) {
            entityData.set(QX, t.getFloat("qx")); entityData.set(QY, t.getFloat("qy"));
            entityData.set(QZ, t.getFloat("qz")); entityData.set(QW, t.getFloat("qw"));
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag t) {
        t.putFloat("qx", entityData.get(QX)); t.putFloat("qy", entityData.get(QY));
        t.putFloat("qz", entityData.get(QZ)); t.putFloat("qw", entityData.get(QW));
    }

    @Override
    public boolean isPickable() { return !isRemoved(); }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (player.isSecondaryUseActive()) return InteractionResult.PASS;
        if (!level().isClientSide && getPassengers().isEmpty()) {
            player.startRiding(this);
            asleep = false; restTicks = 0;
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved()) return true;
        if (source.getEntity() instanceof Player p) {
            if (!p.getAbilities().instabuild) spawnAtLocation(ModRegistry.TEST_CAR_ITEM.get());
            discard();
            return true;
        }
        return false;
    }

    public boolean causeFallDamage(float dist, float mult, DamageSource src) { return false; }

    public Vec3 getPassengerAttachmentPoint(Entity passenger, EntityDimensions dims, float scale) {
        Vector3f v = new Vector3f(0.40f, (float) SEAT_Y, -0.25f);
        getRenderQuat(1.0f).transform(v);
        return new Vec3(v.x, v.y + COM_Y, v.z);
    }

    // ------------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) clientTick(); else serverTick();
    }

    private LivingEntity getDriver() {
        return getFirstPassenger() instanceof LivingEntity l ? l : null;
    }

    private void initSim() {
        sim = new VehicleSim(VehicleSpec.blazer());
        float qx = entityData.get(QX), qy = entityData.get(QY), qz = entityData.get(QZ), qw = entityData.get(QW);
        RigidBody b = sim.body;
        if (qx * qx + qy * qy + qz * qz + qw * qw < 0.5f) {
            double th = -Math.toRadians(getYRot());
            b.qw = Math.cos(th / 2); b.qx = 0; b.qy = Math.sin(th / 2); b.qz = 0;
        } else {
            b.qw = qw; b.qx = qx; b.qy = qy; b.qz = qz;
        }
    }

    /** Нажатия клавиш от игрока (приходят из сети). */
    public void applyKeys(InputPayload k, Player p) {
        if (sim == null) initSim();
        handbrakeHeld = k.handbrake();
        Drivetrain d = sim.drivetrain;
        if (k.gearUp()) { if (d.manual) d.shiftUp(); }
        if (k.gearDown()) { if (d.manual) d.shiftDown(); }
        if (k.toggleBox()) {
            d.setManual(!d.manual);
            p.displayClientMessage(Component.literal("Коробка: " + (d.manual ? "механика (X/Z - передачи)" : "автомат")), true);
        }
        if (k.toggleTc()) {
            sim.spec.tractionControl = !sim.spec.tractionControl;
            p.displayClientMessage(Component.literal("Антибуксовка: " + (sim.spec.tractionControl ? "вкл" : "выкл")), true);
        }
    }

    private void serverTick() {
        if (sim == null) initSim();
        LivingEntity driver = getDriver();
        boolean hasDriver = driver != null;
        if (hasDriver) { asleep = false; restTicks = 0; } else handbrakeHeld = false;
        if (asleep && tickCount % 20 != 0) return;

        input.parked = !hasDriver;
        input.throttle = hasDriver ? Mth.clamp(driver.zza, -1f, 1f) : 0;
        input.steer = hasDriver ? Mth.clamp(driver.xxa, -1f, 1f) : 0;
        input.handbrake = handbrakeHeld;

        List<Entity> riders = findStanding();
        Vec3 oldPos = position();
        double oldHeading = heading;

        RigidBody b = sim.body;
        b.px = oldPos.x; b.py = oldPos.y + COM_Y; b.pz = oldPos.z;
        double speed = Math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz);
        sim.prepare(probe, speed * 0.05 + 0.3);
        int n = Mth.clamp((int) Math.ceil(speed * 0.2), 5, 12); // быстрее едем - больше подшагов
        double dt = 0.05 / n;
        for (int i = 0; i < n; i++) sim.step(dt, input, probe);
        lastImpactSpeed = sim.takeImpact(); // для деформации (следующий этап)
        setPos(b.px, b.py - COM_Y, b.pz);

        double v2 = b.vx * b.vx + b.vy * b.vy + b.vz * b.vz;
        double w2 = b.wx * b.wx + b.wy * b.wy + b.wz * b.wz;
        boolean allGrounded = sim.wheels[0].grounded && sim.wheels[1].grounded && sim.wheels[2].grounded && sim.wheels[3].grounded;
        if (!hasDriver && allGrounded && v2 < 0.01 && w2 < 0.01) { if (++restTicks > 40) asleep = true; }
        else { restTicks = 0; asleep = false; }

        double[] f = new double[3];
        b.toWorld(0, 0, 1, f);
        heading = Math.atan2(-f[0], f[2]);
        setYRot((float) Math.toDegrees(heading));
        setXRot(0);
        entityData.set(QX, (float) b.qx); entityData.set(QY, (float) b.qy);
        entityData.set(QZ, (float) b.qz); entityData.set(QW, (float) b.qw);
        entityData.set(STEER, (float) sim.steerAngle);
        entityData.set(SPIN, (float) sim.spinAccum);

        updateParts();
        carry(riders, oldPos, oldHeading);

        Drivetrain dr = sim.drivetrain;
        entityData.set(HUD_SPEED, Math.round(sim.forwardSpeed() * 3.6 * 2) / 2f);
        entityData.set(HUD_RPM, Math.round(dr.rpm / 25.0) * 25f);
        entityData.set(HUD_RPM_MAX, (float) dr.redline);
        entityData.set(HUD_GEAR, ((dr.gear + 2) & 15) | (dr.manual ? 16 : 0) | (sim.spec.tractionControl ? 32 : 0)
                | (handbrakeHeld ? 64 : 0) | (sim.tcActive ? 128 : 0));
        entityData.set(HUD_PEDALS, (int) (sim.outThrottle * 100) | ((int) (sim.outBrake * 100) << 8));
    }

    // --- данные для HUD (клиент) ---
    public float getHudSpeedKmh() { return entityData.get(HUD_SPEED); }
    public float getHudRpm() { return entityData.get(HUD_RPM); }
    public float getHudRpmMax() { return entityData.get(HUD_RPM_MAX); }
    /** -1 = задняя, 0 = нейтраль, 1.. = передача. */
    public int getHudGear() { return (entityData.get(HUD_GEAR) & 15) - 2; }
    public boolean getHudManual() { return (entityData.get(HUD_GEAR) & 16) != 0; }
    public boolean getHudTcEnabled() { return (entityData.get(HUD_GEAR) & 32) != 0; }
    public boolean getHudHandbrake() { return (entityData.get(HUD_GEAR) & 64) != 0; }
    public boolean getHudTcActive() { return (entityData.get(HUD_GEAR) & 128) != 0; }
    public float getHudThrottle() { return (entityData.get(HUD_PEDALS) & 255) / 100f; }
    public float getHudBrake() { return ((entityData.get(HUD_PEDALS) >> 8) & 255) / 100f; }
    public float getHudSteer() { return steer; }

    // ------------------------------------------------- хитбокс из частей, перенос
    private void updateParts() {
        double fx = -Math.sin(heading), fz = Math.cos(heading);
        Vec3 p = position();
        for (int i = 0; i < parts.length; i++) {
            double[] d = PART_DEF[i];
            parts[i].setPos(p.x + fx * d[0], p.y + d[2], p.z + fz * d[0]);
        }
    }

    /** Кто стоит на машине (на верхней грани одной из частей). */
    private List<Entity> findStanding() {
        List<Entity> out = new ArrayList<>();
        AABB area = getBoundingBox().inflate(3.0, 0.5, 3.0).expandTowards(0, 2.2, 0);
        for (Entity e : level().getEntities(this, area)) {
            if (e instanceof PartEntity<?> || e.isPassenger() || e.isSpectator() || !e.onGround()) continue;
            if (level().isClientSide) { if (!(e instanceof Player p && p.isLocalPlayer())) continue; }
            else if (e instanceof Player) continue; // игроков двигает их клиент
            AABB eb = e.getBoundingBox();
            for (VehiclePart part : parts) {
                AABB pb = part.getBoundingBox();
                if (eb.minX < pb.maxX && eb.maxX > pb.minX && eb.minZ < pb.maxZ && eb.maxZ > pb.minZ
                        && Math.abs(eb.minY - pb.maxY) < 0.15) { out.add(e); break; }
            }
        }
        return out;
    }

    /** Переносит стоящих на машине вместе с ней (сдвиг и поворот). */
    private void carry(List<Entity> riders, Vec3 oldPos, double oldHeading) {
        if (riders.isEmpty()) return;
        Vec3 np = position();
        double dh = heading - oldHeading;
        while (dh > Math.PI) dh -= 2 * Math.PI;
        while (dh < -Math.PI) dh += 2 * Math.PI;
        double c = Math.cos(dh), s = Math.sin(dh);
        for (Entity e : riders) {
            double ox = e.getX(), oy = e.getY(), oz = e.getZ();
            double rx = ox - oldPos.x, rz = oz - oldPos.z;
            double nx = np.x + rx * c - rz * s, nz = np.z + rx * s + rz * c, ny = oy + (np.y - oldPos.y);
            e.setPos(nx, ny, nz);
            if (level().isClientSide) {
                e.xo += nx - ox; e.yo += ny - oy; e.zo += nz - oz;
                e.xOld += nx - ox; e.yOld += ny - oy; e.zOld += nz - oz;
            }
        }
    }

    // --------------------------------------------------------------- клиент
    @Override
    public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps) {
        if (level().isClientSide) { lerpX = x; lerpY = y; lerpZ = z; lerpSteps = 2; }
        else super.lerpTo(x, y, z, yRot, xRot, steps);
    }

    private void clientTick() {
        List<Entity> riders = findStanding();
        Vec3 oldPos = position();
        double oldHeading = heading;
        if (lerpSteps > 0) {
            setPos(getX() + (lerpX - getX()) / lerpSteps, getY() + (lerpY - getY()) / lerpSteps,
                    getZ() + (lerpZ - getZ()) / lerpSteps);
            lerpSteps--;
        }
        prevQ.set(curQ);
        float x = entityData.get(QX), y = entityData.get(QY), z = entityData.get(QZ), w = entityData.get(QW);
        if (x * x + y * y + z * z + w * w < 0.5f) curQ.identity(); else curQ.set(x, y, z, w).normalize();
        Vector3f fwd = curQ.transform(new Vector3f(0, 0, 1));
        heading = Math.atan2(-fwd.x, fwd.z);
        prevSteer = steer; steer = entityData.get(STEER);
        float raw = entityData.get(SPIN);
        double d = raw - lastRawSpin;
        while (d > Math.PI) d -= 2 * Math.PI;
        while (d < -Math.PI) d += 2 * Math.PI;
        lastRawSpin = raw; prevSpin = spin; spin += (float) d;
        updateParts();
        carry(riders, oldPos, oldHeading);
    }

    public Quaternionf getRenderQuat(float pt) {
        if (level().isClientSide) return new Quaternionf(prevQ).slerp(curQ, pt);
        float x = entityData.get(QX), y = entityData.get(QY), z = entityData.get(QZ), w = entityData.get(QW);
        if (x * x + y * y + z * z + w * w < 0.5f) return new Quaternionf();
        return new Quaternionf(x, y, z, w).normalize();
    }
    public float getRenderSteer(float pt) { return Mth.lerp(pt, prevSteer, steer); }
    public float getRenderSpin(float pt) { return Mth.lerp(pt, prevSpin, spin); }

    // ---------------------------------------------------------------- земля
    private final class LevelProbe implements GroundProbe {
        private double grip = 1.0;
        private final BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        private final BlockPos.MutableBlockPos nb = new BlockPos.MutableBlockPos();

        @Override
        public double cast(double ox, double oy, double oz, double dx, double dy, double dz, double maxLen) {
            Vec3 from = new Vec3(ox, oy, oz);
            Vec3 to = new Vec3(ox + dx * maxLen, oy + dy * maxLen, oz + dz * maxLen);
            BlockHitResult r = level().clip(new ClipContext(from, to, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, VehicleEntity.this));
            if (r.getType() == HitResult.Type.MISS) return -1;
            float friction = level().getBlockState(r.getBlockPos()).getBlock().getFriction();
            grip = friction <= 0.6f ? 1.0 : Math.max(0.15, 1.0 - (friction - 0.6) / 0.38 * 0.85);
            return from.distanceTo(r.getLocation());
        }

        @Override
        public double grip() { return grip; }

        private boolean full(int x, int y, int z) {
            nb.set(x, y, z);
            return level().getBlockState(nb).isCollisionShapeFullBlock(level(), nb);
        }

        private int coverFlags(int x, int y, int z) {
            int f = 0;
            if (full(x - 1, y, z)) f |= 1;
            if (full(x + 1, y, z)) f |= 2;
            if (full(x, y - 1, z)) f |= 4;
            if (full(x, y + 1, z)) f |= 8;
            if (full(x, y, z - 1)) f |= 16;
            if (full(x, y, z + 1)) f |= 32;
            return f;
        }

        @Override
        public int boxes(double x0, double y0, double z0, double x1, double y1, double z1, double[] out, int max) {
            int n = 0;
            Level lv = level();
            for (int x = Mth.floor(x0); x <= Mth.floor(x1); x++)
                for (int y = Mth.floor(y0); y <= Mth.floor(y1); y++)
                    for (int z = Mth.floor(z0); z <= Mth.floor(z1); z++) {
                        mp.set(x, y, z);
                        BlockState bs = lv.getBlockState(mp);
                        if (bs.isAir()) continue;
                        VoxelShape shape = bs.getCollisionShape(lv, mp);
                        if (shape.isEmpty()) continue;
                        int cover = -1;
                        for (AABB a : shape.toAabbs()) {
                            if (n >= max) return n;
                            if (cover < 0) cover = coverFlags(x, y, z);
                            int f = 0;
                            if (a.minX <= 1e-6) f |= cover & 1;
                            if (a.maxX >= 1 - 1e-6) f |= cover & 2;
                            if (a.minY <= 1e-6) f |= cover & 4;
                            if (a.maxY >= 1 - 1e-6) f |= cover & 8;
                            if (a.minZ <= 1e-6) f |= cover & 16;
                            if (a.maxZ >= 1 - 1e-6) f |= cover & 32;
                            int o = n * 7;
                            out[o] = x + a.minX; out[o + 1] = y + a.minY; out[o + 2] = z + a.minZ;
                            out[o + 3] = x + a.maxX; out[o + 4] = y + a.maxY; out[o + 5] = z + a.maxZ;
                            out[o + 6] = f;
                            n++;
                        }
                    }
            return n;
        }
    }
}
