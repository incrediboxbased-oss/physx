package dev.physx.core.entity;

import dev.physx.core.ModRegistry;
import dev.physx.core.vehicle.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class VehicleEntity extends Entity {
    /** Высота центра масс над низом хитбокса. */
    public static final double COM_Y = -0.044;
    /** Высота днища хитбокса над землёй при стоянке (~0.55 м): проезжает над полублоками. */
    public static final double SEAT_Y = 0.06;
    private static final int SUBSTEPS = 4;
    private static final double DT = 0.05 / SUBSTEPS;

    private static final EntityDataAccessor<Float> QX = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> QY = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> QZ = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> QW = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> STEER = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> SPIN = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);

    // сервер
    private VehicleSim sim;
    private final VehicleInput input = new VehicleInput();
    private final LevelProbe probe = new LevelProbe();
    private boolean asleep;
    private int restTicks;
    public double lastImpactSpeed;

    // клиент
    private final Quaternionf prevQ = new Quaternionf(), curQ = new Quaternionf();
    private float prevSteer, steer, prevSpin, spin, lastRawSpin;
    private double lerpX, lerpY, lerpZ;
    private int lerpSteps;

    public VehicleEntity(EntityType<? extends VehicleEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder b) {
        b.define(QX, 0f); b.define(QY, 0f); b.define(QZ, 0f); b.define(QW, 0f);
        b.define(STEER, 0f); b.define(SPIN, 0f);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag t) {
        if (t.contains("qw")) {
            entityData.set(QX, t.getFloat("qx")); entityData.set(QY, t.getFloat("qy"));
            entityData.set(QZ, t.getFloat("qz")); entityData.set(QW, t.getFloat("qw"));
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag t) {
        t.putFloat("qx", entityData.get(QX)); t.putFloat("qy", entityData.get(QY));
        t.putFloat("qz", entityData.get(QZ)); t.putFloat("qw", entityData.get(QW));
    }

    @Override
    public boolean isPickable() { return !isRemoved(); }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (player.isSecondaryUseActive()) return InteractionResult.PASS;
        if (!level().isClientSide && getPassengers().isEmpty()) {
            player.startRiding(this);
            asleep = false; restTicks = 0;
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved()) return true;
        if (source.getEntity() instanceof Player p) {
            if (!p.getAbilities().instabuild) spawnAtLocation(ModRegistry.TEST_CAR_ITEM.get());
            discard();
            return true;
        }
        return false;
    }

    /** Автоподъём на ступеньки и полублоки. */
    public float maxUpStep() { return 0.6F; }

    public boolean causeFallDamage(float dist, float mult, DamageSource src) { return false; }

    public Vec3 getPassengerAttachmentPoint(Entity passenger, EntityDimensions dims, float scale) {
        Vector3f v = new Vector3f(0.35f, (float) SEAT_Y, -0.1f);
        getRenderQuat(1.0f).transform(v);
        return new Vec3(v.x, v.y + COM_Y, v.z);
    }

    // ------------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) clientTick(); else serverTick();
    }

    private LivingEntity getDriver() {
        return getFirstPassenger() instanceof LivingEntity l ? l : null;
    }

    private void initSim() {
        sim = new VehicleSim(VehicleSpec.sportsCar());
        float qx = entityData.get(QX), qy = entityData.get(QY), qz = entityData.get(QZ), qw = entityData.get(QW);
        RigidBody b = sim.body;
        if (qx * qx + qy * qy + qz * qz + qw * qw < 0.5f) {
            double th = -Math.toRadians(getYRot());
            b.qw = Math.cos(th / 2); b.qx = 0; b.qy = Math.sin(th / 2); b.qz = 0;
        } else {
            b.qw = qw; b.qx = qx; b.qy = qy; b.qz = qz;
        }
    }

    private void serverTick() {
        if (sim == null) initSim();
        LivingEntity driver = getDriver();
        boolean hasDriver = driver != null;
        if (hasDriver) { asleep = false; restTicks = 0; }
        if (asleep && tickCount % 20 != 0) return;

        input.parked = !hasDriver;
        input.throttle = hasDriver ? Mth.clamp(driver.zza, -1f, 1f) : 0;
        input.steer = hasDriver ? Mth.clamp(driver.xxa, -1f, 1f) : 0;
        input.handbrake = false;

        RigidBody b = sim.body;
        Vec3 start = position();
        b.px = start.x; b.py = start.y + COM_Y; b.pz = start.z;
        for (int i = 0; i < SUBSTEPS; i++) sim.step(DT, input, probe);

        Vec3 desired = new Vec3(b.px - start.x, b.py - start.y - COM_Y, b.pz - start.z);
        move(MoverType.SELF, desired);
        Vec3 end = position();
        double impact = 0;
        if (Math.abs(end.x - start.x - desired.x) > 1e-4) { impact = Math.max(impact, Math.abs(b.vx)); b.vx *= -0.1; }
        if (Math.abs(end.z - start.z - desired.z) > 1e-4) { impact = Math.max(impact, Math.abs(b.vz)); b.vz *= -0.1; }
        double dyAct = end.y - start.y;
        if (dyAct > desired.y + 1e-4 && b.vy < 0) b.vy = 0;
        if (dyAct < desired.y - 1e-4 && b.vy > 0) b.vy = 0;
        if (impact > 1.0) { b.wx *= 0.6; b.wy *= 0.6; b.wz *= 0.6; }
        lastImpactSpeed = impact; // для деформации (этап 4)
        b.px = end.x; b.py = end.y + COM_Y; b.pz = end.z;

        // сон: стоящая машина не считается
        double v2 = b.vx * b.vx + b.vy * b.vy + b.vz * b.vz;
        double w2 = b.wx * b.wx + b.wy * b.wy + b.wz * b.wz;
        boolean allGrounded = sim.wheels[0].grounded && sim.wheels[1].grounded && sim.wheels[2].grounded && sim.wheels[3].grounded;
        if (!hasDriver && allGrounded && v2 < 0.01 && w2 < 0.01) { if (++restTicks > 40) asleep = true; }
        else { restTicks = 0; asleep = false; }

        double[] f = new double[3];
        b.toWorld(0, 0, 1, f);
        setYRot((float) Math.toDegrees(Math.atan2(-f[0], f[2])));
        setXRot(0);
        entityData.set(QX, (float) b.qx); entityData.set(QY, (float) b.qy);
        entityData.set(QZ, (float) b.qz); entityData.set(QW, (float) b.qw);
        entityData.set(STEER, (float) sim.steerAngle);
        entityData.set(SPIN, (float) sim.spinAccum);
    }

    // --------------------------------------------------------------- клиент
    @Override
    public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps) {
        if (level().isClientSide) { lerpX = x; lerpY = y; lerpZ = z; lerpSteps = 2; }
        else super.lerpTo(x, y, z, yRot, xRot, steps);
    }

    private void clientTick() {
        if (lerpSteps > 0) {
            setPos(getX() + (lerpX - getX()) / lerpSteps, getY() + (lerpY - getY()) / lerpSteps,
                    getZ() + (lerpZ - getZ()) / lerpSteps);
            lerpSteps--;
        }
        prevQ.set(curQ);
        float x = entityData.get(QX), y = entityData.get(QY), z = entityData.get(QZ), w = entityData.get(QW);
        if (x * x + y * y + z * z + w * w < 0.5f) curQ.identity(); else curQ.set(x, y, z, w).normalize();
        prevSteer = steer; steer = entityData.get(STEER);
        float raw = entityData.get(SPIN);
        double d = raw - lastRawSpin;
        while (d > Math.PI) d -= 2 * Math.PI;
        while (d < -Math.PI) d += 2 * Math.PI;
        lastRawSpin = raw; prevSpin = spin; spin += (float) d;
    }

    public Quaternionf getRenderQuat(float pt) {
        if (level().isClientSide) return new Quaternionf(prevQ).slerp(curQ, pt);
        float x = entityData.get(QX), y = entityData.get(QY), z = entityData.get(QZ), w = entityData.get(QW);
        if (x * x + y * y + z * z + w * w < 0.5f) return new Quaternionf();
        return new Quaternionf(x, y, z, w).normalize();
    }
    public float getRenderSteer(float pt) { return Mth.lerp(pt, prevSteer, steer); }
    public float getRenderSpin(float pt) { return Mth.lerp(pt, prevSpin, spin); }

    // ---------------------------------------------------------------- земля
    private final class LevelProbe implements GroundProbe {
        private double grip = 1.0;

        @Override
        public double cast(double ox, double oy, double oz, double dx, double dy, double dz, double maxLen) {
            Vec3 from = new Vec3(ox, oy, oz);
            Vec3 to = new Vec3(ox + dx * maxLen, oy + dy * maxLen, oz + dz * maxLen);
            BlockHitResult r = level().clip(new ClipContext(from, to, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, VehicleEntity.this));
            if (r.getType() == HitResult.Type.MISS) return -1;
            float friction = level().getBlockState(r.getBlockPos()).getBlock().getFriction();
            grip = friction <= 0.6f ? 1.0 : Math.max(0.15, 1.0 - (friction - 0.6) / 0.38 * 0.85);
            return from.distanceTo(r.getLocation());
        }

        @Override
        public double grip() { return grip; }
    }
}
