package dev.physx.core.vehicle;

/** Ядро симуляции машины: подвеска, шины (Magic Formula + круг трения), трансмиссия, аэродинамика. */
public final class VehicleSim {
    public final VehicleSpec spec;
    public final RigidBody body = new RigidBody();
    public final Wheel[] wheels = new Wheel[4];
    public final Drivetrain drivetrain;
    public double steerAngle, spinAccum;

    private final double[] s = new double[3], p = new double[3], up = new double[3], fw = new double[3],
            h = new double[3], vl = new double[3], fl = new double[3];
    private static final double G = 9.81, RHO = 1.225;

    public VehicleSim(VehicleSpec spec) {
        this.spec = spec;
        this.drivetrain = spec.drivetrain;
        body.mass = spec.mass; body.ix = spec.ix; body.iy = spec.iy; body.iz = spec.iz;
        for (int i = 0; i < 4; i++) {
            Wheel w = new Wheel();
            boolean front = i < 2, left = (i % 2) == 0;
            w.lx = left ? spec.halfTrack : -spec.halfTrack;
            w.lz = front ? spec.halfWheelbase : -spec.halfWheelbase;
            w.ly = spec.mountY;
            w.radius = spec.wheelRadius; w.inertia = spec.wheelInertia;
            w.springK = spec.springK; w.damperC = spec.damperC; w.maxLen = spec.maxLen; w.bumpLen = spec.bumpLen;
            w.mu = spec.mu; w.len = spec.maxLen;
            w.steerFactor = front ? 1 : 0; w.driveFactor = front ? 0 : 0.5;
            w.brakeFactor = 1; w.handbrakeFactor = front ? 0 : 1;
            wheels[i] = w;
        }
    }

    public double forwardSpeed() {
        body.toWorld(0, 0, 1, fw);
        return body.vx * fw[0] + body.vy * fw[1] + body.vz * fw[2];
    }

    private static double mf(double b, double c, double x) {
        double bx = b * x;
        return Math.sin(c * Math.atan(bx));
    }

    public void step(double dt, VehicleInput in, GroundProbe probe) {
        RigidBody B = body;
        double fwdSpeed = forwardSpeed();
        double speed = Math.sqrt(B.vx * B.vx + B.vy * B.vy + B.vz * B.vz);

        // --- управление ---
        double thr = 0, brake = 0, t = in.throttle;
        if (in.parked) brake = 1;
        else if (t > 0.01) { if (fwdSpeed < -1.0) brake = t; else { thr = t; drivetrain.reverse = false; } }
        else if (t < -0.01) { if (fwdSpeed > 1.0) brake = -t; else { thr = -t; drivetrain.reverse = true; } }
        double lim = 2 * spec.halfWheelbase * 1.3 * spec.mu * G / Math.max(speed * speed, 1.0);
        double maxSteer = Math.max(spec.steerHigh, Math.min(spec.steerLow, lim));
        double target = in.steer * maxSteer;
        double rate = (Math.abs(target) < Math.abs(steerAngle) ? 3.0 : 1.8) * dt;
        steerAngle += Math.max(-rate, Math.min(rate, target - steerAngle));

        // --- антибуксовка (можно выключить для дрифта) ---
        if (spec.tractionControl && thr > 0) {
            double ms = 0;
            for (Wheel w : wheels) if (w.driveFactor > 0) ms = Math.max(ms, w.slipRatio);
            thr *= Math.max(0.2, Math.min(1.0, 1.0 - (ms - 0.15) * 5.0));
        }
        // --- трансмиссия ---
        double sumOmega = 0, nDriven = 0;
        for (Wheel w : wheels) if (w.driveFactor > 0) { sumOmega += w.omega; nDriven++; }
        double driveTotal = drivetrain.update(thr, sumOmega / nDriven, dt);

        B.toWorld(0, 1, 0, up);
        double fx = 0, fy = -G * B.mass, fz = 0, tx = 0, ty = 0, tz = 0;
        double meff = B.mass / 4.0;
        boolean flipped = up[1] < 0.1;
        double omegaSum = 0;

        for (Wheel w : wheels) {
            B.toWorld(w.lx, w.ly, w.lz, p);
            double ox = B.px + p[0], oy = B.py + p[1], oz = B.pz + p[2];
            double dx = -up[0], dy = -up[1], dz = -up[2];
            double hit = probe.cast(ox, oy, oz, dx, dy, dz, w.maxLen + w.radius);
            if (hit >= 0 && hit < 0.02) hit = -1; // луч начался внутри блока: игнорируем
            w.grounded = hit >= 0;
            double len = w.grounded ? Math.max(0, hit - w.radius) : w.maxLen;
            double cv = (w.len - len) / dt;
            w.len = len;
            double load = 0;
            if (w.grounded) {
                load = w.springK * (w.maxLen - len) + w.damperC * cv;
                if (len < w.bumpLen) load += w.springK * 5 * (w.bumpLen - len);
                if (load < 0) load = 0;
                double cap = 4.0 * spec.mass * G / 4.0; // не катапультируем машину на бордюрах
                if (load > cap) load = cap;
            }
            w.load = load;
            double drive = driveTotal * w.driveFactor;
            double brakeT = (brake * spec.maxBrakeTorque * w.brakeFactor)
                    + (in.handbrake ? spec.handbrakeTorque * w.handbrakeFactor : 0);

            double om = w.omega + drive / w.inertia * dt;
            if (brakeT > 0) {
                double tb = Math.min(brakeT, Math.abs(om) * w.inertia / dt);
                om -= Math.signum(om) * tb / w.inertia * dt;
            }

            if (w.grounded && !flipped) {
                // подвеска вдоль оси корпуса
                double sx = up[0] * load, sy = up[1] * load, sz = up[2] * load;
                fx += sx; fy += sy; fz += sz;
                tx += p[1] * sz - p[2] * sy; ty += p[2] * sx - p[0] * sz; tz += p[0] * sy - p[1] * sx;

                double cx = p[0] + dx * hit, cy = p[1] + dy * hit, cz = p[2] + dz * hit;
                double vcx = B.vx + (B.wy * cz - B.wz * cy);
                double vcz = B.vz + (B.wx * cy - B.wy * cx);
                double a = steerAngle * w.steerFactor;
                B.toWorld(Math.sin(a), 0, Math.cos(a), h);
                double hn = Math.hypot(h[0], h[2]);
                double hx = h[0] / hn, hz = h[2] / hn, sdx = hz, sdz = -hx;
                double vlong = vcx * hx + vcz * hz, vlat = vcx * sdx + vcz * sdz;

                double mu = w.mu * probe.grip();
                double kappa = (om * w.radius - vlong) / Math.max(Math.abs(vlong), 1.5);
                double alpha = Math.atan2(vlat, Math.abs(vlong) + 0.8);
                double fxn = mf(10, 1.65, kappa), fyn = -mf(10, 1.4, alpha);
                double mag = Math.hypot(fxn, fyn);
                if (mag > 1) { fxn /= mag; fyn /= mag; }
                double Fx = fxn * mu * load, Fy = fyn * mu * load;

                double d = om * w.radius - vlong;
                double closing = w.radius * w.radius / w.inertia + 1.0 / meff;
                double fxCap = Math.abs(d) / (dt * closing);
                if (Math.abs(Fx) > fxCap) Fx = Math.signum(Fx) * fxCap;
                double fyCap = meff * Math.abs(vlat) / dt;
                if (Math.abs(Fy) > fyCap) Fy = Math.signum(Fy) * fyCap;
                om -= Fx * w.radius * dt / w.inertia;
                w.slipRatio = (om * w.radius - vlong) / Math.max(Math.abs(vlong), 1.5);
                Fx -= spec.rollingResistance * load * Math.max(-1, Math.min(1, vlong / 0.5));

                w.slipAngle = alpha;
                double Fwx = Fx * hx + Fy * sdx, Fwz = Fx * hz + Fy * sdz;
                fx += Fwx; fz += Fwz;
                tx += cy * Fwz - cz * 0; // Fwy = 0
                ty += cz * Fwx - cx * Fwz;
                tz += cx * 0 - cy * Fwx;
            }
            if (Math.abs(om) > 700) om = Math.signum(om) * 700;
            w.omega = om;
            w.spin += om * dt;
            omegaSum += om;
        }
        spinAccum = (spinAccum + omegaSum / 4.0 * dt) % (2 * Math.PI);

        // --- аэродинамика (в осях корпуса) ---
        B.toLocal(B.vx, B.vy, B.vz, vl);
        double dragK = 0.5 * RHO * spec.cd * spec.frontalArea;
        double sideK = 0.5 * RHO * spec.sideCd * spec.sideArea;
        double lfx = -sideK * Math.abs(vl[0]) * vl[0];
        double lfz = -dragK * Math.abs(vl[2]) * vl[2];
        double lfy = -0.5 * RHO * spec.downforceCoef * vl[2] * vl[2];
        double ltY = spec.aeroCenterZ * lfx;
        B.toWorld(lfx, lfy, lfz, fl);
        fx += fl[0]; fy += fl[1]; fz += fl[2];
        B.toWorld(0, ltY, 0, fl);
        tx += fl[0]; ty += fl[1]; tz += fl[2];

        B.integrate(fx, fy, fz, tx, ty, tz, dt, s);
    }
}
