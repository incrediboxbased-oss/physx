package dev.physx.core.vehicle;

/** Параметры машины. Позже будут читаться из JSON датапака. */
public final class VehicleSpec {
    public double mass = 1200, ix = 1796, iy = 2000, iz = 596;
    public double frontAxleZ = 1.3, rearAxleZ = -1.3, halfTrack = 0.8, mountY = 0.25;
    public double wheelRadius = 0.34, wheelInertia = 1.5;
    public double springK = 35000, damperC = 3200, maxLen = 0.5, bumpLen = 0.08;
    public double maxBrakeTorque = 1300, handbrakeTorque = 2200;
    public double steerLow = 0.55, steerHigh = 0.06, steerSpeedRef = 18;
    public double mu = 1.15;
    public double cd = 0.32, frontalArea = 2.2, downforceCoef = 0.15, sideCd = 1.0, sideArea = 5.0, aeroCenterZ = -0.3;
    public boolean tractionControl = true;
    public double rollingResistance = 0.015;
    public final Drivetrain drivetrain = new Drivetrain();

    // оболочка корпуса: ориентированный бокс (OBB) в осях корпуса, относительно центра масс
    public double hullHx = 0.95, hullHy = 0.675, hullHz = 2.2, hullCy = 0.719, hullCz = 0;
    // контакт со ступеньками и стенами
    public double contactK = 8.0e5, contactC = 20000, contactMu = 0.4, contactMaxForce = 400000;
    /** Препятствия ниже (уровень земли под колёсами + stepHeight) машина не считает стеной, а наезжает на них. */
    public double stepHeight = 1.15;
    /** Силы подъёма в долях веса машины; предел силы подвески в долях статической нагрузки колеса. */
    public double stepForceG = 1.0, climbAssistG = 0.45, suspCapFactor = 2.5;
    /** Как быстро (м/с) "земля" под колесом может подниматься при наезде на ступеньку. */
    public double groundRiseRate = 3.5;
    /** Подъём начала луча колеса: колесо видит ступеньки выше своей оси. */
    public double rayLift = 0.5, stepLead = 0.28;

    public static VehicleSpec sportsCar() { return new VehicleSpec(); }

    /** Chevrolet K5 Blazer 1978: 2 т, V8, 4-ступенчатая коробка, шины 0.42 м. Начало координат = центр масс. */
    public static VehicleSpec blazer() {
        VehicleSpec s = new VehicleSpec();
        s.mass = 2000; s.ix = 4370; s.iy = 4500; s.iz = 1207;
        s.frontAxleZ = 1.286; s.rearAxleZ = -1.50; s.halfTrack = 0.906; s.mountY = 0.0;
        s.wheelRadius = 0.42; s.wheelInertia = 3.5;
        s.springK = 65000; s.damperC = 6500; s.maxLen = 0.5; s.bumpLen = 0.08;
        s.maxBrakeTorque = 2200; s.handbrakeTorque = 3000;
        s.steerLow = 0.55; s.steerHigh = 0.06; s.mu = 1.1;
        s.cd = 0.45; s.frontalArea = 2.9; s.downforceCoef = 0.0; s.sideCd = 1.1; s.sideArea = 7.0; s.aeroCenterZ = -0.3;
        s.hullHx = 1.0; s.hullHy = 0.80; s.hullHz = 2.41; s.hullCy = 0.355; s.hullCz = -0.23;
        Drivetrain d = s.drivetrain;
        d.rpmPts = new double[]{0, 1000, 2000, 3000, 4000, 5000, 6000, 7000};
        d.nmPts = new double[]{200, 280, 340, 380, 370, 330, 260, 180};
        d.idle = 700; d.redline = 5500; d.launchRpm = 2000;
        d.gears = new double[]{2.8, 1.7, 1.0, 0.75}; d.reverseRatio = -2.4; d.finalDrive = 3.73; d.engineBrakeNm = 110;
        return s;
    }
}
