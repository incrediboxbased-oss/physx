import dev.physx.core.softbody.SoftBody;
public class CrashTest {
    public static void main(String[] a) {
        int nx=5, ny=3, nz=3; double sp=1.0;
        SoftBody b = new SoftBody(nx*ny*nz, 2000);
        int[][][] id = new int[nx][ny][nz];
        for (int i=0;i<nx;i++) for (int j=0;j<ny;j++) for (int l=0;l<nz;l++)
            id[i][j][l] = b.addNode(i*sp, 0.3+j*0.6, l*sp, 1200.0/(nx*ny*nz));
        int N = b.nodeCount();
        for (int p=0;p<N;p++) for (int q=p+1;q<N;q++) {
            double d = Math.sqrt(Math.pow(b.px[p]-b.px[q],2)+Math.pow(b.py[p]-b.py[q],2)+Math.pow(b.pz[p]-b.pz[q],2));
            if (d < 1.75) b.addBeam(p,q, 4e5, 900, 0.01, 0.6);
        }
        double v0 = 20; for (int i=0;i<N;i++) b.vx[i] = v0;
        b.wallX = 12;
        double front0 = b.px[id[nx-1][0][0]];
        long t0 = System.nanoTime(); int steps = 0;
        for (double t=0; t<1.0; t+=0.0005) { b.step(0.0005); steps++; }
        double ms = (System.nanoTime()-t0)/1e6;
        double crush = (12 - (front0)) ; // отложенная оценка ниже
        double minX=1e9, maxX=-1e9; for (int i=0;i<N;i++){minX=Math.min(minX,b.px[i]);maxX=Math.max(maxX,b.px[i]);}
        System.out.printf("nodes=%d beams=%d%n", N, b.beamCount);
        System.out.printf("длина машины: было 4.00 м, стало %.2f м%n", maxX-minX);
        System.out.printf("остаточная деформация балок: %.2f%%%n", b.permanentDeformation()*100);
        System.out.printf("1 с симуляции = %.1f мс CPU (%d подшагов)%n", ms, steps);
    }
}
