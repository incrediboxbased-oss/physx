import dev.physx.core.vehicle.*;
import java.util.*;
public class WorldTest {
    static final List<double[]> BOX = new ArrayList<>();
    static boolean inside(double x,double y,double z){ for(double[] b:BOX) if(x>b[0]&&x<b[3]&&y>b[1]&&y<b[4]&&z>b[2]&&z<b[5]) return true; return false; }
    static final GroundProbe W = new GroundProbe(){
        public double cast(double ox,double oy,double oz,double dx,double dy,double dz,double m){
            for(double d=0; d<=m; d+=0.01) if(inside(ox+dx*d,oy+dy*d,oz+dz*d)) return d; return -1; }
        public double grip(){return 1;}
        public boolean penetration(double x,double y,double z,double[] o){
            for(double[] b:BOX) if(x>b[0]&&x<b[3]&&y>b[1]&&y<b[4]&&z>b[2]&&z<b[5]){
                double[] ds={x-b[0],b[3]-x,y-b[1],b[4]-y,z-b[2],b[5]-z}; int k=0; for(int i=1;i<6;i++) if(ds[i]<ds[k]) k=i;
                o[0]=o[1]=o[2]=0; switch(k){case 0:o[0]=-1;break;case 1:o[0]=1;break;case 2:o[1]=-1;break;case 3:o[1]=1;break;case 4:o[2]=-1;break;default:o[2]=1;}
                o[3]=ds[k]; return true; } return false; } };
    static void run(String name,double stepH,double stepZ,double kmh){
        BOX.clear(); BOX.add(new double[]{-1000,-10,-1000,1000,0,1000});
        if(stepH>0) BOX.add(new double[]{-50,0,stepZ,50,stepH,stepZ+200});
        VehicleSim s=new VehicleSim(VehicleSpec.sportsCar()); s.body.py=0.55; double dt=1/160.0; VehicleInput in=new VehicleInput();
        for(int i=0;i<320;i++) s.step(dt,in,W);
        double v0=kmh/3.6; s.body.vz=v0; for(Wheel w:s.wheels) w.omega=v0/0.34;
        in.throttle=0.4; double maxYaw=0,maxImp=0,maxPen=0; boolean nan=false;
        for(int i=0;i<160*8;i++){ s.step(dt,in,W); maxYaw=Math.max(maxYaw,Math.abs(s.body.wy)); maxImp=Math.max(maxImp,s.impactSpeed); s.impactSpeed=0;
            if(Double.isNaN(s.body.px)) nan=true; }
        System.out.printf("%-22s z=%6.1f высота ЦМ=%.2f v=%5.1f км/ч макс.рыскание=%.2f рад/с макс.удар=%.1f м/с %s%n",name,s.body.pz,s.body.py,s.forwardSpeed()*3.6,maxYaw,maxImp,nan?"NaN!":"");
    }
    public static void main(String[] a){
        run("ровно 40 км/ч",0,0,40);
        run("полублок 0.5, 40км/ч",0.5,15,40);
        run("полублок 0.5, 15км/ч",0.5,8,15);
        run("блок 1.0, 40 км/ч",1.0,15,40);
        run("блок 1.0, 15 км/ч",1.0,8,15);
        run("стена 3.0, 70 км/ч",3.0,30,70);
    }
}
