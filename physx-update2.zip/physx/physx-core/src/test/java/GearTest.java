import dev.physx.core.vehicle.*;
public class GearTest { public static void main(String[] a){
  WorldTest.BOX.clear(); WorldTest.BOX.add(new double[]{-1000,-10,-1000,1000,0,1000});
  VehicleSpec sp=VehicleSpec.sportsCar(); sp.drivetrain.setManual(true); VehicleSim s=new VehicleSim(sp);
  s.body.py=0.55; double dt=1/160.0; VehicleInput in=new VehicleInput();
  for(int i=0;i<320;i++) s.step(dt,in,WorldTest.W);
  in.throttle=1; int ups=0;
  for(int i=0;i<160*14;i++){ s.step(dt,in,WorldTest.W);
    if(i%320==0) System.out.printf("МКПП t=%2.0f v=%5.1f км/ч передача=%d rpm=%4.0f%n", i*dt, s.forwardSpeed()*3.6, sp.drivetrain.gear, sp.drivetrain.rpm);
    if(sp.drivetrain.rpm>6200 && sp.drivetrain.gear<5 && ups<20){ sp.drivetrain.shiftUp(); ups++; } }
  System.out.println("--- ручник на скорости (поворот) ---");
  sp.drivetrain.setManual(false); in.throttle=0.3; in.steer=0.6; in.handbrake=true;
  for(int i=0;i<160*2;i++){ s.step(dt,in,WorldTest.W); if(i%80==0) System.out.printf("v=%5.1f рыскание=%.2f рад/с угол заноса задних=%.2f%n", s.forwardSpeed()*3.6, s.body.wy, s.wheels[2].slipAngle); }
}}
