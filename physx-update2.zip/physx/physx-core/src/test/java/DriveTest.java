import dev.physx.core.vehicle.*;
public class DriveTest {
    static final GroundProbe FLAT = new GroundProbe() {
        public double cast(double ox,double oy,double oz,double dx,double dy,double dz,double max){
            if (dy >= -1e-6) return -1; double d = oy / -dy; return (d>=0 && d<=max)? d : -1; }
        public double grip(){ return 1.0; }
    };
    public static void main(String[] a){
        VehicleSim s = new VehicleSim(VehicleSpec.sportsCar());
        s.body.py = 0.9; double dt = 1/80.0; VehicleInput in = new VehicleInput();
        for (int i=0;i<160;i++) s.step(dt,in,FLAT);   // осесть
        System.out.printf("осела: высота ЦМ %.3f м, ход подвески %.3f%n", s.body.py, s.wheels[0].len);
        in.throttle = 1;
        double t100=-1;
        for (int i=0;i<80*12;i++){ s.step(dt,in,FLAT); double v=s.forwardSpeed()*3.6;
            if (t100<0 && v>=100) t100=i*dt;
            if (i%160==0) System.out.printf("t=%2.0f с v=%5.1f км/ч передача=%d rpm=%4.0f%n", i*dt, v, s.drivetrain.gear, s.drivetrain.rpm); }
        System.out.printf("0-100: %.1f с%n", t100);
        in.throttle = -1; double v0=s.forwardSpeed(); int n=0;
        while (s.forwardSpeed()>1 && n<80*20){ s.step(dt,in,FLAT); n++; }
        System.out.printf("торможение с %.0f км/ч: %.1f с%n", v0*3.6, n*dt);
        // поворот на 60 км/ч
        VehicleSim c = new VehicleSim(VehicleSpec.sportsCar()); c.body.py=0.9; VehicleInput i2 = new VehicleInput();
        for (int i=0;i<160;i++) c.step(dt,i2,FLAT);
        i2.throttle=0.5; while (c.forwardSpeed()<16.7) c.step(dt,i2,FLAT);
        i2.throttle=0.25; i2.steer=1; double maxLat=0, maxRoll=0;
        for (int i=0;i<80*4;i++){ c.step(dt,i2,FLAT);
            double lat=Math.abs(c.body.vx*0); }
        double[] up=new double[3]; c.body.toWorld(1,0,0,up);
        System.out.printf("поворот: скорость %.0f км/ч, угловая скорость рыскания %.2f рад/с, крен(x.y)=%.3f%n", c.forwardSpeed()*3.6, c.body.wy, up[1]);
        boolean nan = Double.isNaN(c.body.px)||Double.isNaN(s.body.px);
        System.out.println(nan? "ЕСТЬ NaN!":"NaN нет, симуляция стабильна");
    }
}
