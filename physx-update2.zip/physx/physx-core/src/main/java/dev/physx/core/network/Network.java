package dev.physx.core.network;

import dev.physx.core.entity.VehicleEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class Network {
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar r = event.registrar("1");
        r.playToServer(InputPayload.TYPE, InputPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            Player p = ctx.player();
            if (p != null && p.getVehicle() instanceof VehicleEntity car) car.applyKeys(payload, p);
        }));
    }
    private Network() {}
}
