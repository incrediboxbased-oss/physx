package dev.physx.core.vehicle;

public final class Wheel {
    public double lx, ly, lz;              // точка крепления относительно центра масс
    public double radius, inertia, springK, damperC, maxLen, bumpLen, mu;
    public double steerFactor, driveFactor, brakeFactor, handbrakeFactor;
    // состояние
    public double omega, len, spin, load, slipRatio, slipAngle;
    public boolean grounded;
}
