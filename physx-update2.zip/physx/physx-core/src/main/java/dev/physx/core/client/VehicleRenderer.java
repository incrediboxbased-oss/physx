package dev.physx.core.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.physx.core.entity.VehicleEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * Модель машины из параллелепипедов: 4.4 x 1.9 x 1.9 м (выше игрока).
 * Кабина открытая (рама и стойки), чтобы из первого лица всё было видно.
 * Координаты модели: y = 0 это земля при стоянке, +x влево, +z вперёд.
 */
public class VehicleRenderer extends EntityRenderer<VehicleEntity> {
    private static final ResourceLocation WHITE = ResourceLocation.withDefaultNamespace("textures/block/white_concrete.png");
    private static final float GROUND = -0.506f; // земля относительно центра масс

    public VehicleRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override
    public ResourceLocation getTextureLocation(VehicleEntity e) { return WHITE; }

    @Override
    public void render(VehicleEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        ps.translate(0, VehicleEntity.COM_Y, 0);
        ps.mulPose(e.getRenderQuat(pt));
        ps.translate(0, GROUND, 0);

        VertexConsumer c = buf.getBuffer(RenderType.entityCutoutNoCull(WHITE));
        PoseStack.Pose p = ps.last();
        final int BR = LightTexture.FULL_BRIGHT;

        // --- кузов (красный) ---
        int[] R = {200, 30, 30};
        box(p, c, -0.95f, 0.50f, 0.95f, 0.95f, 1.00f, 2.20f, light, R);          // капот
        box(p, c, -0.95f, 0.50f, -2.20f, 0.95f, 1.05f, -1.25f, light, R);        // багажник
        box(p, c, -0.95f, 0.50f, -1.25f, -0.85f, 1.20f, 0.95f, light, R);        // правая дверь/порог
        box(p, c, 0.85f, 0.50f, -1.25f, 0.95f, 1.20f, 0.95f, light, R);          // левая дверь/порог
        box(p, c, -0.95f, 0.50f, -1.25f, 0.95f, 0.58f, 0.95f, light, R);         // пол
        box(p, c, -0.95f, 0.58f, 0.60f, 0.95f, 1.00f, 0.95f, light, R);          // торпедо
        // --- стойки и крыша ---
        int[] D = {40, 40, 45};
        box(p, c, -0.95f, 1.00f, 0.80f, -0.85f, 1.90f, 0.95f, light, D);         // A-стойки
        box(p, c, 0.85f, 1.00f, 0.80f, 0.95f, 1.90f, 0.95f, light, D);
        box(p, c, -0.95f, 1.20f, -0.12f, -0.85f, 1.90f, -0.02f, light, D);       // B-стойки
        box(p, c, 0.85f, 1.20f, -0.12f, 0.95f, 1.90f, -0.02f, light, D);
        box(p, c, -0.95f, 1.05f, -1.35f, -0.85f, 1.90f, -1.20f, light, D);       // C-стойки
        box(p, c, 0.85f, 1.05f, -1.35f, 0.95f, 1.90f, -1.20f, light, D);
        box(p, c, -0.95f, 1.84f, -1.35f, 0.95f, 1.92f, 0.95f, light, R);         // крыша
        // --- сиденья и руль ---
        int[] S = {35, 35, 40};
        box(p, c, 0.05f, 0.58f, -0.55f, 0.65f, 0.64f, 0.10f, light, S);          // сиденье водителя
        box(p, c, 0.05f, 0.64f, -0.62f, 0.65f, 1.25f, -0.52f, light, S);         // спинка
        box(p, c, -0.65f, 0.58f, -0.55f, -0.05f, 0.64f, 0.10f, light, S);        // пассажир
        box(p, c, -0.65f, 0.64f, -0.62f, -0.05f, 1.25f, -0.52f, light, S);
        box(p, c, 0.20f, 0.95f, 0.48f, 0.50f, 1.05f, 0.56f, light, S);           // руль
        // --- бамперы, фары ---
        int[] B = {60, 60, 65};
        box(p, c, -0.95f, 0.50f, 2.20f, 0.95f, 0.75f, 2.32f, light, B);
        box(p, c, -0.95f, 0.50f, -2.32f, 0.95f, 0.75f, -2.20f, light, B);
        int[] H = {255, 245, 180};
        box(p, c, 0.55f, 0.78f, 2.19f, 0.88f, 0.92f, 2.23f, BR, H);
        box(p, c, -0.88f, 0.78f, 2.19f, -0.55f, 0.92f, 2.23f, BR, H);
        int[] T = {255, 20, 20};
        box(p, c, 0.55f, 0.78f, -2.23f, 0.88f, 0.92f, -2.19f, BR, T);
        box(p, c, -0.88f, 0.78f, -2.23f, -0.55f, 0.92f, -2.19f, BR, T);

        // --- колёса: шина + диск, вращаются, передние поворачиваются ---
        float steer = e.getRenderSteer(pt), spin = e.getRenderSpin(pt);
        int[] K = {20, 20, 22}, G = {170, 170, 180};
        for (int i = 0; i < 4; i++) {
            boolean front = i < 2, left = (i % 2) == 0;
            ps.pushPose();
            ps.translate(left ? 0.8f : -0.8f, 0.34f, front ? 1.3f : -1.3f);
            if (front) ps.mulPose(Axis.YP.rotation(steer));
            ps.mulPose(Axis.XP.rotation(spin));
            PoseStack.Pose wp = ps.last();
            box(wp, c, -0.14f, -0.34f, -0.34f, 0.14f, 0.34f, 0.34f, light, K);
            float o = left ? 0.141f : -0.141f;
            box(wp, c, Math.min(o, 0f), -0.20f, -0.20f, Math.max(o, 0f), 0.20f, 0.20f, light, G);
            ps.popPose();
        }
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    private static void box(PoseStack.Pose p, VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1,
                            int l, int[] col) {
        int r = col[0], g = col[1], b = col[2];
        quad(p, c, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, 0, 1, 0, l, r, g, b);
        quad(p, c, x0, y0, z1, x0, y0, z0, x1, y0, z0, x1, y0, z1, 0, -1, 0, l, r, g, b);
        quad(p, c, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, 1, 0, 0, l, r, g, b);
        quad(p, c, x0, y0, z1, x0, y1, z1, x0, y1, z0, x0, y0, z0, -1, 0, 0, l, r, g, b);
        quad(p, c, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1, l, r, g, b);
        quad(p, c, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0, 0, -1, l, r, g, b);
    }

    private static void quad(PoseStack.Pose p, VertexConsumer c,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float nx, float ny, float nz, int l, int r, int g, int b) {
        v(p, c, ax, ay, az, 0, 0, nx, ny, nz, l, r, g, b);
        v(p, c, bx, by, bz, 0, 1, nx, ny, nz, l, r, g, b);
        v(p, c, cx, cy, cz, 1, 1, nx, ny, nz, l, r, g, b);
        v(p, c, dx, dy, dz, 1, 0, nx, ny, nz, l, r, g, b);
    }

    private static void v(PoseStack.Pose p, VertexConsumer c, float x, float y, float z, float u, float vv,
                          float nx, float ny, float nz, int l, int r, int g, int b) {
        c.addVertex(p, x, y, z).setColor(r, g, b, 255).setUv(u, vv)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(l).setNormal(p, nx, ny, nz);
    }
}
