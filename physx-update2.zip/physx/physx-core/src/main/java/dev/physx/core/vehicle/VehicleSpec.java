package dev.physx.core.vehicle;

/** Параметры машины. Позже будут читаться из JSON датапака. */
public final class VehicleSpec {
    public double mass = 1200, ix = 1796, iy = 2000, iz = 596;
    public double halfWheelbase = 1.3, halfTrack = 0.8, mountY = 0.25;
    public double wheelRadius = 0.34, wheelInertia = 1.5;
    public double springK = 35000, damperC = 3200, maxLen = 0.5, bumpLen = 0.08;
    public double maxBrakeTorque = 1300, handbrakeTorque = 2200;
    public double steerLow = 0.55, steerHigh = 0.06, steerSpeedRef = 18;
    public double mu = 1.15;
    public double cd = 0.32, frontalArea = 2.2, downforceCoef = 0.15, sideCd = 1.0, sideArea = 5.0, aeroCenterZ = -0.3;
    public boolean tractionControl = true;
    public double rollingResistance = 0.015;
    public final Drivetrain drivetrain = new Drivetrain();

    // контакт корпуса с блоками (штрафные пружины в точках оболочки)
    public double contactK = 3.0e5, contactC = 5000, contactMu = 0.4, contactMaxForce = 250000;
    public double stepLead = 0.28; // вынос луча колеса вперёд: колесо "видит" ступеньку заранее
    public double[] hullX, hullY, hullZ; // точки оболочки в осях корпуса (относительно центра масс)

    public VehicleSpec() {
        // днище ~0.55 м над землёй, крыша ~1.9 м, длина 4.4 м, ширина 1.9 м
        double[] ys = {0.044, 0.75, 1.394};
        double hx = 0.95, hz = 2.2;
        double[][] xz = {{hx, hz}, {-hx, hz}, {hx, -hz}, {-hx, -hz}, {hx, 0}, {-hx, 0}, {0, hz}, {0, -hz}};
        int n = ys.length * xz.length + 1;
        hullX = new double[n]; hullY = new double[n]; hullZ = new double[n];
        int i = 0;
        for (double y : ys) for (double[] c : xz) { hullX[i] = c[0]; hullY[i] = y; hullZ[i] = c[1]; i++; }
        hullX[i] = 0; hullY[i] = ys[0]; hullZ[i] = 0;
    }

    public static VehicleSpec sportsCar() { return new VehicleSpec(); }
}
