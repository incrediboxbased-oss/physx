package dev.physx.core.vehicle;

public final class VehicleInput {
    /** -1..1: вперёд/назад. */ public double throttle;
    /** -1..1: положительное = влево. */ public double steer;
    public boolean handbrake;
    /** Машина без водителя: стояночный тормоз. */ public boolean parked;
}
