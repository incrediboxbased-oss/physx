package dev.physx.core;

import dev.physx.core.entity.VehicleEntity;
import dev.physx.core.item.TestCarItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModRegistry {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, PhysxCore.MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(PhysxCore.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<VehicleEntity>> TEST_CAR =
            ENTITIES.register("test_car", () -> EntityType.Builder.<VehicleEntity>of(VehicleEntity::new, MobCategory.MISC)
                    .sized(2.0F, 1.3F).clientTrackingRange(10).updateInterval(1).build("test_car"));

    public static final DeferredItem<TestCarItem> TEST_CAR_ITEM =
            ITEMS.register("test_car", () -> new TestCarItem(new Item.Properties().stacksTo(1)));

    private ModRegistry() {}
}
