package dev.physx.core.client;

import dev.physx.core.PhysxCore;
import dev.physx.core.entity.VehicleEntity;
import dev.physx.core.network.InputPayload;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = PhysxCore.MODID, value = Dist.CLIENT)
public final class ClientInput {
    private static boolean lastHand;

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !(mc.player.getVehicle() instanceof VehicleEntity)) { lastHand = false; return; }
        boolean hand = KeyBindings.HANDBRAKE.isDown();
        boolean up = false, down = false, box = false, tc = false;
        while (KeyBindings.GEAR_UP.consumeClick()) up = true;
        while (KeyBindings.GEAR_DOWN.consumeClick()) down = true;
        while (KeyBindings.TOGGLE_GEARBOX.consumeClick()) box = true;
        while (KeyBindings.TOGGLE_TC.consumeClick()) tc = true;
        if (hand != lastHand || up || down || box || tc) {
            lastHand = hand;
            PacketDistributor.sendToServer(new InputPayload(hand, up, down, box, tc));
        }
    }
    private ClientInput() {}
}
