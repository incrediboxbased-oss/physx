package dev.physx.core.vehicle;

/** Твёрдое тело: позиция центра масс, кватернион, скорости. Без аллокаций. */
public final class RigidBody {
    public double px, py, pz, vx, vy, vz, wx, wy, wz;
    public double qw = 1, qx, qy, qz;
    public double mass = 1000, ix = 1000, iy = 1000, iz = 1000;

    public void toWorld(double x, double y, double z, double[] o) {
        double tx = 2 * (qy * z - qz * y), ty = 2 * (qz * x - qx * z), tz = 2 * (qx * y - qy * x);
        o[0] = x + qw * tx + (qy * tz - qz * ty);
        o[1] = y + qw * ty + (qz * tx - qx * tz);
        o[2] = z + qw * tz + (qx * ty - qy * tx);
    }

    public void toLocal(double x, double y, double z, double[] o) {
        double cx = -qx, cy = -qy, cz = -qz;
        double tx = 2 * (cy * z - cz * y), ty = 2 * (cz * x - cx * z), tz = 2 * (cx * y - cy * x);
        o[0] = x + qw * tx + (cy * tz - cz * ty);
        o[1] = y + qw * ty + (cz * tx - cx * tz);
        o[2] = z + qw * tz + (cx * ty - cy * tx);
    }

    /** Силы и моменты в мировых осях. s - буфер из 3 double. */
    public void integrate(double fx, double fy, double fz, double tx, double ty, double tz, double dt, double[] s) {
        vx += fx / mass * dt; vy += fy / mass * dt; vz += fz / mass * dt;
        toLocal(wx, wy, wz, s); double lwx = s[0], lwy = s[1], lwz = s[2];
        toLocal(tx, ty, tz, s); double ltx = s[0], lty = s[1], ltz = s[2];
        lwx += (ltx - (iz - iy) * lwy * lwz) / ix * dt;
        lwy += (lty - (ix - iz) * lwz * lwx) / iy * dt;
        lwz += (ltz - (iy - ix) * lwx * lwy) / iz * dt;
        toWorld(lwx, lwy, lwz, s); wx = s[0]; wy = s[1]; wz = s[2];
        double h = 0.5 * dt;
        double nw = qw + h * (-wx * qx - wy * qy - wz * qz);
        double nx = qx + h * (wx * qw + wy * qz - wz * qy);
        double ny = qy + h * (wy * qw + wz * qx - wx * qz);
        double nz = qz + h * (wz * qw + wx * qy - wy * qx);
        double n = 1.0 / Math.sqrt(nw * nw + nx * nx + ny * ny + nz * nz);
        qw = nw * n; qx = nx * n; qy = ny * n; qz = nz * n;
        px += vx * dt; py += vy * dt; pz += vz * dt;
    }
}
