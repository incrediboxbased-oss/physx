package dev.physx.core.client;

import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

/** Клавиши машины. Переназначаются в Настройки -> Управление -> категория PhysX. */
public final class KeyBindings {
    public static final String CATEGORY = "key.categories.physx_core";
    public static final KeyMapping HANDBRAKE = new KeyMapping("key.physx_core.handbrake", GLFW.GLFW_KEY_SPACE, CATEGORY);
    public static final KeyMapping GEAR_UP = new KeyMapping("key.physx_core.gear_up", GLFW.GLFW_KEY_X, CATEGORY);
    public static final KeyMapping GEAR_DOWN = new KeyMapping("key.physx_core.gear_down", GLFW.GLFW_KEY_Z, CATEGORY);
    public static final KeyMapping TOGGLE_GEARBOX = new KeyMapping("key.physx_core.toggle_gearbox", GLFW.GLFW_KEY_G, CATEGORY);
    public static final KeyMapping TOGGLE_TC = new KeyMapping("key.physx_core.toggle_tc", GLFW.GLFW_KEY_V, CATEGORY);
    private KeyBindings() {}
}
