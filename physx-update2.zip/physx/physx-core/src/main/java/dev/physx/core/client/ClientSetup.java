package dev.physx.core.client;

import dev.physx.core.ModRegistry;
import dev.physx.core.PhysxCore;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

@EventBusSubscriber(modid = PhysxCore.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModRegistry.TEST_CAR.get(), VehicleRenderer::new);
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(KeyBindings.HANDBRAKE);
        e.register(KeyBindings.GEAR_UP);
        e.register(KeyBindings.GEAR_DOWN);
        e.register(KeyBindings.TOGGLE_GEARBOX);
        e.register(KeyBindings.TOGGLE_TC);
    }
}
