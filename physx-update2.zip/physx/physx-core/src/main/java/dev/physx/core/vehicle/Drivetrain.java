package dev.physx.core.vehicle;

/** Двигатель (кривая момента), сцепление, коробка (АКПП или МКПП), главная передача. */
public final class Drivetrain {
    public double[] rpmPts = {0, 1000, 2000, 3000, 4000, 5000, 6000, 7000};
    public double[] nmPts = {120, 140, 190, 230, 260, 270, 250, 200};
    public double idle = 900, redline = 6800, launchRpm = 2800;
    public double[] gears = {3.4, 2.0, 1.35, 1.0, 0.8};
    public double reverseRatio = -3.2, finalDrive = 3.4, efficiency = 0.9, engineBrakeNm = 90;

    public double rpm = idle;
    /** -1 = задняя, 0 = нейтраль, 1..N = передачи. */
    public int gear = 1;
    /** true = механика (ручное переключение), false = автомат. */
    public boolean manual;
    private double shiftTimer;

    private double curve(double r) {
        if (r <= rpmPts[0]) return nmPts[0];
        for (int i = 1; i < rpmPts.length; i++) {
            if (r <= rpmPts[i]) {
                double t = (r - rpmPts[i - 1]) / (rpmPts[i] - rpmPts[i - 1]);
                return nmPts[i - 1] + t * (nmPts[i] - nmPts[i - 1]);
            }
        }
        return nmPts[nmPts.length - 1];
    }

    public void shiftUp() { if (gear < gears.length) { gear++; shiftTimer = 0.25; } }
    public void shiftDown() { if (gear > -1) { gear--; shiftTimer = 0.25; } }

    /** Только для автомата: направление выбирается по нажатой клавише. */
    public void setReverseAuto(boolean reverse) {
        if (manual) return;
        if (reverse) gear = -1; else if (gear < 1) gear = 1;
    }

    public void setManual(boolean m) {
        manual = m;
        if (!m && gear == 0) gear = 1;
    }

    /** Суммарный момент на ведущих колёсах (Нм). */
    public double update(double throttle, double wheelOmega, double dt) {
        shiftTimer -= dt;
        if (gear == 0) { // нейтраль: двигатель свободно раскручивается
            double target = idle + throttle * (redline * 0.95 - idle);
            rpm += (target - rpm) * Math.min(1, dt * 8);
            return 0;
        }
        double ratio = gear < 0 ? reverseRatio : gears[gear - 1];
        double tot = ratio * finalDrive;
        double wheelRpm = Math.abs(wheelOmega * tot) * 60.0 / (2 * Math.PI);
        double engage = Math.min(1, Math.max(0, (wheelRpm - idle * 0.8) / (idle * 0.6)));
        double freeRev = idle + throttle * (launchRpm - idle);
        double target = Math.max(idle, engage * wheelRpm + (1 - engage) * Math.max(wheelRpm, freeRev));
        rpm += (target - rpm) * Math.min(1, dt * 15);
        if (rpm > redline + 300) rpm = redline + 300;

        if (!manual && gear >= 1 && shiftTimer <= 0) {
            if (rpm > redline * 0.88 && gear < gears.length) { gear++; shiftTimer = 0.35; }
            else if (gear > 1 && rpm < 2600
                    && wheelRpm * gears[gear - 2] / gears[gear - 1] < redline * 0.8) { gear--; shiftTimer = 0.2; }
        }

        if (shiftTimer > 0) return 0;
        if (throttle > 0.02) {
            double tq = rpm > redline ? 0 : curve(rpm) * throttle;
            return tq * tot * efficiency * (0.4 + 0.6 * engage);
        }
        double eb = engineBrakeNm * (rpm / redline) * Math.abs(tot) * engage;
        return -Math.signum(wheelOmega) * eb;
    }
}
