package dev.physx.core.item;

import dev.physx.core.ModRegistry;
import dev.physx.core.entity.VehicleEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class TestCarItem extends Item {
    public TestCarItem(Properties props) { super(props); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        VehicleEntity car = ModRegistry.TEST_CAR.get().create(level);
        if (car == null) return InteractionResult.FAIL;
        car.moveTo(pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5, ctx.getRotation(), 0);
        level.addFreshEntity(car);
        ctx.getItemInHand().consume(1, ctx.getPlayer());
        return InteractionResult.CONSUME;
    }
}
