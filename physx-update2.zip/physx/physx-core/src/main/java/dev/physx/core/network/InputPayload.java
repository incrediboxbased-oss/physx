package dev.physx.core.network;

import dev.physx.core.PhysxCore;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Состояние клавиш машины: клиент -> сервер. gearUp/gearDown/toggle* - одноразовые нажатия. */
public record InputPayload(boolean handbrake, boolean gearUp, boolean gearDown, boolean toggleBox, boolean toggleTc)
        implements CustomPacketPayload {

    public static final Type<InputPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(PhysxCore.MODID, "input"));

    public static final StreamCodec<FriendlyByteBuf, InputPayload> CODEC = StreamCodec.of(
            (buf, p) -> {
                int f = (p.handbrake ? 1 : 0) | (p.gearUp ? 2 : 0) | (p.gearDown ? 4 : 0)
                        | (p.toggleBox ? 8 : 0) | (p.toggleTc ? 16 : 0);
                buf.writeByte(f);
            },
            buf -> {
                int f = buf.readByte();
                return new InputPayload((f & 1) != 0, (f & 2) != 0, (f & 4) != 0, (f & 8) != 0, (f & 16) != 0);
            });

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
