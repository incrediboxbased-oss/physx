package dev.physx.core.softbody;

/** Мягкое тело в стиле BeamNG: узлы + балки с пластической деформацией. Без аллокаций в step(). */
public final class SoftBody {
    public final int n;
    public final double[] px, py, pz, vx, vy, vz, fx, fy, fz, mass;
    public int beamCount;
    public final int[] ba, bb;
    public final double[] rest, rest0, k, damp, yield, brk;
    public double gravity = 9.81, groundY = 0, groundFriction = 0.8;
    public double wallX = Double.POSITIVE_INFINITY; // тестовая стена
    private int nodes;

    public SoftBody(int maxNodes, int maxBeams) {
        n = maxNodes;
        px = new double[n]; py = new double[n]; pz = new double[n];
        vx = new double[n]; vy = new double[n]; vz = new double[n];
        fx = new double[n]; fy = new double[n]; fz = new double[n]; mass = new double[n];
        ba = new int[maxBeams]; bb = new int[maxBeams];
        rest = new double[maxBeams]; rest0 = new double[maxBeams];
        k = new double[maxBeams]; damp = new double[maxBeams];
        yield = new double[maxBeams]; brk = new double[maxBeams];
    }

    public int addNode(double x, double y, double z, double m) {
        px[nodes] = x; py[nodes] = y; pz[nodes] = z; mass[nodes] = m; return nodes++;
    }
    public int nodeCount() { return nodes; }

    public void addBeam(int a, int b, double stiff, double damping, double yieldStrain, double breakStrain) {
        int i = beamCount++;
        ba[i] = a; bb[i] = b;
        double dx = px[b]-px[a], dy = py[b]-py[a], dz = pz[b]-pz[a];
        rest[i] = rest0[i] = Math.sqrt(dx*dx+dy*dy+dz*dz);
        k[i] = stiff; damp[i] = damping; yield[i] = yieldStrain; brk[i] = breakStrain;
    }

    /** Один подшаг (semi-implicit Euler). dt ~ 0.0005 c. */
    public void step(double dt) {
        for (int i = 0; i < nodes; i++) { fx[i] = 0; fy[i] = -gravity * mass[i]; fz[i] = 0; }
        for (int i = 0; i < beamCount; i++) {
            if (k[i] == 0) continue;
            int a = ba[i], b = bb[i];
            double dx = px[b]-px[a], dy = py[b]-py[a], dz = pz[b]-pz[a];
            double len = Math.sqrt(dx*dx+dy*dy+dz*dz);
            if (len < 1e-9) continue;
            double inv = 1.0/len; dx *= inv; dy *= inv; dz *= inv;
            double strain = (len - rest[i]) / rest[i];
            // пластика: превысили предел упругости -> длина покоя «переезжает», балка остаётся погнутой
            double y = yield[i];
            if (strain > y) { rest[i] = len / (1 + y); strain = y; }
            else if (strain < -y) { rest[i] = len / (1 - y); strain = -y; }
            if (Math.abs((len - rest0[i]) / rest0[i]) > brk[i]) { k[i] = 0; continue; } // разрыв
            double rv = (vx[b]-vx[a])*dx + (vy[b]-vy[a])*dy + (vz[b]-vz[a])*dz;
            double f = k[i]*(len - rest[i]) + damp[i]*rv;
            fx[a] += f*dx; fy[a] += f*dy; fz[a] += f*dz;
            fx[b] -= f*dx; fy[b] -= f*dy; fz[b] -= f*dz;
        }
        for (int i = 0; i < nodes; i++) {
            vx[i] += fx[i]/mass[i]*dt; vy[i] += fy[i]/mass[i]*dt; vz[i] += fz[i]/mass[i]*dt;
            px[i] += vx[i]*dt; py[i] += vy[i]*dt; pz[i] += vz[i]*dt;
            if (py[i] < groundY) { // земля с трением
                py[i] = groundY; if (vy[i] < 0) vy[i] = 0;
                double s = Math.max(0, 1 - groundFriction*9.81*dt/Math.max(1e-6, Math.hypot(vx[i], vz[i])));
                vx[i] *= s; vz[i] *= s;
            }
            if (px[i] > wallX) { px[i] = wallX; if (vx[i] > 0) vx[i] = 0; }
        }
    }

    /** Суммарная остаточная деформация (средняя |rest-rest0|/rest0). */
    public double permanentDeformation() {
        double s = 0; for (int i = 0; i < beamCount; i++) s += Math.abs(rest[i]-rest0[i])/rest0[i];
        return s / Math.max(1, beamCount);
    }
}
