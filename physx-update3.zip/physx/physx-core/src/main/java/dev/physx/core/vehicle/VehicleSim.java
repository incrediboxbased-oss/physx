package dev.physx.core.vehicle;

/** Ядро симуляции машины: подвеска, шины (Magic Formula + круг трения), трансмиссия, аэродинамика. */
public final class VehicleSim {
    public final VehicleSpec spec;
    public final RigidBody body = new RigidBody();
    public final Wheel[] wheels = new Wheel[4];
    public final Drivetrain drivetrain;
    public double steerAngle, spinAccum, impactSpeed;

    private final double[] s = new double[3], p = new double[3], up = new double[3], fw = new double[3],
            h = new double[3], vl = new double[3], fl = new double[3],
            p2 = new double[3], hc = new double[3], ux = new double[3], uy = new double[3], uz = new double[3];
    private final double[] boxes = new double[7 * 600];
    private int boxCount;
    private double afx, afy, afz, atx, aty, atz, groundRef;
    private boolean climbing;
    private static final double G = 9.81, RHO = 1.225;

    public VehicleSim(VehicleSpec spec) {
        this.spec = spec;
        this.drivetrain = spec.drivetrain;
        body.mass = spec.mass; body.ix = spec.ix; body.iy = spec.iy; body.iz = spec.iz;
        for (int i = 0; i < 4; i++) {
            Wheel w = new Wheel();
            boolean front = i < 2, left = (i % 2) == 0;
            w.lx = left ? spec.halfTrack : -spec.halfTrack;
            w.lz = front ? spec.halfWheelbase : -spec.halfWheelbase;
            w.ly = spec.mountY;
            w.radius = spec.wheelRadius; w.inertia = spec.wheelInertia;
            w.springK = spec.springK; w.damperC = spec.damperC; w.maxLen = spec.maxLen; w.bumpLen = spec.bumpLen;
            w.mu = spec.mu; w.len = spec.maxLen;
            w.steerFactor = front ? 1 : 0; w.driveFactor = front ? 0 : 0.5;
            w.brakeFactor = 1; w.handbrakeFactor = front ? 0 : 1;
            wheels[i] = w;
        }
    }

    /** Вызывать раз в тик перед подшагами: собирает блоки вокруг машины. */
    public void prepare(GroundProbe probe, double lookahead) {
        RigidBody B = body;
        B.toWorld(0, spec.hullCy, 0, hc);
        double r = Math.sqrt(spec.hullHx * spec.hullHx + spec.hullHy * spec.hullHy + spec.hullHz * spec.hullHz) + 0.6 + lookahead;
        double cx = B.px + hc[0], cy = B.py + hc[1], cz = B.pz + hc[2];
        boxCount = probe.boxes(cx - r, cy - r, cz - r, cx + r, cy + r, cz + r, boxes, boxes.length / 7);
    }

    /** Максимальная скорость удара за прошедшее время (для деформации/урона), затем обнуляется. */
    public double takeImpact() { double v = impactSpeed; impactSpeed = 0; return v; }

    public double forwardSpeed() {
        body.toWorld(0, 0, 1, fw);
        return body.vx * fw[0] + body.vy * fw[1] + body.vz * fw[2];
    }

    private static double mf(double b, double c, double x) {
        double bx = b * x;
        return Math.sin(c * Math.atan(bx));
    }

    public void step(double dt, VehicleInput in, GroundProbe probe) {
        RigidBody B = body;
        double fwdSpeed = forwardSpeed();
        double speed = Math.sqrt(B.vx * B.vx + B.vy * B.vy + B.vz * B.vz);

        // --- управление ---
        double thr = 0, brake = 0, t = in.throttle;
        if (in.parked) brake = 1;
        else if (drivetrain.manual) { thr = Math.max(t, 0); brake = Math.max(-t, 0); }
        else if (t > 0.01) { if (fwdSpeed < -1.0) brake = t; else { thr = t; drivetrain.setReverseAuto(false); } }
        else if (t < -0.01) { if (fwdSpeed > 1.0) brake = -t; else { thr = -t; drivetrain.setReverseAuto(true); } }
        double lim = 2 * spec.halfWheelbase * 1.3 * spec.mu * G / Math.max(speed * speed, 1.0);
        double maxSteer = Math.max(spec.steerHigh, Math.min(spec.steerLow, lim));
        double target = in.steer * maxSteer;
        double rate = (Math.abs(target) < Math.abs(steerAngle) ? 3.0 : 1.8) * dt;
        steerAngle += Math.max(-rate, Math.min(rate, target - steerAngle));

        // --- антибуксовка (можно выключить для дрифта) ---
        if (spec.tractionControl && thr > 0 && speed > 4.0) { // на малой скорости (подъём на блок) не душим газ
            double ms = 0;
            for (Wheel w : wheels) if (w.driveFactor > 0) ms = Math.max(ms, w.slipRatio);
            thr *= Math.max(0.2, Math.min(1.0, 1.0 - (ms - 0.15) * 5.0));
        }
        // --- трансмиссия ---
        double sumOmega = 0, nDriven = 0;
        for (Wheel w : wheels) if (w.driveFactor > 0) { sumOmega += w.omega; nDriven++; }
        double driveTotal = drivetrain.update(thr, sumOmega / nDriven, dt);

        B.toWorld(0, 1, 0, up);
        double fx = 0, fy = -G * B.mass, fz = 0, tx = 0, ty = 0, tz = 0;
        double meff = B.mass / 4.0;
        boolean flipped = up[1] < 0.1;
        double omegaSum = 0;
        double lowContact = 1e9;

        for (Wheel w : wheels) {
            B.toWorld(w.lx, w.ly, w.lz, p);
            double ox = B.px + p[0], oy = B.py + p[1], oz = B.pz + p[2];
            double dx = -up[0], dy = -up[1], dz = -up[2];
            double lift = spec.rayLift, reach = lift + w.maxLen + w.radius;
            double hit = probe.cast(ox + up[0] * lift, oy + up[1] * lift, oz + up[2] * lift, dx, dy, dz, reach);
            // второй луч чуть впереди по движению: колесо заранее "видит" ступеньку и наезжает как на рампу
            double leadDir = fwdSpeed >= -0.5 ? 1 : -1;
            B.toWorld(w.lx, w.ly, w.lz + leadDir * spec.stepLead, p2);
            double hit2 = probe.cast(B.px + p2[0] + up[0] * lift, B.py + p2[1] + up[1] * lift, B.pz + p2[2] + up[2] * lift,
                    dx, dy, dz, reach);
            if (hit >= 0 && hit < 0.02) hit = -1; // луч начался внутри блока: игнорируем
            if (hit2 >= 0.02 && (hit < 0 || hit2 < hit)) hit = hit2;
            if (hit >= 0) hit = Math.max(0, hit - lift); // расстояние от точки крепления
            w.grounded = hit >= 0;
            double len = w.grounded ? Math.max(0, hit - w.radius) : w.maxLen;
            double cv = (w.len - len) / dt;
            w.len = len;
            double load = 0;
            if (w.grounded) {
                load = w.springK * (w.maxLen - len) + w.damperC * cv;
                if (len < w.bumpLen) load += w.springK * 5 * (w.bumpLen - len);
                if (load < 0) load = 0;
                double cap = 4.0 * spec.mass * G / 4.0; // не катапультируем машину на бордюрах
                if (load > cap) load = cap;
            }
            w.load = load;
            double drive = driveTotal * w.driveFactor;
            double brakeT = (brake * spec.maxBrakeTorque * w.brakeFactor)
                    + (in.handbrake ? spec.handbrakeTorque * w.handbrakeFactor : 0);

            double om = w.omega + drive / w.inertia * dt;
            if (brakeT > 0) {
                double tb = Math.min(brakeT, Math.abs(om) * w.inertia / dt);
                om -= Math.signum(om) * tb / w.inertia * dt;
            }

            if (w.grounded && !flipped) {
                // подвеска вдоль оси корпуса
                double sx = up[0] * load, sy = up[1] * load, sz = up[2] * load;
                fx += sx; fy += sy; fz += sz;
                tx += p[1] * sz - p[2] * sy; ty += p[2] * sx - p[0] * sz; tz += p[0] * sy - p[1] * sx;

                double cx = p[0] + dx * hit, cy = p[1] + dy * hit, cz = p[2] + dz * hit;
                lowContact = Math.min(lowContact, B.py + cy);
                double vcx = B.vx + (B.wy * cz - B.wz * cy);
                double vcz = B.vz + (B.wx * cy - B.wy * cx);
                double a = steerAngle * w.steerFactor;
                B.toWorld(Math.sin(a), 0, Math.cos(a), h);
                double hn = Math.hypot(h[0], h[2]);
                double hx = h[0] / hn, hz = h[2] / hn, sdx = hz, sdz = -hx;
                double vlong = vcx * hx + vcz * hz, vlat = vcx * sdx + vcz * sdz;

                double mu = w.mu * probe.grip();
                double kappa = (om * w.radius - vlong) / Math.max(Math.abs(vlong), 1.5);
                double alpha = Math.atan2(vlat, Math.abs(vlong) + 0.8);
                double fxn = mf(10, 1.65, kappa), fyn = -mf(10, 1.4, alpha);
                double mag = Math.hypot(fxn, fyn);
                if (mag > 1) { fxn /= mag; fyn /= mag; }
                double Fx = fxn * mu * load, Fy = fyn * mu * load;

                double d = om * w.radius - vlong;
                double closing = w.radius * w.radius / w.inertia + 1.0 / meff;
                double fxCap = Math.abs(d) / (dt * closing);
                if (Math.abs(Fx) > fxCap) Fx = Math.signum(Fx) * fxCap;
                double fyCap = meff * Math.abs(vlat) / dt;
                if (Math.abs(Fy) > fyCap) Fy = Math.signum(Fy) * fyCap;
                om -= Fx * w.radius * dt / w.inertia;
                w.slipRatio = (om * w.radius - vlong) / Math.max(Math.abs(vlong), 1.5);
                Fx -= spec.rollingResistance * load * Math.max(-1, Math.min(1, vlong / 0.5));

                w.slipAngle = alpha;
                double Fwx = Fx * hx + Fy * sdx, Fwz = Fx * hz + Fy * sdz;
                fx += Fwx; fz += Fwz;
                tx += cy * Fwz - cz * 0; // Fwy = 0
                ty += cz * Fwx - cx * Fwz;
                tz += cx * 0 - cy * Fwx;
            }
            if (Math.abs(om) > 700) om = Math.signum(om) * 700;
            w.omega = om;
            w.spin += om * dt;
            omegaSum += om;
        }
        spinAccum = (spinAccum + omegaSum / 4.0 * dt) % (2 * Math.PI);
        if (lowContact < 1e8) groundRef = lowContact; else groundRef = Double.NaN;

        // --- аэродинамика (в осях корпуса) ---
        B.toLocal(B.vx, B.vy, B.vz, vl);
        double dragK = 0.5 * RHO * spec.cd * spec.frontalArea;
        double sideK = 0.5 * RHO * spec.sideCd * spec.sideArea;
        double lfx = -sideK * Math.abs(vl[0]) * vl[0];
        double lfz = -dragK * Math.abs(vl[2]) * vl[2];
        double lfy = -0.5 * RHO * spec.downforceCoef * vl[2] * vl[2];
        double ltY = spec.aeroCenterZ * lfx;
        B.toWorld(lfx, lfy, lfz, fl);
        fx += fl[0]; fy += fl[1]; fz += fl[2];
        B.toWorld(0, ltY, 0, fl);
        tx += fl[0]; ty += fl[1]; tz += fl[2];

        // --- столкновение корпуса с блоками (OBB против боксов мира) ---
        afx = afy = afz = atx = aty = atz = 0;
        climbing = false;
        hullContacts();
        if (climbing && Math.abs(in.throttle) > 0.05 && !in.parked) { // помощь на подъёме: машина "ползёт" на ступеньку
            B.toWorld(0, 0, 1, fl);
            double hl = Math.hypot(fl[0], fl[2]);
            if (hl > 1e-3) {
                double dirn = Math.signum(in.throttle) * spec.climbAssist / hl;
                afx += fl[0] * dirn; afz += fl[2] * dirn;
            }
        }
        fx += afx; fy += afy; fz += afz; tx += atx; ty += aty; tz += atz;

        B.integrate(fx, fy, fz, tx, ty, tz, dt, s);
    }

    private void hullContacts() {
        RigidBody B = body;
        B.toWorld(1, 0, 0, ux); B.toWorld(0, 1, 0, uy); B.toWorld(0, 0, 1, uz);
        B.toWorld(0, spec.hullCy, 0, hc);
        double cx = B.px + hc[0], cy = B.py + hc[1], cz = B.pz + hc[2];
        double hx = spec.hullHx, hy = spec.hullHy, hz = spec.hullHz;
        double minY = cy - (hx * Math.abs(ux[1]) + hy * Math.abs(uy[1]) + hz * Math.abs(uz[1]));
        double ref = Double.isNaN(groundRef) ? minY : groundRef;
        double ex = hx * Math.abs(ux[0]) + hy * Math.abs(uy[0]) + hz * Math.abs(uz[0]);
        double ey = hx * Math.abs(ux[1]) + hy * Math.abs(uy[1]) + hz * Math.abs(uz[1]);
        double ez = hx * Math.abs(ux[2]) + hy * Math.abs(uy[2]) + hz * Math.abs(uz[2]);
        for (int i = 0; i < boxCount; i++) {
            int o = i * 7;
            double bx0 = boxes[o], by0 = boxes[o + 1], bz0 = boxes[o + 2], bx1 = boxes[o + 3], by1 = boxes[o + 4], bz1 = boxes[o + 5];
            int flags = (int) boxes[o + 6];
            if (bx1 <= cx - ex || bx0 >= cx + ex || by1 <= cy - ey || by0 >= cy + ey || bz1 <= cz - ez || bz0 >= cz + ez) continue;
            double bhx = (bx1 - bx0) * 0.5, bhy = (by1 - by0) * 0.5, bhz = (bz1 - bz0) * 0.5;
            double dx = cx - (bx0 + bx1) * 0.5, dy = cy - (by0 + by1) * 0.5, dz = cz - (bz0 + bz1) * 0.5;

            double best = 1e9, bnx = 0, bny = 0, bnz = 0, minHoriz = 1e9;
            boolean separated = false;
            for (int a = 0; a < 15 && !separated; a++) {
                double ax, ay, az;
                if (a < 3) { ax = a == 0 ? 1 : 0; ay = a == 1 ? 1 : 0; az = a == 2 ? 1 : 0; }
                else if (a < 6) { double[] u = a == 3 ? ux : a == 4 ? uy : uz; ax = u[0]; ay = u[1]; az = u[2]; }
                else {
                    int ei = (a - 6) / 3; double[] u = (a - 6) % 3 == 0 ? ux : (a - 6) % 3 == 1 ? uy : uz;
                    double ex0 = ei == 0 ? 1 : 0, ey0 = ei == 1 ? 1 : 0, ez0 = ei == 2 ? 1 : 0;
                    ax = ey0 * u[2] - ez0 * u[1]; ay = ez0 * u[0] - ex0 * u[2]; az = ex0 * u[1] - ey0 * u[0];
                    double l = Math.sqrt(ax * ax + ay * ay + az * az);
                    if (l < 1e-6) continue;
                    ax /= l; ay /= l; az /= l;
                }
                double rA = hx * Math.abs(ux[0] * ax + ux[1] * ay + ux[2] * az)
                        + hy * Math.abs(uy[0] * ax + uy[1] * ay + uy[2] * az)
                        + hz * Math.abs(uz[0] * ax + uz[1] * ay + uz[2] * az);
                double rB = bhx * Math.abs(ax) + bhy * Math.abs(ay) + bhz * Math.abs(az);
                double dist = dx * ax + dy * ay + dz * az;
                double ov = rA + rB - Math.abs(dist);
                if (ov <= 0) { separated = true; break; }
                if (dist < 0) { ax = -ax; ay = -ay; az = -az; }
                boolean horizontal = Math.abs(ay) < 0.7;
                if (horizontal && (by1 - ref) <= spec.stepHeight) { if (ov < minHoriz) minHoriz = ov; continue; }
                if (a < 3) { // внутренняя грань между блоками: столкновения нет
                    int bit = a == 0 ? (ax > 0 ? 2 : 1) : a == 1 ? (ay > 0 ? 8 : 4) : (az > 0 ? 32 : 16);
                    if ((flags & bit) != 0) continue;
                }
                if (ov < best) { best = ov; bnx = ax; bny = ay; bnz = az; }
            }
            if (separated || best > 1e8) continue;
            boolean stepping = minHoriz < best && bny > 0.7;
            if (stepping) climbing = true;
            double depth = Math.min(best, 0.5);

            double qx = Math.max(Math.max(bx0, cx - ex), Math.min(cx, Math.min(bx1, cx + ex)));
            double qy = Math.max(Math.max(by0, cy - ey), Math.min(cy, Math.min(by1, cy + ey)));
            double qz = Math.max(Math.max(bz0, cz - ez), Math.min(cz, Math.min(bz1, cz + ez)));
            double rx = qx - B.px, ry = qy - B.py, rz = qz - B.pz;
            double vpx = B.vx + (B.wy * rz - B.wz * ry);
            double vpy = B.vy + (B.wz * rx - B.wx * rz);
            double vpz = B.vz + (B.wx * ry - B.wy * rx);
            double vn = vpx * bnx + vpy * bny + vpz * bnz;
            double fn = spec.contactK * depth - spec.contactC * vn;
            double cap = stepping ? spec.stepForce : spec.contactMaxForce;
            if (fn < 0) fn = 0;
            if (fn > cap) fn = cap;
            if (-vn > impactSpeed && !stepping) impactSpeed = -vn;
            double tvx = vpx - vn * bnx, tvy = vpy - vn * bny, tvz = vpz - vn * bnz;
            double tm = Math.sqrt(tvx * tvx + tvy * tvy + tvz * tvz);
            double kf = stepping ? 0 : -spec.contactMu * fn / (tm + 0.5);
            double Fx = fn * bnx + kf * tvx, Fy = fn * bny + kf * tvy, Fz = fn * bnz + kf * tvz;
            afx += Fx; afy += Fy; afz += Fz;
            atx += ry * Fz - rz * Fy; aty += rz * Fx - rx * Fz; atz += rx * Fy - ry * Fx;
        }
    }
}
