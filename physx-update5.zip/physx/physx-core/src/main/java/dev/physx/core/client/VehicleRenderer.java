package dev.physx.core.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.physx.core.PhysxCore;
import dev.physx.core.entity.VehicleEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

/** Рисует Chevrolet K5 Blazer из файла модели. Колёса вращаются, передние поворачиваются. */
public class VehicleRenderer extends EntityRenderer<VehicleEntity> {
    private static final ResourceLocation MODEL =
            ResourceLocation.fromNamespaceAndPath(PhysxCore.MODID, "models/vehicle/blazer.pxm");
    private static final ResourceLocation WHITE = ResourceLocation.withDefaultNamespace("textures/block/white_concrete.png");
    /** Центры колёс в системе машины (y от земли, начало по z в центре масс). */
    private static final float WX = 0.9058f, WY = 0.4195f, FRONT_Z = 1.2864f, REAR_Z = -1.50f;
    private static VehicleMesh mesh;

    public VehicleRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override
    public ResourceLocation getTextureLocation(VehicleEntity e) { return WHITE; }

    @Override
    public void render(VehicleEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        if (mesh == null) mesh = VehicleMesh.load(MODEL);
        ps.pushPose();
        ps.translate(0, VehicleEntity.COM_Y, 0);
        ps.mulPose(e.getRenderQuat(pt));
        ps.translate(0, -VehicleEntity.COM_H, 0); // y = 0 это земля при стоянке

        VehicleMesh.draw(mesh.body, buf, ps.last(), light, false);

        float steer = e.getRenderSteer(pt), spin = e.getRenderSpin(pt);
        for (int i = 0; i < 4; i++) {
            boolean front = i < 2, left = (i % 2) == 0;
            ps.pushPose();
            ps.translate(left ? WX : -WX, WY, front ? FRONT_Z : REAR_Z);
            if (front) ps.mulPose(Axis.YP.rotation(steer));
            ps.mulPose(Axis.XP.rotation(spin));
            if (!left) ps.mulPose(Axis.YP.rotation((float) Math.PI)); // правая сторона: модель колеса зеркалим поворотом
            VehicleMesh.draw(mesh.wheel, buf, ps.last(), light, false);
            ps.popPose();
        }

        VehicleMesh.draw(mesh.body, buf, ps.last(), light, true); // стёкла и значки (полупрозрачные) в конце
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }
}
