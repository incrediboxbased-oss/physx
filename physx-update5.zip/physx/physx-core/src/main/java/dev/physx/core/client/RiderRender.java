package dev.physx.core.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.physx.core.PhysxCore;
import dev.physx.core.entity.VehicleEntity;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLivingEvent;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Пассажир машины поворачивается и наклоняется вместе с кузовом (крен, тангаж, рыскание). */
@EventBusSubscriber(modid = PhysxCore.MODID, value = Dist.CLIENT)
public final class RiderRender {
    private static final float PIVOT_Y = 0.75f; // таз относительно ног

    @SubscribeEvent
    public static void pre(RenderLivingEvent.Pre<?, ?> e) {
        LivingEntity le = e.getEntity();
        if (!(le.getVehicle() instanceof VehicleEntity car)) return;
        Quaternionf q = car.getRenderQuat(e.getPartialTick());
        Vector3f f = q.transform(new Vector3f(0, 0, 1));
        float h = (float) Math.atan2(-f.x, f.z);
        float deg = (float) Math.toDegrees(h);
        // тело всегда по направлению машины, голова свободна в пределах +-80 градусов
        le.yBodyRot = deg; le.yBodyRotO = deg;
        le.yHeadRot = deg + Mth.clamp(Mth.wrapDegrees(le.yHeadRot - deg), -80f, 80f);
        le.yHeadRotO = deg + Mth.clamp(Mth.wrapDegrees(le.yHeadRotO - deg), -80f, 80f);
        // наклон кузова без рыскания (рыскание уже в yBodyRot)
        Quaternionf tilt = new Quaternionf(q).mul(new Quaternionf().rotationY(h));
        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        ps.translate(0, PIVOT_Y, 0);
        ps.mulPose(tilt);
        ps.translate(0, -PIVOT_Y, 0);
    }

    @SubscribeEvent
    public static void post(RenderLivingEvent.Post<?, ?> e) {
        if (e.getEntity().getVehicle() instanceof VehicleEntity) e.getPoseStack().popPose();
    }

    private RiderRender() {}
}
