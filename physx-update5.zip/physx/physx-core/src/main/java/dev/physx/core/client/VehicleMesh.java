package dev.physx.core.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.physx.core.PhysxCore;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/** Модель машины из файла .pxm (конвертируется из GLB). Части кузова и общая модель колеса. */
public final class VehicleMesh {
    public static final class Part {
        public String name;
        public ResourceLocation texture;
        public boolean translucent, wheel;
        public int r, g, b, a;
        public float[] v;   // x y z nx ny nz u v
        public int[] idx;
    }

    public final List<Part> body = new ArrayList<>();
    public final List<Part> wheel = new ArrayList<>();

    public static VehicleMesh load(ResourceLocation rl) {
        VehicleMesh m = new VehicleMesh();
        try (InputStream in = Minecraft.getInstance().getResourceManager().open(rl)) {
            ByteBuffer bb = ByteBuffer.wrap(in.readAllBytes()).order(ByteOrder.LITTLE_ENDIAN);
            if (bb.get() != 'P' || bb.get() != 'X' || bb.get() != 'M' || bb.get() != '1') throw new IllegalStateException("bad magic");
            int n = bb.getShort() & 0xFFFF;
            for (int i = 0; i < n; i++) {
                Part p = new Part();
                p.name = str(bb);
                String tex = str(bb);
                int flags = bb.get() & 0xFF;
                p.translucent = (flags & 1) != 0;
                p.wheel = (flags & 2) != 0;
                p.r = bb.get() & 0xFF; p.g = bb.get() & 0xFF; p.b = bb.get() & 0xFF; p.a = bb.get() & 0xFF;
                p.texture = tex.isEmpty() ? ResourceLocation.withDefaultNamespace("textures/block/white_concrete.png")
                        : ResourceLocation.fromNamespaceAndPath(PhysxCore.MODID, "textures/entity/" + tex + ".png");
                int vc = bb.getInt(), ic = bb.getInt();
                p.v = new float[vc * 8];
                for (int k = 0; k < p.v.length; k++) p.v[k] = bb.getFloat();
                p.idx = new int[ic];
                for (int k = 0; k < ic; k++) p.idx[k] = bb.getShort() & 0xFFFF;
                (p.wheel ? m.wheel : m.body).add(p);
            }
        } catch (Exception e) {
            System.err.println("[physx_core] не удалось загрузить модель " + rl + ": " + e);
        }
        return m;
    }

    private static String str(ByteBuffer bb) {
        int len = bb.get() & 0xFF;
        byte[] b = new byte[len];
        bb.get(b);
        return new String(b, java.nio.charset.StandardCharsets.UTF_8);
    }

    public static void draw(List<Part> parts, MultiBufferSource buf, PoseStack.Pose pose, int light, boolean translucentPass) {
        for (Part p : parts) {
            if (p.translucent != translucentPass) continue;
            RenderType rt = p.translucent ? RenderType.entityTranslucent(p.texture) : RenderType.entityCutoutNoCull(p.texture);
            VertexConsumer vc = buf.getBuffer(rt);
            float[] v = p.v;
            int[] ix = p.idx;
            for (int t = 0; t + 2 < ix.length; t += 3) {
                emit(vc, pose, v, ix[t], p, light);
                emit(vc, pose, v, ix[t + 1], p, light);
                emit(vc, pose, v, ix[t + 2], p, light);
                emit(vc, pose, v, ix[t + 2], p, light); // треугольник как вырожденный квад
            }
        }
    }

    private static void emit(VertexConsumer vc, PoseStack.Pose pose, float[] v, int i, Part p, int light) {
        int o = i * 8;
        vc.addVertex(pose, v[o], v[o + 1], v[o + 2]).setColor(p.r, p.g, p.b, p.a).setUv(v[o + 6], v[o + 7])
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, v[o + 3], v[o + 4], v[o + 5]);
    }
}
