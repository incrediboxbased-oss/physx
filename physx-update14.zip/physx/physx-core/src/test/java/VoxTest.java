import dev.physx.core.vehicle.*;
import java.util.*;
/** Мир из блоков 1x1x1 как в Minecraft: у каждого бокса флаги внутренних граней. */
public class VoxTest {
    static final Set<Long> SOLID = new HashSet<>();
    static long key(int x,int y,int z){ return ((long)(x+4096)<<40)|((long)(y+4096)<<20)|(z+4096); }
    static boolean solid(int x,int y,int z){ return y<0 || SOLID.contains(key(x,y,z)); }
    static final GroundProbe P = new GroundProbe(){
        public double cast(double ox,double oy,double oz,double dx,double dy,double dz,double m){
            for(double d=0; d<=m; d+=0.02){ int x=(int)Math.floor(ox+dx*d), y=(int)Math.floor(oy+dy*d), z=(int)Math.floor(oz+dz*d); if(solid(x,y,z)) return d; } return -1; }
        public double grip(){return 1;}
        public int boxes(double x0,double y0,double z0,double x1,double y1,double z1,double[] out,int max){
            int n=0;
            for(int x=(int)Math.floor(x0);x<=(int)Math.floor(x1);x++) for(int y=(int)Math.floor(y0);y<=(int)Math.floor(y1);y++) for(int z=(int)Math.floor(z0);z<=(int)Math.floor(z1);z++){
                if(!solid(x,y,z)) continue; if(n>=max) return n;
                int f=0; if(solid(x-1,y,z))f|=1; if(solid(x+1,y,z))f|=2; if(solid(x,y-1,z))f|=4; if(solid(x,y+1,z))f|=8; if(solid(x,y,z-1))f|=16; if(solid(x,y,z+1))f|=32;
                int o=n*7; out[o]=x; out[o+1]=y; out[o+2]=z; out[o+3]=x+1; out[o+4]=y+1; out[o+5]=z+1; out[o+6]=f; n++; }
            return n; } };
    static void world(int obstacleH,int zStart){
        SOLID.clear();
        for(int x=-20;x<=20;x++) for(int z=zStart;z<=300;z++) for(int y=0;y<obstacleH;y++) SOLID.add(key(x,y,z));
    }
    static void tick(VehicleSim s,VehicleInput in,int n,double dt){ s.prepare(P,Math.abs(s.forwardSpeed())*0.05+0.3); for(int i=0;i<n;i++) s.step(dt,in,P); }
    public static void main(String[] a){
        for(String name: new String[]{"blazer","sports"}) for(int h: new int[]{1}) for(double kmh: new double[]{0,10,25,40}){
            world(h,8);
            VehicleSim s=new VehicleSim(name.equals("blazer")?VehicleSpec.blazer():VehicleSpec.sportsCar()); s.body.py=1.0; VehicleInput in=new VehicleInput();
            for(int i=0;i<60;i++) tick(s,in,5,0.01);
            s.body.vz=kmh/3.6; for(Wheel w:s.wheels) w.omega=kmh/3.6/s.spec.wheelRadius; in.throttle=1;
            double minY=9, maxY=0, maxTilt=0; double[] f=new double[3]; String log="";
            for(int i=0;i<20*10;i++){ tick(s,in,5,0.01); if(s.body.pz>3){ minY=Math.min(minY,s.body.py); maxY=Math.max(maxY,s.body.py);} s.body.toWorld(0,0,1,f); maxTilt=Math.max(maxTilt,Math.abs(Math.toDegrees(Math.asin(f[1])))); }
            System.out.printf("%-6s блок %d, старт %2.0f км/ч: z=%6.1f ЦМ мин=%.2f макс=%.2f (на блоке ожидается %.2f) макс.тангаж=%.0f° v=%.0f км/ч%n",name,h,kmh,s.body.pz,minY,maxY,0.846+h,maxTilt,s.forwardSpeed()*3.6);
        }
    }
}
