import dev.physx.core.vehicle.*;
import java.util.*;
public class CarRand {
  static VehicleSim mk(double x,double z,double yaw,double v){
    VehicleSim s=new VehicleSim(VehicleSpec.blazer()); s.body.px=x; s.body.py=1.0; s.body.pz=z;
    double th=-yaw; s.body.qw=Math.cos(th/2); s.body.qy=Math.sin(th/2);
    s.body.vx=-Math.sin(yaw)*v; s.body.vz=Math.cos(yaw)*v; for(Wheel w:s.wheels) w.omega=v/s.spec.wheelRadius; return s; }
  public static void main(String[] a){
    Random r=new Random(3); int N=300, bad=0; int[] badByType=new int[4]; 
    for(int t=0;t<N;t++){
      VoxTest.SOLID.clear();
      double yawA=r.nextDouble()*Math.PI*2, yawB=r.nextDouble()*Math.PI*2; double vA=r.nextDouble()*25, vB=r.nextDouble()*25*(t%2);
      double ang=r.nextDouble()*Math.PI*2; double dist=7+r.nextDouble()*3;
      VehicleSim A=mk(0,0,yawA,vA), B=mk(Math.cos(ang)*dist,Math.sin(ang)*dist,yawB,vB);
      // направим A примерно на B
      double toB=Math.atan2(-(B.body.px-A.body.px),(B.body.pz-A.body.pz)); double th=-toB+ (r.nextDouble()-.5)*0.6; A.body.qw=Math.cos(th/2);A.body.qy=Math.sin(th/2);A.body.qx=0;A.body.qz=0;
      A.body.vx=-Math.sin(-th)*vA; A.body.vz=Math.cos(-th)*vA;
      VehicleInput in=new VehicleInput(); in.parked=true; double maxPen=0;
      for(int i=0;i<20*6;i++){ VoxTest.tick(A,in,5,0.01); VoxTest.tick(B,in,5,0.01);
        VehicleCollision.resolveCars(A,B);
        // глубина пересечения по SAT
        VehicleCollision.Obb oa=new VehicleCollision.Obb(), ob=new VehicleCollision.Obb(); VehicleCollision.hullOf(A,oa); VehicleCollision.hullOf(B,ob); VehicleCollision.Hit h=new VehicleCollision.Hit();
        if(i>30 && VehicleCollision.sat(oa,ob,h)) maxPen=Math.max(maxPen,h.depth); }
      if(maxPen>0.5){ bad++; System.out.printf("  пересечены: случай %d глубина %.2f (vA=%.0f vB=%.0f)%n",t,maxPen,vA,vB); }
    }
    System.out.printf("случайных столкновений машин: %d, остались пересечёнными (>0.5 м): %d%n",N,bad);
  }
}
