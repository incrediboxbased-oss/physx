import dev.physx.core.vehicle.*;
public class Vox2 {
    static void flatWorld(){ VoxTest.SOLID.clear(); }
    static void add(int x,int y,int z){ VoxTest.SOLID.add(VoxTest.key(x,y,z)); }
    static double minGroundGap(VehicleSim s){ // насколько корпус ушёл ниже поверхности (по самой низкой точке OBB), < 0 = провал
        return 0; }
    public static void main(String[] a){
        // 1) крыша: падение на плоский мир
        flatWorld(); VehicleSim s=new VehicleSim(VehicleSpec.blazer()); VehicleInput in=new VehicleInput(); in.parked=true;
        s.body.py=4; s.body.qw=0; s.body.qz=1; s.body.vz=12; double minY=9;
        for(int i=0;i<400;i++){ VoxTest.tick(s,in,5,0.01); minY=Math.min(minY,s.body.py); }
        System.out.printf("крыша (Blazer): мин. высота ЦМ=%.2f (нормально ~0.84-1.2, если <0.6 - провал)%n",minY);
        // 2) одиночный блок, наезд под углом и с рулём
        for(double ang: new double[]{0,20,45,70}) for(String nm: new String[]{"blazer","sports"}){
            flatWorld(); add(0,0,10); add(1,0,10); add(0,0,11); add(1,0,11);   // колонна 2x2 на пути
            VehicleSim c=new VehicleSim(nm.equals("blazer")?VehicleSpec.blazer():VehicleSpec.sportsCar()); c.body.py=1.0;
            double th=-Math.toRadians(ang); c.body.qw=Math.cos(th/2); c.body.qy=Math.sin(th/2); c.body.px=0.5-Math.sin(Math.toRadians(ang))*-6; 
            VehicleInput i2=new VehicleInput(); for(int i=0;i<60;i++) VoxTest.tick(c,i2,5,0.01);
            double v=25/3.6; double[] f=new double[3]; c.body.toWorld(0,0,1,f); c.body.vx=f[0]*v; c.body.vz=f[2]*v; for(Wheel w:c.wheels) w.omega=v/c.spec.wheelRadius;
            i2.throttle=1; double mn=9, mx=0, mxTilt=0, mxRoll=0; double[] u=new double[3];
            for(int i=0;i<400;i++){ VoxTest.tick(c,i2,5,0.01); mn=Math.min(mn,c.body.py); mx=Math.max(mx,c.body.py); c.body.toWorld(0,1,0,u); mxRoll=Math.max(mxRoll,Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,u[1]))))); }
            System.out.printf("%-6s колонна, угол %2.0f°: ЦМ мин=%.2f макс=%.2f наклон кузова макс=%.0f° конец: x=%.1f z=%.1f y=%.2f%n",nm,ang,mn,mx,mxRoll,c.body.px,c.body.pz,c.body.py);
        }
    }
}
