import dev.physx.core.vehicle.*;
public class BlazerTest {
  static VehicleSim mk(){ WorldTest.BOX.clear(); WorldTest.BOX.add(new double[]{-1000,-10,-1000,1000,0,1000}); VehicleSim s=new VehicleSim(VehicleSpec.blazer()); s.body.py=0.9; return s; }
  static void tick(VehicleSim s,VehicleInput in,int n,double dt){ for(int i=0;i<n;i++){ if(i%4==0) s.prepare(WorldTest.W,Math.abs(s.forwardSpeed())*0.05+0.3); s.step(dt,in,WorldTest.W);} }
  public static void main(String[] a){
    double dt=1/160.0;
    VehicleSim s=mk(); VehicleInput in=new VehicleInput(); tick(s,in,480,dt);
    System.out.printf("стоит: высота ЦМ=%.3f м, ход подвески=%.3f (перед) %.3f (зад)%n",s.body.py,s.wheels[0].len,s.wheels[2].len);
    in.throttle=1; double t100=-1; double vmax=0;
    for(int i=0;i<160*25;i++){ tick(s,in,1,dt); double v=s.forwardSpeed()*3.6; vmax=Math.max(vmax,v); if(t100<0&&v>=100) t100=i*dt; }
    System.out.printf("разгон: 0-100 за %.1f с, макс. за 25 с %.0f км/ч, передача %d%n",t100,vmax,s.drivetrain.gear);
    in.throttle=-1; double v0=s.forwardSpeed(); int n=0; while(s.forwardSpeed()>1&&n<160*20){ tick(s,in,1,dt); n++; }
    System.out.printf("торможение с %.0f км/ч: %.1f с%n",v0*3.6,n*dt);
    // блок 1.0 с места, полный газ
    for(double kmh: new double[]{0,15,40}){
      WorldTest.BOX.clear(); WorldTest.BOX.add(new double[]{-1000,-10,-1000,1000,0,1000}); WorldTest.BOX.add(new double[]{-50,0,5,50,1.0,205});
      VehicleSim c=new VehicleSim(VehicleSpec.blazer()); c.body.py=0.9; VehicleInput i2=new VehicleInput(); tick(c,i2,480,dt);
      c.body.vz=kmh/3.6; for(Wheel w:c.wheels) w.omega=kmh/3.6/0.42; i2.throttle=1; tick(c,i2,160*8,dt);
      System.out.printf("блок 1.0, старт %2.0f км/ч: z=%.1f ЦМ=%.2f v=%.1f км/ч %s%n",kmh,c.body.pz,c.body.py,c.forwardSpeed()*3.6, c.body.pz>8?"ВЗЯЛ":"застрял");
    }
    // стена 2 блока
    WorldTest.BOX.clear(); WorldTest.BOX.add(new double[]{-1000,-10,-1000,1000,0,1000}); WorldTest.BOX.add(new double[]{-50,0,20,50,2.0,25});
    VehicleSim w=new VehicleSim(VehicleSpec.blazer()); w.body.py=0.9; VehicleInput i3=new VehicleInput(); tick(w,i3,480,dt);
    w.body.vz=60/3.6; for(Wheel x:w.wheels) x.omega=60/3.6/0.42; i3.throttle=1; double[] mx={0}; for(int i=0;i<160*6;i++){ tick(w,i3,1,dt); mx[0]=Math.max(mx[0],w.body.pz);} 
    System.out.printf("стена 2 блока, 60 км/ч: макс. z=%.1f (стена на 20, нос +2.2), z сейчас=%.1f, v=%.1f%n",mx[0],w.body.pz,w.forwardSpeed()*3.6);
  }
}
