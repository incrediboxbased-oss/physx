import dev.physx.core.vehicle.*;
import java.util.*;
/** Мир с блоками, плитами и ванильными ступенями (несколько боксов в клетке). */
public class StairTest {
    static final Map<Long,double[][]> CELL = new HashMap<>();
    static long key(int x,int y,int z){ return ((long)(x+4096)<<40)|((long)(y+4096)<<20)|(z+4096); }
    static final double[][] FULL={{0,0,0,1,1,1}}, SLAB={{0,0,0,1,0.5,1}}, STAIR={{0,0,0,1,0.5,1},{0,0.5,0.5,1,1,1}}; // ступень растёт в сторону +z
    static void put(int x,int y,int z,double[][] s){ CELL.put(key(x,y,z),s); }
    static double[][] get(int x,int y,int z){ if(y<0) return FULL; return CELL.get(key(x,y,z)); }
    static boolean full(int x,int y,int z){ double[][] c=get(x,y,z); return c!=null&&c==FULL; }
    static boolean insideCell(int x,int y,int z,double px,double py,double pz){ double[][] c=get(x,y,z); if(c==null) return false;
        double lx=px-x,ly=py-y,lz=pz-z; for(double[] b:c) if(lx>=b[0]&&lx<=b[3]&&ly>=b[1]&&ly<=b[4]&&lz>=b[2]&&lz<=b[5]) return true; return false; }
    static final GroundProbe P=new GroundProbe(){
        public double cast(double ox,double oy,double oz,double dx,double dy,double dz,double m){
            for(double d=0;d<=m;d+=0.01){ double px=ox+dx*d,py=oy+dy*d,pz=oz+dz*d; if(insideCell((int)Math.floor(px),(int)Math.floor(py),(int)Math.floor(pz),px,py,pz)) return d; } return -1; }
        public double grip(){return 1;}
        public int boxes(double x0,double y0,double z0,double x1,double y1,double z1,double[] out,int max){
            int n=0;
            for(int x=(int)Math.floor(x0);x<=(int)Math.floor(x1);x++) for(int y=(int)Math.floor(y0);y<=(int)Math.floor(y1);y++) for(int z=(int)Math.floor(z0);z<=(int)Math.floor(z1);z++){
                double[][] c=get(x,y,z); if(c==null) continue;
                int cover=0; if(full(x-1,y,z))cover|=1; if(full(x+1,y,z))cover|=2; if(full(x,y-1,z))cover|=4; if(full(x,y+1,z))cover|=8; if(full(x,y,z-1))cover|=16; if(full(x,y,z+1))cover|=32;
                for(double[] b:c){ if(n>=max) return n; int f=0;
                    if(b[0]<=1e-6) f|=cover&1; if(b[3]>=1-1e-6) f|=cover&2; if(b[1]<=1e-6) f|=cover&4; if(b[4]>=1-1e-6) f|=cover&8; if(b[2]<=1e-6) f|=cover&16; if(b[5]>=1-1e-6) f|=cover&32;
                    int o=n*7; out[o]=x+b[0];out[o+1]=y+b[1];out[o+2]=z+b[2];out[o+3]=x+b[3];out[o+4]=y+b[4];out[o+5]=z+b[5];out[o+6]=f;n++; } }
            return n; } };
    static void tick(VehicleSim s,VehicleInput in,int n,double dt){ s.prepare(P,Math.abs(s.forwardSpeed())*0.05+0.3); for(int i=0;i<n;i++) s.step(dt,in,P); }
    // лестницы вдоль +z, ширина x -8..8
    static void build(String type){
        CELL.clear();
        int z0=8;
        for(int x=-8;x<=8;x++){
            if(type.equals("плиты 0.5")){ for(int k=0;k<8;k++){ int h=k+1; for(int y=0;y<(h+1)/2;y++) put(x,y,z0+k,(y==(h+1)/2-1&&h%2==1)?SLAB:FULL);} }
            if(type.equals("блоки 1.0")){ for(int k=0;k<4;k++) for(int y=0;y<=k;y++) put(x,y,z0+k,FULL); }
            if(type.equals("плита+блок")){ // 0.5, 1.0, 1.5, 2.0 через один блок глубиной
                for(int k=0;k<6;k++){ int h=k+1; for(int y=0;y<(h+1)/2;y++) put(x,y,z0+k,(y==(h+1)/2-1&&h%2==1)?SLAB:FULL);} }
            if(type.equals("ванильные ступени")){ for(int k=0;k<5;k++){ for(int y=0;y<k;y++) put(x,y,z0+k,FULL); put(x,k,z0+k,STAIR);} }
            // площадка в конце
        }
    }
    public static void main(String[] a){
        String[] types={"плиты 0.5","блоки 1.0","ванильные ступени"};
        for(String nm: new String[]{"blazer","sports"}) for(String t: types) for(double kmh: new double[]{0,20}){
            build(t);
            VehicleSim s=new VehicleSim(nm.equals("blazer")?VehicleSpec.blazer():VehicleSpec.sportsCar()); s.body.py=1.0; VehicleInput in=new VehicleInput();
            for(int i=0;i<60;i++) tick(s,in,5,0.01);
            s.body.vz=kmh/3.6; for(Wheel w:s.wheels) w.omega=kmh/3.6/s.spec.wheelRadius; in.throttle=1;
            double maxY=0; double pitchSum=0, jit=0, lastY=s.body.py, lastP=0; int cnt=0; double[] f=new double[3];
            for(int i=0;i<20*12;i++){ tick(s,in,5,0.01); maxY=Math.max(maxY,s.body.py);
                s.body.toWorld(0,0,1,f); double p=Math.toDegrees(Math.asin(f[1])); if(i>20&&s.body.pz<14){ jit+=Math.abs(s.body.py-lastY)+0.02*Math.abs(p-lastP); cnt++; } lastY=s.body.py; lastP=p; }
            System.out.printf("%-6s %-18s старт %2.0f км/ч: итог z=%5.1f ЦМ=%.2f (макс %.2f) v=%.0f км/ч дрожание=%.3f%n",nm,t,kmh,s.body.pz,s.body.py,maxY,s.forwardSpeed()*3.6,cnt>0?jit/cnt:0);
        }
    }
}
