import dev.physx.core.vehicle.*;
public class BounceTest {
  static final double DT=0.01; // как в игре: 5 подшагов на тик
  static void tick(VehicleSim s,VehicleInput in,int steps){ for(int i=0;i<steps;i++){ if(i%5==0) s.prepare(WorldTest.W,Math.abs(s.forwardSpeed())*0.05+0.3); s.step(DT,in,WorldTest.W);} }
  static void ground(){ WorldTest.BOX.clear(); WorldTest.BOX.add(new double[]{-1000,-10,-1000,1000,0,1000}); }
  public static void main(String[] a){
    // 1) падение на крышу
    ground(); VehicleSim s=new VehicleSim(VehicleSpec.blazer()); VehicleInput in=new VehicleInput(); in.parked=true;
    s.body.py=5; s.body.qw=0; s.body.qx=0; s.body.qy=0; s.body.qz=1; // перевёрнута (поворот на 180° вокруг z)
    s.body.vz=10;
    double maxUp=0; int hops=0; boolean wasAir=false; double v0=0;
    for(int i=0;i<500;i++){ tick(s,in,5); double up=s.body.vy; if(i>20&&up>maxUp) maxUp=up; 
      if(i%25==0) System.out.printf("крыша t=%.2f y=%.2f vy=%.1f vz=%.1f%n",i*0.05,s.body.py,s.body.vy,s.body.vz); }
    System.out.printf("-> макс. подскок после посадки vy=%.2f м/с; итоговая скорость %.1f м/с%n",maxUp,Math.hypot(s.body.vx,s.body.vz));
    // 2) блок 1.0 и 0.5
    for(double h: new double[]{0.5,1.0}){
      ground(); WorldTest.BOX.add(new double[]{-50,0,5,50,h,205});
      VehicleSim c=new VehicleSim(VehicleSpec.blazer()); c.body.py=0.9; VehicleInput i2=new VehicleInput(); tick(c,i2,100);
      c.body.vz=15/3.6; for(Wheel w:c.wheels) w.omega=15/3.6/0.42; i2.throttle=1;
      double maxY=0,maxVy=0,minY=9; double rest=0.846+h;
      for(int i=0;i<400;i++){ tick(c,i2,5); if(c.body.pz>6){ maxY=Math.max(maxY,c.body.py); maxVy=Math.max(maxVy,c.body.vy);} }
      System.out.printf("блок %.1f: макс. высота ЦМ=%.2f (стоячая %.2f, перелёт %.2f м), макс. вертикальная скорость %.1f м/с%n",h,maxY,rest,maxY-rest,maxVy);
    }
  }
}
