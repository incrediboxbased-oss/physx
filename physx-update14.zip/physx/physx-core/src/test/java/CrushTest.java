import dev.physx.core.vehicle.*;
public class CrushTest {
  static void wall(double v0){
    StairTest.CELL.clear();
    for(int x=-6;x<=6;x++) for(int z=40;z<=44;z++) for(int y=0;y<4;y++) StairTest.put(x,y,z,StairTest.FULL);
    VehicleSim s=new VehicleSim(VehicleSpec.blazer()); s.body.py=1.0; VehicleInput in=new VehicleInput(); in.parked=false;
    for(int i=0;i<60;i++) StairTest.tick(s,in,5,0.01);
    s.body.vz=v0; for(Wheel w:s.wheels) w.omega=v0/s.spec.wheelRadius; in.throttle=0; double maxDecel=0, dvTot=0, lastV=v0; double rebound=0;
    for(int i=0;i<20*6;i++){ StairTest.tick(s,in,5,0.01); double v=s.body.vz; maxDecel=Math.max(maxDecel,(lastV-v)/0.05/9.81); lastV=v; rebound=Math.min(rebound,v); dvTot+=s.takeCrashDv(); }
    System.out.printf("стена %.0f км/ч: смятие нос=%.2f корма=%.2f борт=%.2f/%.2f крыша=%.2f м; пик перегрузки %.0f g (за тик), отскок %.1f м/с, суммарный dv=%.1f, z=%.1f%n",v0*3.6,s.crush[0],s.crush[1],s.crush[2],s.crush[3],s.crush[4],maxDecel,rebound,dvTot,s.body.pz);
  }
  public static void main(String[] a){
    for(double v: new double[]{3,6,10,15,20,30}) wall(v);
    // обычная езда не должна мять корпус
    for(String t: new String[]{"блоки 1.0","плиты 0.5"}){ StairTest.build(t); VehicleSim s=new VehicleSim(VehicleSpec.blazer()); s.body.py=1.0; VehicleInput in=new VehicleInput();
      for(int i=0;i<60;i++) StairTest.tick(s,in,5,0.01); s.body.vz=8; in.throttle=1; for(int i=0;i<400;i++) StairTest.tick(s,in,5,0.01);
      double sum=0; for(double c: s.crush) sum+=c; System.out.printf("лестница '%s': суммарное смятие %.3f м%n",t,sum); }
  }
}
