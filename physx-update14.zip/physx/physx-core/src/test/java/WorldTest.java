import dev.physx.core.vehicle.*;
import java.util.*;
public class WorldTest {
    static final List<double[]> BOX = new ArrayList<>();
    static boolean inside(double x,double y,double z){ for(double[] b:BOX) if(x>b[0]&&x<b[3]&&y>b[1]&&y<b[4]&&z>b[2]&&z<b[5]) return true; return false; }
    static final GroundProbe W = new GroundProbe(){
        public double cast(double ox,double oy,double oz,double dx,double dy,double dz,double m){
            for(double d=0; d<=m; d+=0.01) if(inside(ox+dx*d,oy+dy*d,oz+dz*d)) return d; return -1; }
        public double grip(){return 1;}
        public int boxes(double x0,double y0,double z0,double x1,double y1,double z1,double[] out,int max){
            int n=0; for(double[] b:BOX){ if(b[3]<x0||b[0]>x1||b[4]<y0||b[1]>y1||b[5]<z0||b[2]>z1) continue;
                if(n>=max) break; for(int i=0;i<6;i++) out[n*7+i]=b[i]; out[n*7+6]=0; n++; } return n; } };
    static void run(String name,double stepH,double stepZ,double kmh){
        BOX.clear(); BOX.add(new double[]{-1000,-10,-1000,1000,0,1000});
        if(stepH>0) BOX.add(new double[]{-50,0,stepZ,50,stepH,stepZ+200});
        VehicleSim s=new VehicleSim(VehicleSpec.sportsCar()); s.body.py=0.55; double dt=1/160.0; VehicleInput in=new VehicleInput();
        for(int i=0;i<320;i++){ if(i%4==0) s.prepare(W,0.5); s.step(dt,in,W);}
        double v0=kmh/3.6; s.body.vz=v0; for(Wheel w:s.wheels) w.omega=v0/0.34;
        in.throttle=0.4; double maxYaw=0,maxImp=0,maxPen=0; boolean nan=false;
        for(int i=0;i<160*8;i++){ if(i%4==0) s.prepare(W,Math.abs(s.forwardSpeed())*0.05); s.step(dt,in,W); maxYaw=Math.max(maxYaw,Math.abs(s.body.wy)); maxImp=Math.max(maxImp,s.impactSpeed); s.impactSpeed=0;
            if(Double.isNaN(s.body.px)) nan=true; }
        System.out.printf("%-22s z=%6.1f высота ЦМ=%.2f v=%5.1f км/ч макс.рыскание=%.2f рад/с макс.удар=%.1f м/с %s%n",name,s.body.pz,s.body.py,s.forwardSpeed()*3.6,maxYaw,maxImp,nan?"NaN!":"");
    }
    public static void main(String[] a){
        run("ровно 40 км/ч",0,0,40);
        run("полублок 0.5, 40км/ч",0.5,15,40);
        run("полублок 0.5, 15км/ч",0.5,8,15);
        run("блок 1.0, 40 км/ч",1.0,15,40);
        run("блок 1.0, 15 км/ч",1.0,8,15);
        run("блок 1.0, 5 км/ч",1.0,4,5);
        run("стена 1.5, 20 км/ч",1.5,10,20);
        run("стена 3.0, 70 км/ч",3.0,30,70);
    }
}
