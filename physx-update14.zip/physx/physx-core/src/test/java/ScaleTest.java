import dev.physx.core.vehicle.*;
public class ScaleTest {
  public static void main(String[] a){
    VehicleSpec sp=VehicleSpec.blazer(); double dt=0.01;
    VoxTest.SOLID.clear(); VehicleSim s=new VehicleSim(sp); s.body.py=1.2; VehicleInput in=new VehicleInput();
    for(int i=0;i<120;i++) VoxTest.tick(s,in,5,dt);
    System.out.printf("покой: ЦМ=%.3f (расчёт restComHeight=%.3f), ход подвески пер=%.3f зад=%.3f%n",s.body.py,sp.restComHeight(),s.wheels[0].len,s.wheels[2].len);
    in.throttle=1; double t100=-1,vmax=0;
    for(int i=0;i<20*30;i++){ VoxTest.tick(s,in,5,dt); double v=s.forwardSpeed()*3.6; vmax=Math.max(vmax,v); if(t100<0&&v>=100) t100=i*0.05; }
    System.out.printf("разгон: 0-100 за %.1f с, макс. за 30 с %.0f км/ч, передача %d%n",t100,vmax,s.drivetrain.gear);
    in.throttle=-1; double v0=s.forwardSpeed(); int n=0; while(s.forwardSpeed()>1&&n<20*20){ VoxTest.tick(s,in,5,dt); n++; }
    System.out.printf("торможение с %.0f км/ч: %.1f с%n",v0*3.6,n*0.05);
    // устойчивость: полный руль на разных скоростях
    for(double kmh: new double[]{40,60,80,100,130}){
      VoxTest.SOLID.clear(); VehicleSim c=new VehicleSim(VehicleSpec.blazer()); c.body.py=1.2; VehicleInput i2=new VehicleInput();
      for(int i=0;i<120;i++) VoxTest.tick(c,i2,5,dt);
      double v=kmh/3.6; c.body.vz=v; for(Wheel w:c.wheels) w.omega=v/c.spec.wheelRadius; i2.throttle=0.3; i2.steer=1;
      double maxRoll=0,maxLat=0; boolean flip=false; double[] u=new double[3];
      for(int i=0;i<20*8;i++){ VoxTest.tick(c,i2,5,dt); c.body.toWorld(0,1,0,u); double roll=Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,u[1])))); maxRoll=Math.max(maxRoll,roll); if(u[1]<0.3) flip=true; }
      System.out.printf("полный руль на %3.0f км/ч: макс. крен %.0f° %s%n",kmh,maxRoll,flip?"ПЕРЕВЕРНУЛАСЬ":"устойчива");
    }
  }
}
