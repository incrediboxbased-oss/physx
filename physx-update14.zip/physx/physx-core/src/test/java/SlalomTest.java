import dev.physx.core.vehicle.*;
public class SlalomTest { public static void main(String[] a){
  for(double kmh: new double[]{50,80,110}) for(boolean hb: new boolean[]{false,true}){
    VoxTest.SOLID.clear(); VehicleSim c=new VehicleSim(VehicleSpec.blazer()); c.body.py=1.2; VehicleInput in=new VehicleInput();
    for(int i=0;i<120;i++) VoxTest.tick(c,in,5,0.01);
    double v=kmh/3.6; c.body.vz=v; for(Wheel w:c.wheels) w.omega=v/c.spec.wheelRadius; in.throttle=0.5;
    double maxRoll=0; boolean flip=false; double[] u=new double[3];
    for(int i=0;i<20*20;i++){ in.steer=((i/30)%2==0)?1:-1; in.handbrake=hb&&(i%60>45); VoxTest.tick(c,in,5,0.01); c.body.toWorld(0,1,0,u); double roll=Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,u[1])))); maxRoll=Math.max(maxRoll,roll); if(u[1]<0.3) flip=true; }
    System.out.printf("слалом (руль влево-вправо каждые 1.5 с) %3.0f км/ч, ручник=%b: макс. крен %.0f° %s%n",kmh,hb,maxRoll,flip?"ПЕРЕВЕРНУЛАСЬ":"устойчива");
  } } }
