import dev.physx.core.vehicle.*;
import java.util.*;
public class StressTest {
    static double lowest(VehicleSim s){ VehicleCollision.Obb o=new VehicleCollision.Obb(); VehicleCollision.hullOf(s,o);
        return o.cy-(o.hx*Math.abs(o.ux[1])+o.hy*Math.abs(o.uy[1])+o.hz*Math.abs(o.uz[1])); }
    public static void main(String[] a){
        Random r=new Random(7); int bad=0, N=200; double worst=0; int stuck=0;
        for(int t=0;t<N;t++){
            VoxTest.SOLID.clear(); VehicleSpec sp=(t%2==0)?VehicleSpec.blazer():VehicleSpec.sportsCar();
            VehicleSim s=new VehicleSim(sp); VehicleInput in=new VehicleInput(); in.parked=(t%3!=0); in.throttle=(t%3==0)?1:0;
            double qx=r.nextGaussian(),qy=r.nextGaussian(),qz=r.nextGaussian(),qw=r.nextGaussian(); double n=Math.sqrt(qx*qx+qy*qy+qz*qz+qw*qw);
            s.body.qw=qw/n;s.body.qx=qx/n;s.body.qy=qy/n;s.body.qz=qz/n; s.body.py=2+r.nextDouble()*6;
            s.body.vx=(r.nextDouble()-.5)*40; s.body.vz=(r.nextDouble()-.5)*40; s.body.vy=-r.nextDouble()*10;
            s.body.wx=(r.nextDouble()-.5)*6; s.body.wy=(r.nextDouble()-.5)*6; s.body.wz=(r.nextDouble()-.5)*6;
            int sub=5+r.nextInt(8); double dt=0.05/sub; double mn=1e9;
            for(int i=0;i<160;i++){ VoxTest.tick(s,in,sub,dt); if(i>20) mn=Math.min(mn,lowest(s)); }
            double fin=lowest(s); if(fin<-0.15){ stuck++; System.out.printf("  ОСТАЛСЯ ПОД ЗЕМЛЁЙ #%d: %.2f%n",t,fin); }
            if(Double.isNaN(s.body.py)||mn<-0.4){ bad++; }
            worst=Math.min(worst,mn);
        }
        System.out.printf("случайных падений: %d, глубокие проваливания в какой-то момент: %d, худшая глубина: %.2f м, ОСТАЛИСЬ под землёй к концу: %d%n",N,bad,worst,stuck);
    }
}
