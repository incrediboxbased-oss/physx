import dev.physx.core.vehicle.*;
public class CarCrashTest {
  static VehicleSim mk(double x,double z,double yaw,double v){
    VehicleSim s=new VehicleSim(VehicleSpec.blazer()); s.body.px=x; s.body.py=1.2; s.body.pz=z;
    double th=-yaw; s.body.qw=Math.cos(th/2); s.body.qy=Math.sin(th/2);
    s.body.vx=-Math.sin(yaw)*v; s.body.vz=Math.cos(yaw)*v; for(Wheel w:s.wheels) w.omega=v/s.spec.wheelRadius; return s; }
  static void run(String name,VehicleSim a,VehicleSim b){
    VoxTest.SOLID.clear(); VehicleInput in=new VehicleInput(); in.parked=true; double dt=0.01;
    double maxSp=0; 
    for(int t=0;t<20*10;t++){ VoxTest.tick(a,in,5,dt); VoxTest.tick(b,in,5,dt); maxSp=Math.max(maxSp,VehicleCollision.resolveCars(a,b)); }
    System.out.printf("%-28s макс. скорость удара %.1f м/с; после: A z=%.1f v=%.1f, B z=%.1f v=%.1f; дистанция центров %.1f м%n",name,maxSp,a.body.pz,a.forwardSpeed(),b.body.pz,b.forwardSpeed(),Math.hypot(a.body.px-b.body.px,a.body.pz-b.body.pz));
  }
  public static void main(String[] x){
    run("лоб в лоб 20+20 м/с",mk(0,-10,0,20),mk(0,10,Math.PI,20));
    run("удар в стоящую 20 м/с",mk(0,-10,0,20),mk(0,6,0,0));
    run("удар в бок 15 м/с",mk(0,-10,0,15),mk(0,3,Math.PI/2,0));
    run("боковое касание",mk(0,-8,0,15),mk(2.6,0,0,0));
  }
}
