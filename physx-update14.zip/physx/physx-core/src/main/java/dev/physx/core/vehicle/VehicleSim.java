package dev.physx.core.vehicle;

/** Ядро симуляции машины: подвеска, шины (Magic Formula + круг трения), трансмиссия, аэродинамика. */
public final class VehicleSim {
    public final VehicleSpec spec;
    public final RigidBody body = new RigidBody();
    public final Wheel[] wheels = new Wheel[4];
    public final Drivetrain drivetrain;
    public double steerAngle, spinAccum, impactSpeed, outThrottle, outBrake;
    public boolean tcActive;
    /** Угол заноса корпуса (рад, знак: + занос влево). */
    public double driftAngle;
    /** Постоянное смятие зон корпуса (м): нос, корма, левый, правый борт, крыша. */
    public final double[] crush = new double[5];
    /** Сумма изменений скорости от ударов за тик (для травм водителя) и смещение руля от повреждений. */
    public double crashDv, steerBias;

    private final double[] s = new double[3], p = new double[3], up = new double[3], fw = new double[3],
            h = new double[3], vl = new double[3], fl = new double[3],
            p2 = new double[3], hc = new double[3], ux = new double[3], uy = new double[3], uz = new double[3];
    private final double[] boxes = new double[7 * 600];
    private int boxCount;
    private double groundRef, groundRefHigh;
    private boolean climbing;
    private final double[] s2 = new double[3], s3 = new double[3], comp = new double[4];
    /** Последний сильный удар: точка и нормаль в осях корпуса (от препятствия к машине), скорость. */
    public final double[] impPoint = new double[3], impNormal = new double[3];
    public double impSpeed;
    // контакты корпуса с блоками (собираются каждый подшаг)
    private static final int MAXC = 160;
    private final double[] cr = new double[MAXC * 3], cn = new double[MAXC * 3], cDepth = new double[MAXC], cJn = new double[MAXC], cJt = new double[MAXC], cVn0 = new double[MAXC];
    private final boolean[] cStep = new boolean[MAXC], cCrush = new boolean[MAXC];
    private final int[] cZone = new int[MAXC];
    private final int[] zoneCount = new int[5];
    private final boolean[] landAdded = new boolean[5];
    private final double[] zoneDepth = new double[5];
    private double[] env;
    private int cCount;
    private static final double G = 9.81, RHO = 1.225;

    public VehicleSim(VehicleSpec spec) {
        this.spec = spec;
        this.drivetrain = spec.drivetrain;
        body.mass = spec.mass; body.ix = spec.ix; body.iy = spec.iy; body.iz = spec.iz;
        for (int i = 0; i < 4; i++) {
            Wheel w = new Wheel();
            boolean front = i < 2, left = (i % 2) == 0;
            w.lx = left ? spec.halfTrack : -spec.halfTrack;
            w.lz = front ? spec.frontAxleZ : spec.rearAxleZ;
            w.ly = spec.mountY;
            w.radius = spec.wheelRadius; w.inertia = spec.wheelInertia;
            w.springK = spec.springK; w.damperC = spec.damperC; w.maxLen = spec.maxLen; w.bumpLen = spec.bumpLen;
            w.mu = spec.mu; w.len = spec.maxLen;
            w.steerFactor = front ? 1 : 0; w.driveFactor = (front ? spec.frontDrive : spec.rearDrive) / 2;
            w.brakeFactor = 1; w.handbrakeFactor = front ? 0 : 1;
            wheels[i] = w;
        }
    }

    /** Вызывать раз в тик перед подшагами: собирает блоки вокруг машины. */
    public void prepare(GroundProbe probe, double lookahead) {
        RigidBody B = body;
        B.toWorld(0, spec.hullCy, spec.hullCz, hc);
        double r = Math.sqrt(spec.hullHx * spec.hullHx + spec.hullHy * spec.hullHy + spec.hullHz * spec.hullHz) + 0.6 + lookahead;
        double cx = B.px + hc[0], cy = B.py + hc[1], cz = B.pz + hc[2];
        boxCount = probe.boxes(cx - r, cy - r, cz - r, cx + r, cy + r, cz + r, boxes, boxes.length / 7);
    }

    public int contactCount() { return cCount; }

    public double takeCrashDv() { double v = crashDv; crashDv = 0; return v; }

    private int zoneOf(double nx, double ny, double nz) {
        body.toLocal(nx, ny, nz, s2);
        if (s2[2] < -0.6) return 0;
        if (s2[2] > 0.6) return 1;
        if (s2[0] < -0.6) return 2;
        if (s2[0] > 0.6) return 3;
        if (s2[1] < -0.6) return 4;
        return -1;
    }

    /** Добавить смятие от внешнего удара (силой n в мировых осях на эту машину). */
    void addCrush(double nx, double ny, double nz, double amount) {
        int z = zoneOf(nx, ny, nz);
        if (z >= 0) crush[z] = Math.min(spec.crushMax[z], crush[z] + amount);
    }

    void addCrashDv(double dv) { crashDv += dv; }

    public String dumpContacts() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cCount; i++) sb.append(String.format("[n=(%.0f,%.0f,%.0f) d=%.2f step=%b Jn=%.0f] ", cn[i*3], cn[i*3+1], cn[i*3+2], cDepth[i], cStep[i], cJn[i]));
        return sb.toString();
    }

    /** Записать удар (точка и нормаль в мировых осях относительно центра масс). */
    void recordImpact(double rx, double ry, double rz, double nx, double ny, double nz, double speed) {
        if (speed <= impactSpeed) return;
        RigidBody B = body;
        impactSpeed = speed; impSpeed = speed;
        B.toLocal(rx, ry, rz, s2); impPoint[0] = s2[0]; impPoint[1] = s2[1]; impPoint[2] = s2[2];
        B.toLocal(nx, ny, nz, s2); impNormal[0] = s2[0]; impNormal[1] = s2[1]; impNormal[2] = s2[2];
    }

    /** Максимальная скорость удара за прошедшее время (для деформации/урона), затем обнуляется. */
    public double takeImpact() { double v = impactSpeed; impactSpeed = 0; return v; }

    public double forwardSpeed() {
        body.toWorld(0, 0, 1, fw);
        return body.vx * fw[0] + body.vy * fw[1] + body.vz * fw[2];
    }

    private static double mf(double b, double c, double x) {
        double bx = b * x;
        return Math.sin(c * Math.atan(bx));
    }

    public void step(double dt, VehicleInput in, GroundProbe probe) {
        RigidBody B = body;
        double fwdSpeed = forwardSpeed();
        double speed = Math.sqrt(B.vx * B.vx + B.vy * B.vy + B.vz * B.vz);
        B.toLocal(B.vx, B.vy, B.vz, vl);
        driftAngle = speed > 3.0 ? Math.atan2(vl[0], Math.abs(vl[2]) + 0.5) * (vl[2] >= 0 ? 1 : -1) : 0;

        // --- управление ---
        double thr = 0, brake = 0, t = in.throttle;
        if (in.parked) brake = 1;
        else if (drivetrain.manual) { thr = Math.max(t, 0); brake = Math.max(-t, 0); }
        else if (t > 0.01) { if (fwdSpeed < -1.0) brake = t; else { thr = t; drivetrain.setReverseAuto(false); } }
        else if (t < -0.01) { if (fwdSpeed > 1.0) brake = -t; else { thr = -t; drivetrain.setReverseAuto(true); } }
        double lim = (spec.frontAxleZ - spec.rearAxleZ) * 1.3 * spec.mu * G / Math.max(speed * speed, 1.0);
        double maxSteer = Math.max(spec.steerHigh, Math.min(spec.steerLow, lim));
        double target = in.steer * maxSteer + steerBias;
        double rate = (Math.abs(target) < Math.abs(steerAngle) ? 3.0 : 1.8) * dt;
        steerAngle += Math.max(-rate, Math.min(rate, target - steerAngle));

        // --- антибуксовка (можно выключить для дрифта) ---
        if (spec.tractionControl && thr > 0 && speed > 4.0 && !in.handbrake && Math.abs(driftAngle) < 0.25) { // на малой скорости (подъём на блок) не душим газ
            double ms = 0;
            for (Wheel w : wheels) if (w.driveFactor > 0) ms = Math.max(ms, w.slipRatio);
            double tcf = Math.max(0.25, Math.min(1.0, 1.0 - (ms - 0.2) * 4.0));
            tcActive = tcf < 0.98;
            thr *= tcf;
        } else tcActive = false;
        outThrottle = thr; outBrake = brake;
        // --- трансмиссия ---
        double sumOmega = 0, nDriven = 0;
        for (Wheel w : wheels) if (w.driveFactor > 0) { sumOmega += w.omega; nDriven++; }
        double driveTotal = drivetrain.update(thr, sumOmega / nDriven, fwdSpeed / spec.wheelRadius, dt);

        B.toWorld(0, 1, 0, up);
        double fx = 0, fy = -G * B.mass, fz = 0, tx = 0, ty = 0, tz = 0;
        double meff = B.mass / 4.0;
        boolean flipped = up[1] < 0.1;
        for (int i = 0; i < 4; i++) comp[i] = wheels[i].maxLen - wheels[i].len;
        double omegaSum = 0;
        int wi = -1;
        double lowContact = 1e9, highContact = -1e9;

        for (Wheel w : wheels) {
            wi++;
            B.toWorld(w.lx, w.ly, w.lz, p);
            double ox = B.px + p[0], oy = B.py + p[1], oz = B.pz + p[2];
            double dx = -up[0], dy = -up[1], dz = -up[2];
            double lift = spec.rayLift, reach = lift + w.maxLen + w.radius;
            double hit = probe.cast(ox + up[0] * lift, oy + up[1] * lift, oz + up[2] * lift, dx, dy, dz, reach);
            // второй луч чуть впереди по движению: колесо заранее "видит" ступеньку и наезжает как на рампу
            double leadDir = fwdSpeed >= -0.5 ? 1 : -1;
            B.toWorld(w.lx, w.ly, w.lz + leadDir * spec.stepLead, p2);
            double hit2 = probe.cast(B.px + p2[0] + up[0] * lift, B.py + p2[1] + up[1] * lift, B.pz + p2[2] + up[2] * lift,
                    dx, dy, dz, reach);
            if (hit >= 0 && hit < 0.02) hit = -1; // луч начался внутри блока: игнорируем
            if (hit2 >= 0.02 && (hit < 0 || hit2 < hit)) hit = hit2;
            if (hit >= 0) hit = Math.max(0, hit - lift); // расстояние от точки крепления
            // земля под колесом поднимается не быстрее groundRiseRate (колесо "вкатывается" на ступеньку)
            if (hit >= 0) {
                double fall = Math.max(0, -(B.vx * up[0] + B.vy * up[1] + B.vz * up[2]));
                if (w.hitFilt >= 0) hit = Math.max(hit, w.hitFilt - (spec.groundRiseRate + 1.2 * Math.abs(fwdSpeed) + fall) * dt);
                w.hitFilt = hit;
            } else w.hitFilt = -1;
            w.grounded = hit >= 0;
            double len = w.grounded ? Math.max(0, hit - w.radius) : w.maxLen;
            double cv = (w.len - len) / dt;
            w.len = len;
            double load = 0;
            if (w.grounded) {
                load = w.springK * (w.maxLen - len) + w.damperC * cv;
                if (len < w.bumpLen) load += w.springK * 5 * (w.bumpLen - len);
                load += spec.arbK * (comp[wi] - comp[wi ^ 1]); // стабилизатор поперечной устойчивости
                if (load < 0) load = 0;
                double cap = spec.suspCapFactor * spec.mass * G / 4.0; // не катапультируем машину на бордюрах
                if (load > cap) load = cap;
            }
            w.load = load;
            if (!w.grounded) w.smoking = false;
            double drive = driveTotal * w.driveFactor;
            double brakeT = (brake * spec.maxBrakeTorque * w.brakeFactor)
                    + (in.handbrake ? spec.handbrakeTorque * w.handbrakeFactor : 0);

            double om = w.omega + drive / w.inertia * dt;
            if (brakeT > 0) {
                double tb = Math.min(brakeT, Math.abs(om) * w.inertia / dt);
                om -= Math.signum(om) * tb / w.inertia * dt;
            }

            if (w.grounded && !flipped) {
                // подвеска вдоль оси корпуса
                double sx = up[0] * load, sy = up[1] * load, sz = up[2] * load;
                fx += sx; fy += sy; fz += sz;
                tx += p[1] * sz - p[2] * sy; ty += p[2] * sx - p[0] * sz; tz += p[0] * sy - p[1] * sx;

                double cx = p[0] + dx * hit, cy = p[1] + dy * hit, cz = p[2] + dz * hit;
                lowContact = Math.min(lowContact, B.py + cy);
                highContact = Math.max(highContact, B.py + cy);
                double vcx = B.vx + (B.wy * cz - B.wz * cy);
                double vcz = B.vz + (B.wx * cy - B.wy * cx);
                double a = steerAngle * w.steerFactor;
                B.toWorld(Math.sin(a), 0, Math.cos(a), h);
                double hn = Math.hypot(h[0], h[2]);
                double hx = h[0] / hn, hz = h[2] / hn, sdx = hz, sdz = -hx;
                double vlong = vcx * hx + vcz * hz, vlat = vcx * sdx + vcz * sdz;

                double mu = w.mu * probe.grip();
                double kappa = (om * w.radius - vlong) / Math.max(Math.abs(vlong), 1.5);
                double alpha = Math.atan2(vlat, Math.abs(vlong) + 0.8);
                double fxn = mf(10, 1.65, kappa), fyn = -mf(10, 1.4, alpha);
                { double ad = Math.abs(alpha), dd = Math.min(1, Math.max(0, (ad - 0.2) / 0.4)); fyn *= 1 - 0.25 * dd * dd * (3 - 2 * dd); }
                double mag = Math.hypot(fxn, fyn);
                if (mag > 1) { fxn /= mag; fyn /= mag; }
                double Fx = fxn * mu * load, Fy = fyn * mu * load;

                double d = om * w.radius - vlong;
                double closing = w.radius * w.radius / w.inertia + 1.0 / meff;
                double fxCap = Math.abs(d) / (dt * closing);
                if (Math.abs(Fx) > fxCap) Fx = Math.signum(Fx) * fxCap;
                double fyCap = meff * Math.abs(vlat) / dt;
                if (Math.abs(Fy) > fyCap) Fy = Math.signum(Fy) * fyCap;
                om -= Fx * w.radius * dt / w.inertia;
                w.slipRatio = (om * w.radius - vlong) / Math.max(Math.abs(vlong), 1.5);
                Fx -= spec.rollingResistance * load * Math.max(-1, Math.min(1, vlong / 0.5));

                w.slipAngle = alpha;
                w.smoking = speed > 2.0 && (Math.abs(alpha) > 0.3 || Math.abs(kappa) > 0.5);
                double Fwx = Fx * hx + Fy * sdx, Fwz = Fx * hz + Fy * sdz;
                fx += Fwx; fz += Fwz;
                tx += cy * Fwz - cz * 0; // Fwy = 0
                ty += cz * Fwx - cx * Fwz;
                tz += cx * 0 - cy * Fwx;
            }
            if (Math.abs(om) > 700) om = Math.signum(om) * 700;
            w.omega = om;
            w.spin += om * dt;
            omegaSum += om;
        }
        spinAccum = (spinAccum + omegaSum / 4.0 * dt) % (2 * Math.PI);
        if (lowContact < 1e8) { groundRef = lowContact; groundRefHigh = highContact; } else { groundRef = Double.NaN; groundRefHigh = Double.NaN; }

        // --- аэродинамика (в осях корпуса) ---
        B.toLocal(B.vx, B.vy, B.vz, vl);
        double dragK = 0.5 * RHO * spec.cd * spec.frontalArea;
        double sideK = 0.5 * RHO * spec.sideCd * spec.sideArea;
        double lfx = -sideK * Math.abs(vl[0]) * vl[0];
        double lfz = -dragK * Math.abs(vl[2]) * vl[2];
        double lfy = -0.5 * RHO * spec.downforceCoef * vl[2] * vl[2];
        double ltY = spec.aeroCenterZ * lfx;
        B.toWorld(lfx, lfy, lfz, fl);
        fx += fl[0]; fy += fl[1]; fz += fl[2];
        B.toWorld(0, ltY, 0, fl);
        tx += fl[0]; ty += fl[1]; tz += fl[2];

        // помощь на подъёме: машина "ползёт" на ступеньку (по флагу прошлого подшага)
        if (climbing) { // наезд на ступеньку гасит горизонтальную скорость (иначе машину подбрасывает как с трамплина)
            double kd = spec.mass * spec.stepDamping;
            fx -= B.vx * kd; fz -= B.vz * kd;
        }
        if (climbing && Math.abs(in.throttle) > 0.05 && !in.parked) {
            B.toWorld(0, 0, 1, fl);
            double hl = Math.hypot(fl[0], fl[2]);
            if (hl > 1e-3) {
                double dirn = Math.signum(in.throttle) * spec.climbAssistG * spec.mass * G / hl;
                fx += fl[0] * dirn; fz += fl[2] * dirn;
            }
        }
        B.integrateVelocity(fx, fy, fz, tx, ty, tz, dt, s);
        // --- столкновение корпуса с блоками: импульсы (устойчиво при любом шаге) ---
        climbing = false;
        collectContacts();
        solveContacts(dt);
        B.integratePose(dt);
    }

    private void collectContacts() {
        cCount = 0;
        if (spec.partCz == null) collectPart(spec.hullCy, spec.hullCz, spec.hullHx, spec.hullHy, spec.hullHz);
        else for (int i = 0; i < spec.partCz.length; i++) collectPart(spec.partCy[i], spec.partCz[i], spec.partHx[i], spec.partHy[i], spec.partHz[i]);
    }

    private void collectPart(double cyL, double czL, double hxP, double hyP, double hzP) {
        RigidBody B = body;
        if (env == null) env = spec.envelope();
        // смятые зоны уменьшают границы корпуса
        double zMax = Math.min(czL + hzP, env[1] - crush[0]), zMin = Math.max(czL - hzP, env[0] + crush[1]);
        double xMax = Math.min(hxP, env[2] - crush[2]), xMin = Math.max(-hxP, -(env[2] - crush[3]));
        double yTop = Math.min(cyL + hyP, env[4] - crush[4]), yBot = cyL - hyP;
        if (zMax - zMin < 0.08 || xMax - xMin < 0.08 || yTop - yBot < 0.08) return;
        double cxL = (xMax + xMin) / 2; czL = (zMax + zMin) / 2; cyL = (yTop + yBot) / 2;
        hxP = (xMax - xMin) / 2; hzP = (zMax - zMin) / 2; hyP = (yTop - yBot) / 2;
        B.toWorld(1, 0, 0, ux); B.toWorld(0, 1, 0, uy); B.toWorld(0, 0, 1, uz);
        B.toWorld(cxL, cyL, czL, hc);
        double cx = B.px + hc[0], cy = B.py + hc[1], cz = B.pz + hc[2];
        double hx = hxP, hy = hyP, hz = hzP;
        double minY = cy - (hx * Math.abs(ux[1]) + hy * Math.abs(uy[1]) + hz * Math.abs(uz[1]));
        double ref = Double.isNaN(groundRef) ? minY : groundRef;
        boolean stepOK = !Double.isNaN(groundRef) && uy[1] > 0.5;
        double refHigh = Double.isNaN(groundRefHigh) ? ref : groundRefHigh;
        double ex = hx * Math.abs(ux[0]) + hy * Math.abs(uy[0]) + hz * Math.abs(uz[0]);
        double ey = hx * Math.abs(ux[1]) + hy * Math.abs(uy[1]) + hz * Math.abs(uz[1]);
        double ez = hx * Math.abs(ux[2]) + hy * Math.abs(uy[2]) + hz * Math.abs(uz[2]);
        for (int i = 0; i < boxCount; i++) {
            int o = i * 7;
            double bx0 = boxes[o], by0 = boxes[o + 1], bz0 = boxes[o + 2], bx1 = boxes[o + 3], by1 = boxes[o + 4], bz1 = boxes[o + 5];
            int flags = (int) boxes[o + 6];
            if (bx1 <= cx - ex || bx0 >= cx + ex || by1 <= cy - ey || by0 >= cy + ey || bz1 <= cz - ez || bz0 >= cz + ez) continue;
            // высота блока относительно самой высокой точки опоры колёс (для лестниц: следующая ступень выше текущей на шаг)
            double rel = stepOK ? by1 - refHigh : 1e9; // наезд на ступеньки работает только когда колёса на земле и машина стоит на колёсах
            boolean obstacle = stepOK && by1 - ref > 0.08; // верх блока выше уровня земли под колёсами
            double bhx = (bx1 - bx0) * 0.5, bhy = (by1 - by0) * 0.5, bhz = (bz1 - bz0) * 0.5;
            double dx = cx - (bx0 + bx1) * 0.5, dy = cy - (by0 + by1) * 0.5, dz = cz - (bz0 + bz1) * 0.5;

            double best = 1e9, bnx = 0, bny = 0, bnz = 0, minHoriz = 1e9;
            boolean separated = false;
            for (int a = 0; a < 15 && !separated; a++) {
                double ax, ay, az;
                if (a < 3) { ax = a == 0 ? 1 : 0; ay = a == 1 ? 1 : 0; az = a == 2 ? 1 : 0; }
                else if (a < 6) { double[] u = a == 3 ? ux : a == 4 ? uy : uz; ax = u[0]; ay = u[1]; az = u[2]; }
                else {
                    int ei = (a - 6) / 3; double[] u = (a - 6) % 3 == 0 ? ux : (a - 6) % 3 == 1 ? uy : uz;
                    double ex0 = ei == 0 ? 1 : 0, ey0 = ei == 1 ? 1 : 0, ez0 = ei == 2 ? 1 : 0;
                    ax = ey0 * u[2] - ez0 * u[1]; ay = ez0 * u[0] - ex0 * u[2]; az = ex0 * u[1] - ey0 * u[0];
                    double l = Math.sqrt(ax * ax + ay * ay + az * az);
                    if (l < 1e-6) continue;
                    ax /= l; ay /= l; az /= l;
                }
                double rA = hx * Math.abs(ux[0] * ax + ux[1] * ay + ux[2] * az)
                        + hy * Math.abs(uy[0] * ax + uy[1] * ay + uy[2] * az)
                        + hz * Math.abs(uz[0] * ax + uz[1] * ay + uz[2] * az);
                double rB = bhx * Math.abs(ax) + bhy * Math.abs(ay) + bhz * Math.abs(az);
                double dist = dx * ax + dy * ay + dz * az;
                double ov = rA + rB - Math.abs(dist);
                if (ov <= 0) { separated = true; break; }
                boolean flipped = false;
                if (dist < 0) { ax = -ax; ay = -ay; az = -az; }
                if (a < 3) { // центр машины глубже середины блока: выталкиваем через открытую сторону, а не вглубь
                    int bitSide = a == 0 ? (ax > 0 ? 2 : 1) : a == 1 ? (ay > 0 ? 8 : 4) : (az > 0 ? 32 : 16);
                    int bitOpp = a == 0 ? (ax > 0 ? 1 : 2) : a == 1 ? (ay > 0 ? 4 : 8) : (az > 0 ? 16 : 32);
                    if ((flags & bitSide) != 0 && (flags & bitOpp) == 0) { ax = -ax; ay = -ay; az = -az; flipped = true; }
                }
                if (flipped) ov = rA + rB + Math.abs(dist);
                boolean horizontal = Math.abs(ay) < 0.7;
                if (horizontal && rel <= spec.stepHeight) { // низкое препятствие или сама земля: бок не считаем стеной
                    if (obstacle && ov < minHoriz) minHoriz = ov;   // а вот наезд на ступеньку отмечаем (земля - нет)
                    continue;
                }
                if (!flipped) { // внутренняя грань между блоками: столкновения нет (для любых осей после привязки к осям мира)
                    double qa = Math.abs(ax), qb = Math.abs(ay), qc = Math.abs(az);
                    int bit;
                    if (qb >= qa && qb >= qc) bit = ay > 0 ? 8 : 4;
                    else if (qa >= qc) bit = ax > 0 ? 2 : 1;
                    else bit = az > 0 ? 32 : 16;
                    if ((flags & bit) != 0) continue;
                }
                if (ov < best) { best = ov; bnx = ax; bny = ay; bnz = az; }
            }
            if (separated || best > 1e8) continue;
            // блоки мира выровнены по осям: нормаль контакта привязываем к ближайшей оси мира
            // (иначе при крене/тангаже нормаль наклоняется и вдавливает машину в землю)
            { double qa = Math.abs(bnx), qb = Math.abs(bny), qc = Math.abs(bnz);
              if (qb >= qa && qb >= qc) { bnx = 0; bnz = 0; bny = Math.signum(bny); }
              else if (qa >= qc) { bny = 0; bnz = 0; bnx = Math.signum(bnx); }
              else { bnx = 0; bny = 0; bnz = Math.signum(bnz); } }
            boolean stepping = minHoriz < 1e8 && bny > 0.7; // была проигнорирована горизонтальная ось: это наезд на ступеньку
            if (stepping) climbing = true;
            double depth = Math.min(best, 0.5);

            // точка контакта: самая глубокая вершина корпуса против нормали, прижатая к области блока
            double sgx = (ux[0] * bnx + ux[1] * bny + ux[2] * bnz) > 0 ? 1 : -1;
            double sgy = (uy[0] * bnx + uy[1] * bny + uy[2] * bnz) > 0 ? 1 : -1;
            double sgz = (uz[0] * bnx + uz[1] * bny + uz[2] * bnz) > 0 ? 1 : -1;
            double qx = cx - sgx * hx * ux[0] - sgy * hy * uy[0] - sgz * hz * uz[0];
            double qy = cy - sgx * hx * ux[1] - sgy * hy * uy[1] - sgz * hz * uz[1];
            double qz = cz - sgx * hx * ux[2] - sgy * hy * uy[2] - sgz * hz * uz[2];
            if (bnx == 0) qx = Math.max(bx0, Math.min(bx1, qx));
            if (bny == 0) qy = Math.max(by0, Math.min(by1, qy));
            if (bnz == 0) qz = Math.max(bz0, Math.min(bz1, qz));
            if (cCount >= MAXC) break;
            int k = cCount++;
            cr[k * 3] = qx - B.px; cr[k * 3 + 1] = qy - B.py; cr[k * 3 + 2] = qz - B.pz;
            cn[k * 3] = bnx; cn[k * 3 + 1] = bny; cn[k * 3 + 2] = bnz;
            cDepth[k] = depth; cStep[k] = stepping; cJn[k] = 0; cJt[k] = 0; cVn0[k] = Double.NaN;
            cZone[k] = stepping ? -1 : zoneOf(bnx, bny, bnz);
        }
    }

    double kEff(double rx, double ry, double rz, double nx, double ny, double nz) {
        RigidBody B = body;
        double cx = ry * nz - rz * ny, cy = rz * nx - rx * nz, cz = rx * ny - ry * nx;
        B.toLocal(cx, cy, cz, s2); s2[0] /= B.ix; s2[1] /= B.iy; s2[2] /= B.iz;
        B.toWorld(s2[0], s2[1], s2[2], s3);
        double wx = s3[0], wy = s3[1], wz = s3[2];
        return 1.0 / B.mass + ((wy * rz - wz * ry) * nx + (wz * rx - wx * rz) * ny + (wx * ry - wy * rx) * nz);
    }

    void impulseAt(double rx, double ry, double rz, double jx, double jy, double jz) {
        RigidBody B = body;
        B.vx += jx / B.mass; B.vy += jy / B.mass; B.vz += jz / B.mass;
        double lx = ry * jz - rz * jy, ly = rz * jx - rx * jz, lz = rx * jy - ry * jx;
        B.toLocal(lx, ly, lz, s2); s2[0] /= B.ix; s2[1] /= B.iy; s2[2] /= B.iz;
        B.toWorld(s2[0], s2[1], s2[2], s3);
        B.wx += s3[0]; B.wy += s3[1]; B.wz += s3[2];
    }

    private void solveContacts(double dt) {
        if (cCount == 0) return;
        RigidBody B = body;
        double capWall = spec.crashForceG * spec.mass * G * dt;
        double yieldF = spec.crushYieldG * spec.mass * G;
        // пред-проход: скорости сближения, зоны смятия
        for (int z = 0; z < 5; z++) { zoneCount[z] = 0; zoneDepth[z] = 0; landAdded[z] = false; }
        for (int i = 0; i < cCount; i++) {
            cCrush[i] = false; cVn0[i] = Double.NaN;
            if (cStep[i]) continue;
            double rx = cr[i * 3], ry = cr[i * 3 + 1], rz = cr[i * 3 + 2];
            double nx = cn[i * 3], ny = cn[i * 3 + 1], nz = cn[i * 3 + 2];
            double vn = (B.vx + (B.wy * rz - B.wz * ry)) * nx + (B.vy + (B.wz * rx - B.wx * rz)) * ny + (B.vz + (B.wx * ry - B.wy * rx)) * nz;
            cVn0[i] = vn;
            if (-vn > impactSpeed) {
                impactSpeed = -vn;
                B.toLocal(rx, ry, rz, s2); impPoint[0] = s2[0]; impPoint[1] = s2[1]; impPoint[2] = s2[2];
                B.toLocal(nx, ny, nz, s2); impNormal[0] = s2[0]; impNormal[1] = s2[1]; impNormal[2] = s2[2];
                impSpeed = -vn;
            }
            int z = cZone[i];
            if (z >= 0 && Math.abs(ny) >= 0.7 && vn < -6.0 && !landAdded[z]) { // падение/удар о землю: смятие зоны по энергии
                landAdded[z] = true;
                crush[z] = Math.min(spec.crushMax[z], crush[z] + Math.min(0.2, 0.025 * (-vn - 5)));
            }
            if (z >= 0 && Math.abs(ny) < 0.7 && vn < -7.0 && crush[z] < spec.crushMax[z] - 0.005) { cCrush[i] = true; zoneCount[z]++; zoneDepth[z] = Math.max(zoneDepth[z], cDepth[i]); }
        }
        for (int it = 0; it < 4; it++) {
            for (int i = 0; i < cCount; i++) {
                if (cStep[i]) continue; // подъём на ступеньку: только плавный подъём позицией (ниже)
                double rx = cr[i * 3], ry = cr[i * 3 + 1], rz = cr[i * 3 + 2];
                double nx = cn[i * 3], ny = cn[i * 3 + 1], nz = cn[i * 3 + 2];
                double vpx = B.vx + (B.wy * rz - B.wz * ry), vpy = B.vy + (B.wz * rx - B.wx * rz), vpz = B.vz + (B.wx * ry - B.wy * rx);
                double vn = vpx * nx + vpy * ny + vpz * nz;
                double target = cVn0[i] < -3.0 ? -spec.contactRestitution * cVn0[i] : 0;
                double K = kEff(rx, ry, rz, nx, ny, nz);
                double j = (target - vn) / K;
                double cap;
                if (cCrush[i]) cap = yieldF * (1 + 2 * crush[cZone[i]] / spec.crushMax[cZone[i]]) / Math.max(1, zoneCount[cZone[i]]) * dt; // зона смятия: поглощает удар, пока не исчерпана
                else cap = Math.abs(ny) > 0.7 ? 1e9 : capWall; // земля жёсткая, стена ограничена
                double newJ = Math.max(0, Math.min(cJn[i] + j, cap));
                j = newJ - cJn[i]; cJn[i] = newJ;
                if (j > 0 && cVn0[i] < -2.0) crashDv += j / B.mass;
                if (j != 0) impulseAt(rx, ry, rz, nx * j, ny * j, nz * j);
                // трение
                vpx = B.vx + (B.wy * rz - B.wz * ry); vpy = B.vy + (B.wz * rx - B.wx * rz); vpz = B.vz + (B.wx * ry - B.wy * rx);
                double vn2 = vpx * nx + vpy * ny + vpz * nz;
                double tx = vpx - vn2 * nx, ty = vpy - vn2 * ny, tz = vpz - vn2 * nz;
                double tm = Math.sqrt(tx * tx + ty * ty + tz * tz);
                if (tm > 1e-6 && cJn[i] > 0) {
                    double mu = Math.abs(ny) > 0.7 ? spec.groundFriction : spec.wallFriction;
                    double Kt = kEff(rx, ry, rz, tx / tm, ty / tm, tz / tm);
                    double jt = Math.min(tm / Kt, mu * cJn[i] - cJt[i]);
                    if (jt > 0) { cJt[i] += jt; impulseAt(rx, ry, rz, -tx / tm * jt, -ty / tm * jt, -tz / tm * jt); }
                }
            }
        }
        // позиционная коррекция без добавления энергии: по оси берём максимальное выталкивание
        double pxP = 0, pxN = 0, pyP = 0, pyN = 0, pzP = 0, pzN = 0;
        double rise = spec.stepRise * dt;
        double[] add = {0, 0, 0, 0, 0};
        for (int z = 0; z < 5; z++) if (zoneCount[z] > 0) {
            add[z] = Math.min(Math.max(0, zoneDepth[z] - 0.01), Math.min(0.3, spec.crushMax[z] - crush[z]));
            crush[z] += add[z];
        }
        for (int i = 0; i < cCount; i++) {
            double depthLeft = cDepth[i] - (cCrush[i] ? add[cZone[i]] : 0); // смятие забрало часть проникновения
            double d = Math.max(0, depthLeft - 0.005) * (cStep[i] ? 0.5 : 0.8);
            if (cStep[i]) { d = Math.min(d, rise); climbing = true; } else d = Math.min(d, 0.3);
            double nx = cn[i * 3], ny = cn[i * 3 + 1], nz = cn[i * 3 + 2];
            if (nx > 0) pxP = Math.max(pxP, d * nx); else if (nx < 0) pxN = Math.max(pxN, -d * nx);
            if (ny > 0) pyP = Math.max(pyP, d * ny); else if (ny < 0) pyN = Math.max(pyN, -d * ny);
            if (nz > 0) pzP = Math.max(pzP, d * nz); else if (nz < 0) pzN = Math.max(pzN, -d * nz);
        }
        B.px += pxP - pxN; B.py += pyP - pyN; B.pz += pzP - pzN;
    }
}
