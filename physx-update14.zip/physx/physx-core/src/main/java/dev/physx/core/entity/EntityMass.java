package dev.physx.core.entity;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;

/** Масса существ (кг) для столкновений и (позже) для веса на машине. */
public final class EntityMass {
    public static double of(Entity e) {
        if (e instanceof Player) return 75;
        EntityType<?> t = e.getType();
        if (t == EntityType.IRON_GOLEM) return 650;
        if (t == EntityType.HORSE || t == EntityType.DONKEY || t == EntityType.MULE || t == EntityType.CAMEL) return 480;
        if (t == EntityType.COW || t == EntityType.MOOSHROOM) return 450;
        if (t == EntityType.PIG) return 130;
        if (t == EntityType.SHEEP) return 80;
        if (t == EntityType.VILLAGER || t == EntityType.ZOMBIE || t == EntityType.SKELETON) return 75;
        double v = e.getBbWidth() * e.getBbWidth() * e.getBbHeight();
        return Math.max(5, v * 400);
    }
    private EntityMass() {}
}
