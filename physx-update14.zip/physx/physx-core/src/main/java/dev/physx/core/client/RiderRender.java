package dev.physx.core.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.physx.core.PhysxCore;
import dev.physx.core.entity.VehicleEntity;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLivingEvent;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayDeque;

/**
 * Пассажир машины поворачивается и наклоняется вместе с кузовом (крен, тангаж, рыскание).
 * Важно: углы тела и головы меняются только на время отрисовки модели и возвращаются в Post,
 * иначе камера от первого лица (она берёт угол головы) дёргается при повороте головы в сторону.
 */
@EventBusSubscriber(modid = PhysxCore.MODID, value = Dist.CLIENT)
public final class RiderRender {
    private static final float PIVOT_Y = 0.75f; // таз относительно ног
    /** Сидящий водитель чуть уменьшен вокруг таза: голова не торчит из крыши, ноги не вылезают из днища. */
    private static final float SEAT_SCALE = 0.8f;
    private static final ArrayDeque<float[]> SAVED = new ArrayDeque<>();

    @SubscribeEvent
    public static void pre(RenderLivingEvent.Pre<?, ?> e) {
        LivingEntity le = e.getEntity();
        if (!(le.getVehicle() instanceof VehicleEntity car)) return;
        Quaternionf q = car.getRenderQuat(e.getPartialTick());
        Vector3f f = q.transform(new Vector3f(0, 0, 1));
        float h = (float) Math.atan2(-f.x, f.z);
        float deg = (float) Math.toDegrees(h);

        SAVED.push(new float[]{le.yBodyRot, le.yBodyRotO, le.yHeadRot, le.yHeadRotO});
        le.yBodyRot = deg; le.yBodyRotO = deg;
        le.yHeadRot = deg + Mth.clamp(Mth.wrapDegrees(le.yHeadRot - deg), -80f, 80f);
        le.yHeadRotO = deg + Mth.clamp(Mth.wrapDegrees(le.yHeadRotO - deg), -80f, 80f);

        Quaternionf tilt = new Quaternionf(q).mul(new Quaternionf().rotationY(h));
        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        ps.translate(0, PIVOT_Y, 0);
        ps.mulPose(tilt);
        ps.scale(SEAT_SCALE, SEAT_SCALE, SEAT_SCALE);
        ps.translate(0, -PIVOT_Y, 0);
    }

    @SubscribeEvent
    public static void post(RenderLivingEvent.Post<?, ?> e) {
        LivingEntity le = e.getEntity();
        if (!(le.getVehicle() instanceof VehicleEntity) || SAVED.isEmpty()) return;
        e.getPoseStack().popPose();
        float[] s = SAVED.pop();
        le.yBodyRot = s[0]; le.yBodyRotO = s[1]; le.yHeadRot = s[2]; le.yHeadRotO = s[3];
    }

    private RiderRender() {}
}
