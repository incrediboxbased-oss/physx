package dev.physx.core.vehicle;

/** Столкновения машины с другой машиной и с существами (ориентированный бокс против бокса, импульсы). */
public final class VehicleCollision {
    /** Ориентированный бокс. u - оси (по 3 числа: ux, uy, uz), h - половинные размеры. */
    public static final class Obb {
        public double cx, cy, cz, hx, hy, hz;
        public final double[] ux = new double[3], uy = new double[3], uz = new double[3];
    }

    /** Результат SAT: нормаль от B к A, глубина, точка контакта. */
    public static final class Hit { public double nx, ny, nz, depth, px, py, pz; }

    public static void hullOf(VehicleSim s, Obb o) {
        RigidBody B = s.body; double[] c = new double[3];
        double[] env = s.spec.envelope(); // zMin, zMax, xHalf, yMin, yMax
        double zMax = env[1] - s.crush[0], zMin = env[0] + s.crush[1];
        double xMax = env[2] - s.crush[2], xMin = -(env[2] - s.crush[3]);
        double yTop = env[4] - s.crush[4], yBot = env[3];
        B.toWorld(1, 0, 0, o.ux); B.toWorld(0, 1, 0, o.uy); B.toWorld(0, 0, 1, o.uz);
        B.toWorld((xMax + xMin) / 2, (yTop + yBot) / 2, (zMax + zMin) / 2, c);
        o.cx = B.px + c[0]; o.cy = B.py + c[1]; o.cz = B.pz + c[2];
        o.hx = Math.max(0.1, (xMax - xMin) / 2); o.hy = Math.max(0.1, (yTop - yBot) / 2); o.hz = Math.max(0.1, (zMax - zMin) / 2);
    }

    public static void aabb(double x0, double y0, double z0, double x1, double y1, double z1, Obb o) {
        o.cx = (x0 + x1) / 2; o.cy = (y0 + y1) / 2; o.cz = (z0 + z1) / 2;
        o.hx = (x1 - x0) / 2; o.hy = (y1 - y0) / 2; o.hz = (z1 - z0) / 2;
        o.ux[0] = 1; o.ux[1] = 0; o.ux[2] = 0; o.uy[0] = 0; o.uy[1] = 1; o.uy[2] = 0; o.uz[0] = 0; o.uz[1] = 0; o.uz[2] = 1;
    }

    private static double proj(Obb o, double ax, double ay, double az) {
        return o.hx * Math.abs(o.ux[0] * ax + o.ux[1] * ay + o.ux[2] * az)
             + o.hy * Math.abs(o.uy[0] * ax + o.uy[1] * ay + o.uy[2] * az)
             + o.hz * Math.abs(o.uz[0] * ax + o.uz[1] * ay + o.uz[2] * az);
    }

    /** SAT по 15 осям. Возвращает false, если боксы не пересекаются. n направлена от B к A. */
    public static boolean sat(Obb A, Obb B, Hit out) {
        double dx = A.cx - B.cx, dy = A.cy - B.cy, dz = A.cz - B.cz;
        double best = 1e9, bx = 0, by = 0, bz = 0;
        double[][] ax = {A.ux, A.uy, A.uz}, bx_ = {B.ux, B.uy, B.uz};
        for (int a = 0; a < 15; a++) {
            double x, y, z;
            if (a < 3) { x = ax[a][0]; y = ax[a][1]; z = ax[a][2]; }
            else if (a < 6) { x = bx_[a - 3][0]; y = bx_[a - 3][1]; z = bx_[a - 3][2]; }
            else {
                double[] u = ax[(a - 6) / 3], v = bx_[(a - 6) % 3];
                x = u[1] * v[2] - u[2] * v[1]; y = u[2] * v[0] - u[0] * v[2]; z = u[0] * v[1] - u[1] * v[0];
                double l = Math.sqrt(x * x + y * y + z * z);
                if (l < 1e-6) continue;
                x /= l; y /= l; z /= l;
            }
            double dist = dx * x + dy * y + dz * z;
            double ov = proj(A, x, y, z) + proj(B, x, y, z) - Math.abs(dist);
            if (ov <= 0) return false;
            double w = a < 6 ? 1.0 : 1.05; // грани предпочтительнее рёбер
            if (ov * w < best) { best = ov * w; double sg = dist < 0 ? -1 : 1; bx = x * sg; by = y * sg; bz = z * sg; out.depth = ov; }
        }
        out.nx = bx; out.ny = by; out.nz = bz;
        // точка контакта: середина между самыми глубокими вершинами
        double sa0 = sgn(A.ux, bx, by, bz), sa1 = sgn(A.uy, bx, by, bz), sa2 = sgn(A.uz, bx, by, bz);
        double pax = A.cx - sa0 * A.hx * A.ux[0] - sa1 * A.hy * A.uy[0] - sa2 * A.hz * A.uz[0];
        double pay = A.cy - sa0 * A.hx * A.ux[1] - sa1 * A.hy * A.uy[1] - sa2 * A.hz * A.uz[1];
        double paz = A.cz - sa0 * A.hx * A.ux[2] - sa1 * A.hy * A.uy[2] - sa2 * A.hz * A.uz[2];
        double sb0 = sgn(B.ux, bx, by, bz), sb1 = sgn(B.uy, bx, by, bz), sb2 = sgn(B.uz, bx, by, bz);
        double pbx = B.cx + sb0 * B.hx * B.ux[0] + sb1 * B.hy * B.uy[0] + sb2 * B.hz * B.uz[0];
        double pby = B.cy + sb0 * B.hx * B.ux[1] + sb1 * B.hy * B.uy[1] + sb2 * B.hz * B.uz[1];
        double pbz = B.cz + sb0 * B.hx * B.ux[2] + sb1 * B.hy * B.uy[2] + sb2 * B.hz * B.uz[2];
        out.px = (pax + pbx) / 2; out.py = (pay + pby) / 2; out.pz = (paz + pbz) / 2;
        return true;
    }

    private static double sgn(double[] u, double nx, double ny, double nz) { return (u[0] * nx + u[1] * ny + u[2] * nz) > 0 ? 1 : -1; }

    private static double[] vel(RigidBody b, double rx, double ry, double rz) {
        return new double[]{b.vx + (b.wy * rz - b.wz * ry), b.vy + (b.wz * rx - b.wx * rz), b.vz + (b.wx * ry - b.wy * rx)};
    }

    /** Машина против машины. Возвращает скорость сближения (м/с), 0 если нет удара. */
    public static double resolveCars(VehicleSim a, VehicleSim b) {
        Obb A = new Obb(), B = new Obb(); hullOf(a, A); hullOf(b, B);
        double dxy = Math.hypot(A.cx - B.cx, A.cz - B.cz);
        if (dxy > A.hz + B.hz + 1.5) return 0;
        Hit h = new Hit();
        if (!sat(A, B, h)) return 0;
        RigidBody ra = a.body, rb = b.body;
        double rax = h.px - ra.px, ray = h.py - ra.py, raz = h.pz - ra.pz;
        double rbx = h.px - rb.px, rby = h.py - rb.py, rbz = h.pz - rb.pz;
        double[] va = vel(ra, rax, ray, raz), vb = vel(rb, rbx, rby, rbz);
        double vn = (va[0] - vb[0]) * h.nx + (va[1] - vb[1]) * h.ny + (va[2] - vb[2]) * h.nz;
        double speed = Math.max(0, -vn);
        if (vn < 0) {
            double K = a.kEff(rax, ray, raz, h.nx, h.ny, h.nz) + b.kEff(rbx, rby, rbz, h.nx, h.ny, h.nz);
            double e = speed > 3 ? 0.15 : 0;
            double j = -(1 + e) * vn / K;
            a.impulseAt(rax, ray, raz, h.nx * j, h.ny * j, h.nz * j);
            b.impulseAt(rbx, rby, rbz, -h.nx * j, -h.ny * j, -h.nz * j);
            if (speed > 2) { a.addCrashDv(j / ra.mass); b.addCrashDv(j / rb.mass); }
            if (speed > 4) { // оба корпуса сминаются в зонах удара
                double cr = Math.min(0.6, 0.03 * (speed - 3));
                a.addCrush(h.nx, h.ny, h.nz, cr); b.addCrush(-h.nx, -h.ny, -h.nz, cr);
            }
            // трение по касательной
            double tx = (va[0] - vb[0]) - vn * h.nx, ty = (va[1] - vb[1]) - vn * h.ny, tz = (va[2] - vb[2]) - vn * h.nz;
            double tm = Math.sqrt(tx * tx + ty * ty + tz * tz);
            if (tm > 1e-6) {
                double Kt = a.kEff(rax, ray, raz, tx / tm, ty / tm, tz / tm) + b.kEff(rbx, rby, rbz, tx / tm, ty / tm, tz / tm);
                double jt = Math.min(tm / Kt, 0.3 * j);
                a.impulseAt(rax, ray, raz, -tx / tm * jt, -ty / tm * jt, -tz / tm * jt);
                b.impulseAt(rbx, rby, rbz, tx / tm * jt, ty / tm * jt, tz / tm * jt);
            }
        }
        double d = Math.min(h.depth, 0.6) * 0.8, mt = ra.mass + rb.mass;
        ra.px += h.nx * d * rb.mass / mt; ra.py += h.ny * d * rb.mass / mt; ra.pz += h.nz * d * rb.mass / mt;
        rb.px -= h.nx * d * ra.mass / mt; rb.py -= h.ny * d * ra.mass / mt; rb.pz -= h.nz * d * ra.mass / mt;
        a.recordImpact(rax, ray, raz, h.nx, h.ny, h.nz, speed);
        b.recordImpact(rbx, rby, rbz, -h.nx, -h.ny, -h.nz, speed);
        return speed;
    }

    /**
     * Машина против существа (бокс). ev - скорость существа (м/с), изменяется. pushOut - вектор, на который надо
     * сдвинуть существо (из бокса). Возвращает скорость сближения или 0.
     */
    public static double resolveEntity(VehicleSim a, double x0, double y0, double z0, double x1, double y1, double z1,
                                       double entityMass, double[] ev, double[] pushOut) {
        Obb A = new Obb(), B = new Obb(); hullOf(a, A); aabb(x0, y0, z0, x1, y1, z1, B);
        Hit h = new Hit();
        if (!sat(A, B, h)) return 0;
        if (h.ny < -0.7) return 0; // существо стоит сверху: это вес, а не удар
        RigidBody ra = a.body;
        double rax = h.px - ra.px, ray = h.py - ra.py, raz = h.pz - ra.pz;
        double[] va = vel(ra, rax, ray, raz);
        double vn = (va[0] - ev[0]) * h.nx + (va[1] - ev[1]) * h.ny + (va[2] - ev[2]) * h.nz;
        double speed = Math.max(0, -vn);
        if (vn < 0) {
            double K = a.kEff(rax, ray, raz, h.nx, h.ny, h.nz) + 1.0 / entityMass;
            double j = -(1.15) * vn / K;
            a.impulseAt(rax, ray, raz, h.nx * j, h.ny * j, h.nz * j);
            ev[0] -= h.nx * j / entityMass; ev[1] -= h.ny * j / entityMass; ev[2] -= h.nz * j / entityMass;
            a.recordImpact(rax, ray, raz, h.nx, h.ny, h.nz, speed * Math.min(1.0, entityMass / 400.0));
        }
        double d = Math.min(h.depth, 1.0);
        pushOut[0] = -h.nx * d; pushOut[1] = -h.ny * d; pushOut[2] = -h.nz * d;
        return speed;
    }

    private VehicleCollision() {}
}
