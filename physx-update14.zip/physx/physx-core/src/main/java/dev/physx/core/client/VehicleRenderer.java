package dev.physx.core.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.physx.core.PhysxCore;
import dev.physx.core.entity.VehicleEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.Map;

/** Рисует Chevrolet K5 Blazer (масштаб 1.2): колёса ходят вместе с подвеской, кузов с вмятинами. */
public class VehicleRenderer extends EntityRenderer<VehicleEntity> {
    private static final ResourceLocation MODEL =
            ResourceLocation.fromNamespaceAndPath(PhysxCore.MODID, "models/vehicle/blazer.pxm");
    private static final ResourceLocation WHITE = ResourceLocation.withDefaultNamespace("textures/block/white_concrete.png");
    /** Центры колёс в системе модели (единицы модели, ноль по z в центре масс). */
    private static final float WX = 0.9058f, FRONT_Z = 1.2864f, REAR_Z = -1.50f;
    private static VehicleMesh mesh;
    /** Границы модели (единицы модели) и длина зон смятия. */
    private static final float Z_FRONT = 2.18f, Z_REAR = -2.64f, X_HALF = 1.06f, Y_TOP = 2.0f;
    private static final float L_FRONT = 1.7f, L_REAR = 1.4f, L_SIDE = 0.9f, L_TOP = 0.9f;

    private static final class Cache { int hash = Integer.MIN_VALUE; float[][] v; }
    private static final Map<Integer, Cache> CACHE = new HashMap<>();

    public VehicleRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override
    public ResourceLocation getTextureLocation(VehicleEntity e) { return WHITE; }

    @Override
    public void render(VehicleEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        if (mesh == null) mesh = VehicleMesh.load(MODEL);
        float S = (float) VehicleEntity.SCALE;
        ps.pushPose();
        ps.translate(0, VehicleEntity.COM_Y, 0);
        ps.mulPose(e.getRenderQuat(pt));
        ps.translate(0, -VehicleEntity.COM_H, 0); // y = 0 это земля при стоянке
        ps.scale(S, S, S);

        float[][] def = deformed(e);
        VehicleMesh.draw(mesh.body, buf, ps.last(), light, false, def);

        float steer = e.getRenderSteer(pt), spin = e.getRenderSpin(pt);
        int[] crI = e.getDentsTag().getIntArray("c");
        float[] cw = new float[5]; // смятие в единицах модели (для сдвига колёс)
        for (int k = 0; k < 5 && k < crI.length; k++) cw[k] = (float) (Float.intBitsToFloat(crI[k]) / S);
        for (int i = 0; i < 4; i++) {
            boolean front = i < 2, left = (i % 2) == 0;
            float len = e.getWheelLen(i);
            float wy = (float) ((VehicleEntity.COM_H + VehicleEntity.MOUNT_Y - (len > 0.01f ? len : VehicleEntity.MAX_LEN)) / S);
            ps.pushPose();
            float wz = front ? FRONT_Z : REAR_Z, wx = left ? WX : -WX;
            // колесо смещается вместе с той частью кузова, на которой стоит
            if (front) wz -= cw[0] * 0.43f; else wz += cw[1] * 0.17f;
            wx += left ? -cw[2] * 0.76f : cw[3] * 0.76f;
            ps.translate(wx, wy, wz);
            if (front) ps.mulPose(Axis.YP.rotation(steer));
            ps.mulPose(Axis.XP.rotation(spin));
            if (!left) ps.mulPose(Axis.YP.rotation((float) Math.PI));
            VehicleMesh.draw(mesh.wheel, buf, ps.last(), light, false);
            ps.popPose();
        }

        VehicleMesh.draw(mesh.body, buf, ps.last(), light, true, def); // стёкла и значки в конце
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    /** Кузов с вмятинами. Пересчитывается только при изменении вмятин. */
    private static float[][] deformed(VehicleEntity e) {
        CompoundTag tag = e.getDentsTag();
        int[] a = tag.getIntArray("d");
        int[] cr = tag.getIntArray("c");
        boolean anyCrush = false;
        for (int x : cr) if (Float.intBitsToFloat(x) > 0.001f) anyCrush = true;
        if (a.length == 0 && !anyCrush) { CACHE.remove(e.getId()); return null; }
        int h = java.util.Arrays.hashCode(a) * 31 + java.util.Arrays.hashCode(cr);
        Cache c = CACHE.computeIfAbsent(e.getId(), k -> new Cache());
        if (CACHE.size() > 64) { CACHE.clear(); c = CACHE.computeIfAbsent(e.getId(), k -> new Cache()); }
        if (c.hash == h && c.v != null) return c.v;
        double S = VehicleEntity.SCALE;
        int n = a.length / 8;
        float[][] d = new float[n][8];
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < 8; k++) d[i][k] = Float.intBitsToFloat(a[i * 8 + k]);
            // в единицы модели: x/S, (y + COM_H)/S, z/S
            d[i][0] = (float) (d[i][0] / S); d[i][1] = (float) ((d[i][1] + VehicleEntity.COM_H) / S); d[i][2] = (float) (d[i][2] / S);
            d[i][6] = (float) (d[i][6] / S); d[i][7] = (float) (d[i][7] / S);
        }
        float[] cs = new float[5]; // смятие в единицах модели
        for (int i = 0; i < 5 && i < cr.length; i++) cs[i] = (float) (Float.intBitsToFloat(cr[i]) / S);
        float[][] out = new float[mesh.body.size()][];
        for (int pi = 0; pi < out.length; pi++) {
            float[] src = mesh.body.get(pi).v;
            float[] v = src.clone();
            for (int o = 0; o + 7 < v.length; o += 8) {
                float x = v[o], y = v[o + 1], z = v[o + 2];
                float ox = 0, oy = 0, oz = 0;
                for (float[] t : d) {
                    float dx = x - t[0], dy = y - t[1], dz = z - t[2];
                    float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (dist >= t[7]) continue;
                    float f = 1f - dist / t[7];
                    f = f * f * (0.8f + 0.2f * (float) Math.sin(41 * x + 23 * y + 57 * z)); // неровная, "мятая" поверхность
                    ox += t[3] * t[6] * f; oy += t[4] * t[6] * f; oz += t[5] * t[6] * f;
                }
                x += ox; y += oy; z += oz;
                // зоны смятия укорачивают кузов с постепенным затуханием вглубь
                if (cs[0] > 0 && z > Z_FRONT - L_FRONT) { float t = (z - (Z_FRONT - L_FRONT)) / L_FRONT; z -= cs[0] * t * (0.85f + 0.15f * (float) Math.sin(29 * x + 17 * y)); }
                if (cs[1] > 0 && z < Z_REAR + L_REAR) { float t = ((Z_REAR + L_REAR) - z) / L_REAR; z += cs[1] * t * (0.85f + 0.15f * (float) Math.sin(31 * x + 13 * y)); }
                if (cs[2] > 0 && x > X_HALF - L_SIDE) { float t = (x - (X_HALF - L_SIDE)) / L_SIDE; x -= cs[2] * t; }
                if (cs[3] > 0 && x < -X_HALF + L_SIDE) { float t = ((-X_HALF + L_SIDE) - x) / L_SIDE; x += cs[3] * t; }
                if (cs[4] > 0 && y > Y_TOP - L_TOP) { float t = (y - (Y_TOP - L_TOP)) / L_TOP; y -= cs[4] * t; }
                v[o] = x; v[o + 1] = y; v[o + 2] = z;
            }
            out[pi] = v;
        }
        c.hash = h; c.v = out;
        return out;
    }
}
