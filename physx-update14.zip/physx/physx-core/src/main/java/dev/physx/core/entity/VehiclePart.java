package dev.physx.core.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.entity.PartEntity;

/** Часть хитбокса машины: на ней можно стоять. Клики и удары передаются самой машине. */
public class VehiclePart extends PartEntity<VehicleEntity> {
    private final EntityDimensions size;

    public VehiclePart(VehicleEntity parent, float width, float height) {
        super(parent);
        this.size = EntityDimensions.scalable(width, height);
        this.refreshDimensions();
    }

    @Override protected void defineSynchedData(SynchedEntityData.Builder b) {}
    @Override protected void readAdditionalSaveData(CompoundTag t) {}
    @Override protected void addAdditionalSaveData(CompoundTag t) {}

    @Override public boolean isPickable() { return true; }
    @Override public boolean canBeCollidedWith() { return true; }
    @Override public InteractionResult interact(Player p, InteractionHand h) { return getParent().interact(p, h); }
    @Override public boolean hurt(DamageSource s, float a) { return !isInvulnerableTo(s) && getParent().hurt(s, a); }
    @Override public boolean is(Entity e) { return this == e || getParent() == e; }
    @Override public EntityDimensions getDimensions(Pose pose) { return size; }
}
