package dev.physx.core.vehicle;

public interface GroundProbe {
    /** Расстояние до поверхности вдоль луча или -1, если не попали. */
    double cast(double ox, double oy, double oz, double dx, double dy, double dz, double maxLen);
    /** Сцепление поверхности последнего попадания (1.0 = асфальт, ~0.2 = лёд). */
    double grip();
    /**
     * Твёрдые боксы мира в области. Формат out: по 7 чисел на бокс:
     * minX,minY,minZ,maxX,maxY,maxZ,флаги. Флаги (биты): 1=-X,2=+X,4=-Y,8=+Y,16=-Z,32=+Z закрыты соседним
     * полным блоком (внутренняя грань, на ней нет столкновения). Возвращает число боксов.
     */
    default int boxes(double x0, double y0, double z0, double x1, double y1, double z1, double[] out, int maxBoxes) {
        return 0;
    }
}
