package dev.physx.core.client;

import dev.physx.core.PhysxCore;
import dev.physx.core.entity.VehicleEntity;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ViewportEvent;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Камера кренится вместе с кузовом (как и модель водителя). */
@EventBusSubscriber(modid = PhysxCore.MODID, value = Dist.CLIENT)
public final class CameraTilt {
    @SubscribeEvent
    public static void angles(ViewportEvent.ComputeCameraAngles e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !(mc.player.getVehicle() instanceof VehicleEntity car)) return;
        Quaternionf q = car.getRenderQuat((float) e.getPartialTick());
        Vector3f fwd = q.transform(new Vector3f(0, 0, 1));
        float h = (float) Math.atan2(-fwd.x, fwd.z);
        Quaternionf tilt = new Quaternionf(q).mul(new Quaternionf().rotationY(h)); // без рыскания

        double yaw = Math.toRadians(e.getYaw()), pitch = Math.toRadians(e.getPitch());
        Vector3f f = new Vector3f((float) (-Math.sin(yaw) * Math.cos(pitch)), (float) (-Math.sin(pitch)), (float) (Math.cos(yaw) * Math.cos(pitch)));
        Vector3f u0 = new Vector3f(0, 1, 0).sub(new Vector3f(f).mul(f.y));
        if (u0.lengthSquared() < 1e-4f) return;
        u0.normalize();
        Vector3f up = tilt.transform(new Vector3f(0, 1, 0));
        up.sub(new Vector3f(f).mul(up.dot(f)));
        if (up.lengthSquared() < 1e-4f) return;
        up.normalize();
        float cos = u0.dot(up);
        float sin = new Vector3f(u0).cross(up).dot(f);
        e.setRoll(e.getRoll() + (float) Math.toDegrees(Math.atan2(sin, cos)));
    }

    private CameraTilt() {}
}
