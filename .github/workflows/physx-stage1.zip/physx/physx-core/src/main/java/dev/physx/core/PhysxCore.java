package dev.physx.core;

import net.neoforged.fml.common.Mod;

@Mod(PhysxCore.MODID)
public class PhysxCore {
    public static final String MODID = "physx_core";
    public PhysxCore() {}
}
