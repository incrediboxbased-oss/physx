package dev.physx.core.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.physx.core.PhysxCore;
import dev.physx.core.entity.VehicleEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.Map;

/** Рисует Chevrolet K5 Blazer (масштаб 1.2): колёса ходят вместе с подвеской, кузов с вмятинами. */
public class VehicleRenderer extends EntityRenderer<VehicleEntity> {
    private static final ResourceLocation MODEL =
            ResourceLocation.fromNamespaceAndPath(PhysxCore.MODID, "models/vehicle/blazer.pxm");
    private static final ResourceLocation WHITE = ResourceLocation.withDefaultNamespace("textures/block/white_concrete.png");
    /** Центры колёс в системе модели (единицы модели, ноль по z в центре масс). */
    private static final float WX = 0.9058f, FRONT_Z = 1.2864f, REAR_Z = -1.50f;
    private static VehicleMesh mesh;

    private static final class Cache { int hash = Integer.MIN_VALUE; float[][] v; }
    private static final Map<Integer, Cache> CACHE = new HashMap<>();

    public VehicleRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override
    public ResourceLocation getTextureLocation(VehicleEntity e) { return WHITE; }

    @Override
    public void render(VehicleEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        if (mesh == null) mesh = VehicleMesh.load(MODEL);
        float S = (float) VehicleEntity.SCALE;
        ps.pushPose();
        ps.translate(0, VehicleEntity.COM_Y, 0);
        ps.mulPose(e.getRenderQuat(pt));
        ps.translate(0, -VehicleEntity.COM_H, 0); // y = 0 это земля при стоянке
        ps.scale(S, S, S);

        float[][] def = deformed(e);
        VehicleMesh.draw(mesh.body, buf, ps.last(), light, false, def);

        float steer = e.getRenderSteer(pt), spin = e.getRenderSpin(pt);
        for (int i = 0; i < 4; i++) {
            boolean front = i < 2, left = (i % 2) == 0;
            float len = e.getWheelLen(i);
            float wy = (float) ((VehicleEntity.COM_H + VehicleEntity.MOUNT_Y - (len > 0.01f ? len : VehicleEntity.MAX_LEN)) / S);
            ps.pushPose();
            ps.translate(left ? WX : -WX, wy, front ? FRONT_Z : REAR_Z);
            if (front) ps.mulPose(Axis.YP.rotation(steer));
            ps.mulPose(Axis.XP.rotation(spin));
            if (!left) ps.mulPose(Axis.YP.rotation((float) Math.PI));
            VehicleMesh.draw(mesh.wheel, buf, ps.last(), light, false);
            ps.popPose();
        }

        VehicleMesh.draw(mesh.body, buf, ps.last(), light, true, def); // стёкла и значки в конце
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    /** Кузов с вмятинами. Пересчитывается только при изменении вмятин. */
    private static float[][] deformed(VehicleEntity e) {
        CompoundTag tag = e.getDentsTag();
        int[] a = tag.getIntArray("d");
        if (a.length == 0) { CACHE.remove(e.getId()); return null; }
        int h = java.util.Arrays.hashCode(a);
        Cache c = CACHE.computeIfAbsent(e.getId(), k -> new Cache());
        if (CACHE.size() > 64) { CACHE.clear(); c = CACHE.computeIfAbsent(e.getId(), k -> new Cache()); }
        if (c.hash == h && c.v != null) return c.v;
        double S = VehicleEntity.SCALE;
        int n = a.length / 8;
        float[][] d = new float[n][8];
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < 8; k++) d[i][k] = Float.intBitsToFloat(a[i * 8 + k]);
            // в единицы модели: x/S, (y + COM_H)/S, z/S
            d[i][0] = (float) (d[i][0] / S); d[i][1] = (float) ((d[i][1] + VehicleEntity.COM_H) / S); d[i][2] = (float) (d[i][2] / S);
            d[i][6] = (float) (d[i][6] / S); d[i][7] = (float) (d[i][7] / S);
        }
        float[][] out = new float[mesh.body.size()][];
        for (int pi = 0; pi < out.length; pi++) {
            float[] src = mesh.body.get(pi).v;
            float[] v = src.clone();
            for (int o = 0; o + 7 < v.length; o += 8) {
                float x = v[o], y = v[o + 1], z = v[o + 2];
                float ox = 0, oy = 0, oz = 0;
                for (float[] t : d) {
                    float dx = x - t[0], dy = y - t[1], dz = z - t[2];
                    float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (dist >= t[7]) continue;
                    float f = 1f - dist / t[7];
                    f = f * f * (0.8f + 0.2f * (float) Math.sin(41 * x + 23 * y + 57 * z)); // неровная, "мятая" поверхность
                    ox += t[3] * t[6] * f; oy += t[4] * t[6] * f; oz += t[5] * t[6] * f;
                }
                v[o] = x + ox; v[o + 1] = y + oy; v[o + 2] = z + oz;
            }
            out[pi] = v;
        }
        c.hash = h; c.v = out;
        return out;
    }
}
