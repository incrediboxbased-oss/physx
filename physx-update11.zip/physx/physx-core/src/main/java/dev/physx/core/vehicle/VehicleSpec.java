package dev.physx.core.vehicle;

/** Параметры машины. Позже будут читаться из JSON датапака. */
public final class VehicleSpec {
    public double mass = 1200, ix = 1796, iy = 2000, iz = 596;
    public double frontAxleZ = 1.3, rearAxleZ = -1.3, halfTrack = 0.8, mountY = 0.25;
    public double wheelRadius = 0.34, wheelInertia = 1.5;
    public double springK = 35000, damperC = 3200, maxLen = 0.5, bumpLen = 0.08;
    public double maxBrakeTorque = 1300, handbrakeTorque = 2200;
    public double steerLow = 0.55, steerHigh = 0.06, steerSpeedRef = 18;
    public double mu = 1.15;
    public double cd = 0.32, frontalArea = 2.2, downforceCoef = 0.15, sideCd = 1.0, sideArea = 5.0, aeroCenterZ = -0.3;
    public boolean tractionControl = true;
    public double rollingResistance = 0.015;
    public final Drivetrain drivetrain = new Drivetrain();

    // оболочка корпуса: ориентированный бокс (OBB) в осях корпуса, относительно центра масс
    public double hullHx = 0.95, hullHy = 0.675, hullHz = 2.2, hullCy = 0.719, hullCz = 0;
    // контакт со ступеньками и стенами
    public double crashForceG = 60; // предел пиковой силы удара о стену в g массы машины
    public double contactRestitution = 0.05, groundFriction = 0.6, wallFriction = 0.06, stepRise = 1.5;
    /** Препятствия ниже (уровень земли под колёсами + stepHeight) машина не считает стеной, а наезжает на них. */
    public double stepHeight = 1.15;
    /** Силы подъёма в долях веса машины; предел силы подвески в долях статической нагрузки колеса. */
    public double stepForceG = 1.0, climbAssistG = 0.45, suspCapFactor = 2.5;
    /** Как быстро (м/с) "земля" под колесом может подниматься при наезде на ступеньку. */
    public double groundRiseRate = 4.0;
    /** Торможение при наезде на ступеньку (1/с): скорость гаснет за 1/stepDamping секунд. */
    public double stepDamping = 3.0;
    /** Подъём начала луча колеса: колесо видит ступеньки выше своей оси. */
    public double rayLift = 0.5, stepLead = 0.28;

    public static VehicleSpec sportsCar() { return new VehicleSpec(); }

    /** Масштаб модели Blazer (больше игрока, чтобы водитель помещался). */
    public static final double BLAZER_SCALE = 1.2;
    /** Днище и крыша корпуса над землёй в покое (для хитбокса и стоянки). */
    public double hullFloor = 0.4, hullTop = 2.0;
    /** Жёсткость стабилизатора поперечной устойчивости (Н/м разницы хода подвески левого и правого колеса). */
    public double arbK = 0;
    /** Составной корпус для столкновений с блоками (если null - одна коробка hull*). Оси корпуса, от центра масс. */
    public double[] partCy, partCz, partHx, partHy, partHz;

    /** Высота центра масс над землёй в покое. */
    public double restComHeight() { return maxLen - mass * 9.81 / 4.0 / springK + wheelRadius - mountY; }

    /** Chevrolet K5 Blazer 1978 (масштаб 1.2): 3 т, V8, 4-ступенчатая коробка. Начало координат = центр масс. */
    public static VehicleSpec blazer() {
        double S = BLAZER_SCALE;
        VehicleSpec s = new VehicleSpec();
        s.mass = 3000; s.ix = 9475; s.iy = 9740; s.iz = 2610;
        s.frontAxleZ = 1.286 * S; s.rearAxleZ = -1.50 * S; s.halfTrack = 0.906 * S; s.mountY = 0.20;
        s.wheelRadius = 0.42 * S; s.wheelInertia = 5.0;
        s.maxLen = 0.5 * S; s.bumpLen = 0.10; s.springK = 73000;
        s.damperC = 0.6 * 2 * Math.sqrt(73000 * 3000 / 4.0);
        s.arbK = 0.6 * s.springK;
        s.maxBrakeTorque = 3600; s.handbrakeTorque = 5000;
        s.steerLow = 0.50; s.steerHigh = 0.06; s.mu = 1.15;
        s.cd = 0.42; s.frontalArea = 2.9 * S * S; s.downforceCoef = 0.0; s.sideCd = 1.1; s.sideArea = 7.0 * S * S; s.aeroCenterZ = -0.36;
        s.hullFloor = 0.40 * S; s.hullTop = 2.0 * S;
        double comH = s.restComHeight();
        s.hullHx = 1.0 * S; s.hullHz = 2.41 * S; s.hullCz = -0.23 * S;
        s.hullHy = (s.hullTop - s.hullFloor) / 2; s.hullCy = (s.hullTop + s.hullFloor) / 2 - comH;
        // составной корпус: днище по центру низкое, нос и корма приподняты (угол въезда/съезда)
        double[][] pr = {  // zMin, zMax, пол (от земли), верх, полуширина
                {-2.45, 1.80, 0.48, 2.40, 1.20},
                {1.80, 2.61, 0.85, 1.50, 1.15},
                {-3.17, -2.45, 0.80, 2.40, 1.15}};
        int np = pr.length;
        s.partCy = new double[np]; s.partCz = new double[np]; s.partHx = new double[np]; s.partHy = new double[np]; s.partHz = new double[np];
        for (int i = 0; i < np; i++) {
            s.partCz[i] = (pr[i][0] + pr[i][1]) / 2; s.partHz[i] = (pr[i][1] - pr[i][0]) / 2;
            s.partCy[i] = (pr[i][2] + pr[i][3]) / 2 - comH; s.partHy[i] = (pr[i][3] - pr[i][2]) / 2; s.partHx[i] = pr[i][4];
        }
        s.stepHeight = 1.4; s.rayLift = 0.6; s.stepLead = 0.85 * s.wheelRadius; s.climbAssistG = 1.0;
        Drivetrain d = s.drivetrain;
        d.rpmPts = new double[]{0, 1000, 2000, 3000, 4000, 5000, 6000, 7000};
        d.nmPts = new double[]{574, 803, 975, 1089, 1056, 941, 745, 516};
        d.idle = 700; d.redline = 6000; d.launchRpm = 2200;
        d.gears = new double[]{2.8, 1.7, 1.0, 0.75}; d.reverseRatio = -2.4; d.finalDrive = 3.3; d.engineBrakeNm = 180;
        return s;
    }
}
