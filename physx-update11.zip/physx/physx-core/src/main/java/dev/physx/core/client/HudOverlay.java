package dev.physx.core.client;

import dev.physx.core.entity.VehicleEntity;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Приборная панель в стиле BeamNG: круговой тахометр, скорость, передача, педали, руль, индикаторы. */
public final class HudOverlay {
    private static float shownRpm, shownSpeed, shownSteer;

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        if (!(mc.player.getVehicle() instanceof VehicleEntity car)) { shownRpm = 0; shownSpeed = 0; shownSteer = 0; return; }
        Font font = mc.font;

        int R = 42;
        int cx = g.guiWidth() - R - 34, cy = g.guiHeight() - R - 26;
        float redline = car.getHudRpmMax();
        float scaleMax = (float) (Math.ceil((redline + 500f) / 1000f) * 1000f);

        shownSpeed += (car.getHudSpeedKmh() - shownSpeed) * 0.3f;
        shownRpm += (car.getHudRpm() - shownRpm) * 0.35f;
        shownSteer += (car.getHudSteer() - shownSteer) * 0.4f;

        // подложка
        for (int dy = -R - 5; dy <= R + 5; dy++) {
            int half = (int) Math.sqrt((R + 5) * (R + 5) - dy * dy);
            g.fill(cx - half, cy + dy, cx + half, cy + dy + 1, 0xA0101214);
        }

        // шкала оборотов: фон, красная зона, заполнение
        double aStart = Math.toRadians(225), sweep = Math.toRadians(270);
        arc(g, cx, cy, R - 8, R, aStart, 0, 1, 0x80404448);
        double redFrac = redline / scaleMax;
        arc(g, cx, cy, R - 8, R, aStart, redFrac, 1, 0xC0802020);
        double frac = Math.min(1.0, shownRpm / scaleMax);
        for (double f = 0; f <= frac; f += 0.0075) {
            int col = f < redFrac * 0.8 ? 0xFF35D07F : f < redFrac ? 0xFFF2C94C : 0xFFEB4D4B;
            arcStep(g, cx, cy, R - 8, R, aStart - sweep * f, col);
        }
        // цифры шкалы (тысячи оборотов)
        for (int k = 0; k * 1000 <= scaleMax; k++) {
            double a = aStart - sweep * (k * 1000.0 / scaleMax);
            String t = String.valueOf(k);
            int x = (int) Math.round(cx + Math.cos(a) * (R - 15)), y = (int) Math.round(cy - Math.sin(a) * (R - 15));
            g.drawString(font, t, x - font.width(t) / 2, y - 4, k * 1000 > redline ? 0xFFEB4D4B : 0xFFDDDDDD, false);
        }

        // скорость
        String sp = String.valueOf(Math.round(Math.abs(shownSpeed)));
        g.pose().pushPose();
        g.pose().translate(cx, cy - 14, 0);
        g.pose().scale(2.0f, 2.0f, 1.0f);
        g.drawString(font, sp, -font.width(sp) / 2, 0, 0xFFFFFFFF, false);
        g.pose().popPose();
        g.drawString(font, "км/ч", cx - font.width("км/ч") / 2, cy + 3, 0xFFAAAAAA, false);

        // передача и тип коробки
        int gear = car.getHudGear();
        String gs = gear < 0 ? "R" : gear == 0 ? "N" : String.valueOf(gear);
        g.pose().pushPose();
        g.pose().translate(cx, cy + 13, 0);
        g.pose().scale(1.5f, 1.5f, 1.0f);
        g.drawString(font, gs, -font.width(gs) / 2, 0, 0xFFFFD34D, false);
        g.pose().popPose();
        String bt = car.getHudManual() ? "МКПП" : "АКПП";
        g.drawString(font, bt, cx - font.width(bt) / 2, cy + 27, 0xFF9AA0A6, false);

        // педали: газ (зелёная) и тормоз (красная)
        int px = cx - R - 14, pb = cy + 28, ph = 56;
        bar(g, px, pb, ph, car.getHudThrottle(), 0xFF35D07F);
        bar(g, px + 7, pb, ph, car.getHudBrake(), 0xFFEB4D4B);

        // руль
        int sy = cy + R + 10;
        g.fill(cx - 30, sy, cx + 30, sy + 3, 0xA0202428);
        float sf = Math.max(-1f, Math.min(1f, shownSteer / 0.55f));
        int mx = cx - Math.round(sf * 28); // положительный угол = влево
        g.fill(mx - 2, sy - 2, mx + 3, sy + 5, 0xFFFFFFFF);

        // индикаторы
        int ix = cx - 30, iy = sy + 9;
        chip(g, font, ix, iy, "ТС", car.getHudTcActive() ? 0xFFF2C94C : car.getHudTcEnabled() ? 0xFF35D07F : 0xFF555A5F);
        chip(g, font, ix + 22, iy, "РУЧ", car.getHudHandbrake() ? 0xFFEB4D4B : 0xFF555A5F);
    }

    private static void arc(GuiGraphics g, int cx, int cy, int r0, int r1, double aStart, double f0, double f1, int col) {
        double sweep = Math.toRadians(270);
        for (double f = f0; f <= f1; f += 0.0075) arcStep(g, cx, cy, r0, r1, aStart - sweep * f, col);
    }

    private static void arcStep(GuiGraphics g, int cx, int cy, int r0, int r1, double a, int col) {
        double c = Math.cos(a), s = Math.sin(a);
        for (int r = r0; r <= r1; r += 2) {
            int x = (int) Math.round(cx + c * r), y = (int) Math.round(cy - s * r);
            g.fill(x - 1, y - 1, x + 2, y + 2, col);
        }
    }

    private static void bar(GuiGraphics g, int x, int bottom, int h, float v, int col) {
        g.fill(x, bottom - h, x + 5, bottom, 0xA0202428);
        int fh = Math.round(h * Math.max(0f, Math.min(1f, v)));
        if (fh > 0) g.fill(x, bottom - fh, x + 5, bottom, col);
    }

    private static void chip(GuiGraphics g, Font font, int x, int y, String text, int col) {
        int w = font.width(text) + 4;
        g.fill(x, y, x + w, y + 10, 0xA0202428);
        g.fill(x, y + 9, x + w, y + 10, col);
        g.drawString(font, text, x + 2, y + 1, col, false);
    }

    private HudOverlay() {}
}
