package dev.physx.core;

import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

@Mod(PhysxCore.MODID)
public class PhysxCore {
    public static final String MODID = "physx_core";

    public PhysxCore(IEventBus modBus) {
        ModRegistry.ENTITIES.register(modBus);
        ModRegistry.ITEMS.register(modBus);
        modBus.addListener(PhysxCore::addToTab);
    }

    private static void addToTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) e.accept(ModRegistry.TEST_CAR_ITEM.get());
    }
}
