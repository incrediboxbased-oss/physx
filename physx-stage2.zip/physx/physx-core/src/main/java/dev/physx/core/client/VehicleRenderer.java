package dev.physx.core.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.physx.core.entity.VehicleEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Простая модель из параллелепипедов: кузов, кабина, 4 колёса (вращаются и поворачиваются). */
public class VehicleRenderer extends EntityRenderer<VehicleEntity> {
    private static final ResourceLocation BODY = ResourceLocation.withDefaultNamespace("textures/block/white_concrete.png");
    private static final ResourceLocation TIRE = ResourceLocation.withDefaultNamespace("textures/block/black_concrete.png");

    public VehicleRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override
    public ResourceLocation getTextureLocation(VehicleEntity e) { return BODY; }

    @Override
    public void render(VehicleEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        ps.translate(0, VehicleEntity.COM_Y, 0);
        ps.mulPose(e.getRenderQuat(pt));

        VertexConsumer body = buf.getBuffer(RenderType.entityCutoutNoCull(BODY));
        box(ps.last(), body, -0.9f, -0.2f, -2.0f, 0.9f, 0.1f, 2.0f, light, 200, 30, 30);
        box(ps.last(), body, -0.8f, 0.1f, -0.9f, 0.8f, 0.65f, 0.5f, light, 170, 25, 25);

        VertexConsumer tire = buf.getBuffer(RenderType.entityCutoutNoCull(TIRE));
        float steer = e.getRenderSteer(pt), spin = e.getRenderSpin(pt);
        for (int i = 0; i < 4; i++) {
            boolean front = i < 2, left = (i % 2) == 0;
            ps.pushPose();
            ps.translate(left ? 0.8f : -0.8f, -0.166f, front ? 1.3f : -1.3f);
            if (front) ps.mulPose(Axis.YP.rotation(steer));
            ps.mulPose(Axis.XP.rotation(spin));
            box(ps.last(), tire, -0.13f, -0.34f, -0.34f, 0.13f, 0.34f, 0.34f, light, 255, 255, 255);
            ps.popPose();
        }
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    private static void box(PoseStack.Pose p, VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1,
                            int l, int r, int g, int b) {
        quad(p, c, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, 0, 1, 0, l, r, g, b);
        quad(p, c, x0, y0, z1, x0, y0, z0, x1, y0, z0, x1, y0, z1, 0, -1, 0, l, r, g, b);
        quad(p, c, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, 1, 0, 0, l, r, g, b);
        quad(p, c, x0, y0, z1, x0, y1, z1, x0, y1, z0, x0, y0, z0, -1, 0, 0, l, r, g, b);
        quad(p, c, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1, l, r, g, b);
        quad(p, c, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0, 0, -1, l, r, g, b);
    }

    private static void quad(PoseStack.Pose p, VertexConsumer c,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float nx, float ny, float nz, int l, int r, int g, int b) {
        v(p, c, ax, ay, az, 0, 0, nx, ny, nz, l, r, g, b);
        v(p, c, bx, by, bz, 0, 1, nx, ny, nz, l, r, g, b);
        v(p, c, cx, cy, cz, 1, 1, nx, ny, nz, l, r, g, b);
        v(p, c, dx, dy, dz, 1, 0, nx, ny, nz, l, r, g, b);
    }

    private static void v(PoseStack.Pose p, VertexConsumer c, float x, float y, float z, float u, float vv,
                          float nx, float ny, float nz, int l, int r, int g, int b) {
        c.addVertex(p, x, y, z).setColor(r, g, b, 255).setUv(u, vv)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(l).setNormal(p, nx, ny, nz);
    }
}
