package dev.physx.core.vehicle;

/** Параметры машины. Позже будут читаться из JSON датапака. */
public final class VehicleSpec {
    public double mass = 1200, ix = 1796, iy = 2000, iz = 596;
    public double halfWheelbase = 1.3, halfTrack = 0.8, mountY = 0.25;
    public double wheelRadius = 0.34, wheelInertia = 1.5;
    public double springK = 35000, damperC = 3200, maxLen = 0.5, bumpLen = 0.08;
    public double maxBrakeTorque = 1300, handbrakeTorque = 2200;
    public double steerLow = 0.55, steerHigh = 0.06, steerSpeedRef = 18;
    public double mu = 1.15;
    public double cd = 0.32, frontalArea = 2.2, downforceCoef = 0.15, sideCd = 1.0, sideArea = 5.0, aeroCenterZ = -0.3;
    public boolean tractionControl = true;
    public double rollingResistance = 0.015;
    public final Drivetrain drivetrain = new Drivetrain();

    public static VehicleSpec sportsCar() { return new VehicleSpec(); }
}
