package dev.physx.core.vehicle;

public interface GroundProbe {
    /** Расстояние до поверхности вдоль луча или -1, если не попали. */
    double cast(double ox, double oy, double oz, double dx, double dy, double dz, double maxLen);
    /** Сцепление поверхности последнего попадания (1.0 = асфальт, ~0.2 = лёд). */
    double grip();
}
